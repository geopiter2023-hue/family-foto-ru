import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  createPhoto,
  createPhotosOneByOne,
  findPhotoById,
  updatePhoto,
  deletePhoto,
  findPhotosByAlbum,
  findAlbumById,
  updateAlbum,
} from "./queries/familyAlbum";
import { Errors } from "@contracts/errors";

// Remove undefined values from object for clean SQL insert
function cleanInsert<T extends Record<string, unknown>>(obj: T): Partial<T> {
  const result: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) result[key] = value;
  }
  return result as Partial<T>;
}

export const photoRouter = createRouter({
  listByAlbum: authedQuery
    .input(z.object({ albumId: z.number().min(1) }))
    .query(async ({ ctx, input }) => {
      const album = await findAlbumById(input.albumId, ctx.user.id);
      if (!album) throw Errors.notFound("Альбом не найден");
      return findPhotosByAlbum(input.albumId);
    }),

  getById: authedQuery
    .input(z.object({ id: z.number().min(1) }))
    .query(async ({ input }) => {
      const photo = await findPhotoById(input.id);
      if (!photo) throw Errors.notFound("Фото не найдено");
      return photo;
    }),

  create: authedQuery
    .input(
      z.object({
        albumId: z.number().min(1),
        familyMemberId: z.number().optional(),
        url: z.string().min(1, "URL обязателен"),
        caption: z.string().max(255).optional(),
        emotion: z.string().max(50).optional(),
        emotionNote: z.string().optional(),
        dateTaken: z.date().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const album = await findAlbumById(input.albumId, ctx.user.id);
      if (!album) throw Errors.notFound("Альбом не найден");
      return createPhoto(cleanInsert(input) as typeof input);
    }),

  // Batch create - for uploading series of photos
  createBatch: authedQuery
    .input(
      z.object({
        albumId: z.number().min(1),
        familyMemberId: z.number().optional(),
        items: z.array(
          z.object({
            url: z.string().min(1),
            caption: z.string().max(255).optional(),
            emotion: z.string().max(50).optional(),
            emotionNote: z.string().optional(),
            dateTaken: z.date().optional(),
          })
        ).min(1).max(50),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const album = await findAlbumById(input.albumId, ctx.user.id);
      if (!album) throw Errors.notFound("Альбом не найден");
      const photos = await createPhotosOneByOne(
        input.items.map(item =>
          cleanInsert({
            ...item,
            albumId: input.albumId,
            familyMemberId: input.familyMemberId,
          })
        ) as Parameters<typeof createPhotosOneByOne>[0]
      );
      // Auto-set cover if album has no cover
      if (photos.length > 0 && !album.coverPhotoId) {
        await updateAlbum(input.albumId, ctx.user.id, { coverPhotoId: photos[0].id });
      }
      return photos;
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number().min(1),
        albumId: z.number().min(1),
        caption: z.string().max(255).optional(),
        emotion: z.string().max(50).optional(),
        emotionNote: z.string().optional(),
        dateTaken: z.date().optional(),
        familyMemberId: z.number().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const { id, albumId, ...data } = input;
      const photo = await updatePhoto(id, albumId, data);
      if (!photo) throw Errors.notFound("Фото не найдено");
      return photo;
    }),

  delete: authedQuery
    .input(z.object({ id: z.number().min(1), albumId: z.number().min(1) }))
    .mutation(async ({ input }) => {
      await deletePhoto(input.id, input.albumId);
      return { success: true };
    }),

  setCover: authedQuery
    .input(z.object({ photoId: z.number().min(1), albumId: z.number().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const album = await findAlbumById(input.albumId, ctx.user.id);
      if (!album) throw Errors.notFound("Альбом не найден");
      await updateAlbum(input.albumId, ctx.user.id, { coverPhotoId: input.photoId });
      return { success: true };
    }),
});
