import { getDb } from "../queries/connection";
import { users, otpCodes, albums, photos, familyMembers, albumShares } from "@db/schema";
import { eq, and, desc, asc, inArray } from "drizzle-orm";

// Auth queries
export async function findUserByEmail(email: string) {
  return getDb().query.users.findFirst({
    where: eq(users.email, email),
  });
}

export async function createUser(email: string, name?: string) {
  const result = await getDb().insert(users).values({ email, name }).$returningId();
  const id = result[0].id;
  return getDb().query.users.findFirst({ where: eq(users.id, id) });
}

export async function createOtpCode(email: string, code: string, expiresAt: Date) {
  await getDb().insert(otpCodes).values({ email, code, expiresAt });
}

export async function findValidOtpCode(email: string, code: string) {
  return getDb().query.otpCodes.findFirst({
    where: and(
      eq(otpCodes.email, email),
      eq(otpCodes.code, code),
      eq(otpCodes.used, false),
    ),
  });
}

export async function markOtpCodeUsed(id: number) {
  await getDb().update(otpCodes).set({ used: true }).where(eq(otpCodes.id, id));
}

// Family Members queries
export async function findFamilyMembersByUser(userId: number) {
  return getDb().query.familyMembers.findMany({
    where: eq(familyMembers.userId, userId),
    orderBy: [asc(familyMembers.name)],
  });
}

export async function createFamilyMember(data: { userId: number; name: string; email?: string | null; avatar?: string; color?: string }) {
  const result = await getDb().insert(familyMembers).values({
    userId: data.userId,
    name: data.name,
    email: data.email || null,
    avatar: data.avatar || null,
    color: data.color || "#c9a87c",
  }).$returningId();
  const id = result[0].id;
  return getDb().query.familyMembers.findFirst({ where: eq(familyMembers.id, id) });
}

export async function updateFamilyMember(id: number, userId: number, data: { name?: string; avatar?: string; color?: string }) {
  await getDb().update(familyMembers).set(data).where(and(eq(familyMembers.id, id), eq(familyMembers.userId, userId)));
  return getDb().query.familyMembers.findFirst({ where: eq(familyMembers.id, id) });
}

export async function deleteFamilyMember(id: number, userId: number) {
  await getDb().delete(familyMembers).where(and(eq(familyMembers.id, id), eq(familyMembers.userId, userId)));
}

// Album queries
export async function findAlbumsByUser(userId: number) {
  const albumList = await getDb().query.albums.findMany({
    where: eq(albums.userId, userId),
    orderBy: [desc(albums.year), desc(albums.createdAt)],
    with: {
      coverPhoto: true,
    },
  });
  // Fetch ALL photos for ALL albums explicitly (relational query has limit)
  const userAlbumIds = albumList.map((a) => a.id);
  const allPhotos = userAlbumIds.length > 0
    ? await getDb().select().from(photos)
        .where(inArray(photos.albumId, userAlbumIds))
        .orderBy(asc(photos.createdAt))
    : [];
  return albumList.map((a) => ({
    ...a,
    photos: allPhotos.filter((p) => p.albumId === a.id),
  }));
}

// Find album that was shared with the given user (not the owner)
export async function findAlbumByIdShared(albumId: number, sharedWithUserId: number) {
  const db = getDb();
  const share = await db.query.albumShares.findFirst({
    where: and(
      eq(albumShares.albumId, albumId),
      eq(albumShares.sharedWithUserId, sharedWithUserId)
    ),
  });
  if (!share) return null;

  const album = await findAlbumById(albumId, share.ownerUserId);
  if (!album) return null;

  return { ...album, isShared: true as const };
}

export async function findAlbumById(id: number, userId: number) {
  const album = await getDb().query.albums.findFirst({
    where: and(eq(albums.id, id), eq(albums.userId, userId)),
    with: {
      coverPhoto: true,
    },
  });
  if (!album) return null;
  // Fetch ALL photos explicitly — relational query limits results
  const allPhotos = await getDb().select().from(photos)
    .where(eq(photos.albumId, id))
    .orderBy(asc(photos.createdAt));
  // Fetch family members for photos
  const memberIds = [...new Set(allPhotos.map((p) => p.familyMemberId).filter(Boolean))];
  const members = memberIds.length > 0
    ? await getDb().select().from(familyMembers).where(eq(familyMembers.userId, userId))
    : [];
  const photosWithMembers = allPhotos.map((p) => ({
    ...p,
    familyMember: members.find((m) => m.id === p.familyMemberId) || null,
  }));
  return { ...album, photos: photosWithMembers };
}

export async function createAlbum(data: { userId: number; year: number; title: string; location?: string; description?: string }) {
  const result = await getDb().insert(albums).values(data).$returningId();
  const id = result[0].id;
  return getDb().query.albums.findFirst({ where: eq(albums.id, id) });
}

export async function updateAlbum(id: number, userId: number, data: { year?: number; title?: string; location?: string | null; description?: string | null; coverPhotoId?: number | null; photosPerPage?: number }) {
  await getDb().update(albums).set({ ...data, updatedAt: new Date() }).where(and(eq(albums.id, id), eq(albums.userId, userId)));
  return getDb().query.albums.findFirst({ where: eq(albums.id, id) });
}

export async function deleteAlbum(id: number, userId: number) {
  await getDb().delete(albums).where(and(eq(albums.id, id), eq(albums.userId, userId)));
}

// Photo queries
export async function createPhoto(data: { albumId: number; familyMemberId?: number; url: string; caption?: string; emotion?: string; emotionNote?: string; dateTaken?: Date }) {
  const result = await getDb().insert(photos).values(data).$returningId();
  const id = result[0].id;
  return getDb().query.photos.findFirst({
    where: eq(photos.id, id),
    with: { familyMember: true },
  });
}

// Insert photos one by one (avoiding MySQL batch insert issues)
export async function createPhotosOneByOne(items: Array<{ albumId: number; familyMemberId?: number; url: string; caption?: string; emotion?: string; emotionNote?: string; dateTaken?: Date }>) {
  const results = [];
  for (const item of items) {
    const result = await getDb().insert(photos).values(item).$returningId();
    const photo = await getDb().query.photos.findFirst({
      where: eq(photos.id, result[0].id),
      with: { familyMember: true },
    });
    if (photo) results.push(photo);
  }
  return results;
}

export async function findPhotoById(id: number) {
  return getDb().query.photos.findFirst({
    where: eq(photos.id, id),
    with: {
      album: true,
      familyMember: true,
    },
  });
}

export async function updatePhoto(id: number, albumId: number, data: { caption?: string; emotion?: string; emotionNote?: string; dateTaken?: Date; familyMemberId?: number }) {
  await getDb().update(photos).set({ ...data, updatedAt: new Date() }).where(and(eq(photos.id, id), eq(photos.albumId, albumId)));
  return findPhotoById(id);
}

export async function deletePhoto(id: number, albumId: number) {
  await getDb().delete(photos).where(and(eq(photos.id, id), eq(photos.albumId, albumId)));
}

export async function findPhotosByAlbum(albumId: number) {
  return getDb().query.photos.findMany({
    where: eq(photos.albumId, albumId),
    orderBy: [asc(photos.createdAt)],
  });
}