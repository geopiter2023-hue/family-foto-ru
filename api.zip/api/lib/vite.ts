import { readFileSync, existsSync, statSync } from "node:fs";
import path from "node:path";
import type { Hono } from "hono";

function findProjectRoot(): string {
  let dir = process.cwd();
  // Walk up until we find package.json or hit root
  while (dir !== "/" && dir !== ".") {
    if (existsSync(path.join(dir, "package.json"))) {
      return dir;
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

function findPublicDir(): string {
  const roots = [
    path.resolve(process.cwd(), "public"),
    path.resolve(process.cwd(), "..", "public"),
    path.resolve(process.cwd(), "..", "..", "public"),
    path.resolve(process.cwd(), "..", "..", "..", "public"),
    path.resolve(findProjectRoot(), "public"),
    path.resolve(findProjectRoot(), "dist", "public"),
  ];
  for (const r of roots) {
    try {
      if (existsSync(path.join(r, "index.html"))) {
        return r;
      }
    } catch { /* ignore */ }
  }
  return path.resolve(process.cwd(), "public");
}

const mimeTypes: Record<string, string> = {
  ".js": "application/javascript",
  ".css": "text/css",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
};

export function serveStaticFiles(app: Hono) {
  const distPath = findPublicDir();
  const uploadsPath = path.join(distPath, "..", "public");

  // Serve JS/CSS assets
  app.use("/assets/*", async (c, next) => {
    const url = new URL(c.req.url);
    const filePath = path.join(distPath, url.pathname);
    try {
      if (!existsSync(filePath)) return await next();
      const content = readFileSync(filePath);
      const ext = path.extname(filePath);
      return c.newResponse(content, 200, {
        "Content-Type": mimeTypes[ext] || "application/octet-stream",
      });
    } catch {
      return await next();
    }
  });

  // Serve images and other static files
  app.use("/*", async (c, next) => {
    const url = new URL(c.req.url);
    const pathname = url.pathname;
    if (pathname.startsWith("/api/")) return await next();
    
    const filePath = path.join(distPath, pathname);
    try {
      if (existsSync(filePath) && statSync(filePath).isFile()) {
        const content = readFileSync(filePath);
        const ext = path.extname(filePath);
        return c.newResponse(content, 200, {
          "Content-Type": mimeTypes[ext] || "application/octet-stream",
        });
      }
    } catch { /* ignore */ }
    return await next();
  });

  // SPA fallback
  app.use("*", (c) => {
    const pathname = new URL(c.req.url).pathname;
    if (pathname.startsWith("/api/")) {
      return c.json({ error: "Not Found" }, 404);
    }
    try {
      const indexHtml = readFileSync(path.join(distPath, "index.html"), "utf-8");
      return c.html(indexHtml, 200);
    } catch {
      return c.json({ error: "index.html not found" }, 500);
    }
  });
}
