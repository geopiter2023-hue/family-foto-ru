import fs from "node:fs";
import path from "node:path";

function findEnvFile(): string | null {
  const candidates = [
    path.resolve(process.cwd(), ".env"),
    path.resolve(process.cwd(), "..", ".env"),
    path.resolve(process.cwd(), "..", "..", ".env"),
    path.resolve(process.cwd(), "..", "..", "..", ".env"),
    path.resolve(process.cwd(), "..", "..", "..", "..", ".env"),
    "/home/u/.env",
    "/home/.env",
    "/.env",
  ];
  for (const p of candidates) {
    try {
      if (fs.existsSync(p) && fs.statSync(p).isFile()) {
        return p;
      }
    } catch { /* ignore */ }
  }
  return null;
}

function parseEnvFile(filepath: string): Record<string, string> {
  const result: Record<string, string> = {};
  try {
    const content = fs.readFileSync(filepath, "utf-8");
    for (const line of content.split("\n")) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eq = trimmed.indexOf("=");
      if (eq === -1) continue;
      const key = trimmed.slice(0, eq).trim();
      let value = trimmed.slice(eq + 1).trim();
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
        value = value.slice(1, -1);
      }
      if (key) result[key] = value;
    }
  } catch { /* ignore */ }
  return result;
}

// Load .env from file
const envPath = findEnvFile();
const fileEnv = envPath ? parseEnvFile(envPath) : {};

if (envPath) {
  console.log("[ENV] Loaded .env from:", envPath);
} else {
  console.log("[ENV] WARNING: .env file not found anywhere");
}

function get(name: string, fallback?: string): string | undefined {
  return process.env[name] || fileEnv[name] || fallback;
}

export const env = {
  appId: get("APP_ID", "family-album-001")!,
  appSecret: get("APP_SECRET", "w7Kp9mN2xQ4vL8jR5tY6uI3oP1aS0dF2h9Jk3mN7pQ5")!,
  jwtSecret: get("JWT_SECRET", "h9Jk3mN7pQ5rT2vX8yZ4bC6dE1fG0hK4l8Jk2mN6pQ9")!,
  isProduction: process.env.NODE_ENV === "production",
  databaseUrl: get("DATABASE_URL", "")!,
  smtpHost: get("SMTP_HOST"),
  smtpPort: get("SMTP_PORT"),
  smtpUser: get("SMTP_USER"),
  smtpPass: get("SMTP_PASS"),
  smtpFrom: get("SMTP_FROM"),
  adminPassword: get("ADMIN_PASSWORD", "mariana2024")!,
};

// Log env state (safe, no secrets)
console.log("[ENV] APP_ID present:", !!env.appId);
console.log("[ENV] DATABASE_URL present:", !!env.databaseUrl);
console.log("[ENV] JWT_SECRET present:", !!env.jwtSecret);
