import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  users,
  albums,
  photos,
  supportReviews,
  cardCopyStats,
  supportMessages,
} from "@db/schema";
import { count, eq, sql } from "drizzle-orm";
import { env } from "./lib/env";

// Simple admin password check (set ADMIN_PASSWORD in .env)
function checkAdmin(password?: string) {
  const adminPass = env.adminPassword || "mariana2024";
  if (!password || password !== adminPass) {
    throw new Error("Неверный пароль администратора");
  }
}

export const adminRouter = createRouter({
  stats: publicQuery
    .input(z.object({ password: z.string() }))
    .query(async ({ input }) => {
      checkAdmin(input.password);
      const db = getDb();

      const [userCount] = await db.select({ total: count(users.id) }).from(users);
      const [albumCount] = await db.select({ total: count(albums.id) }).from(albums);
      const [photoCount] = await db.select({ total: count(photos.id) }).from(photos);
      const [reviewCount] = await db.select({ total: count(supportReviews.id) }).from(supportReviews);
      const [cardCopyCount] = await db.select({ total: count(cardCopyStats.id) }).from(cardCopyStats);
      const [msgCount] = await db.select({ total: count(supportMessages.id) }).from(supportMessages);
      const [unreadMsgCount] = await db
        .select({ total: count(supportMessages.id) })
        .from(supportMessages)
        .where(eq(supportMessages.isRead, false));

      return {
        users: Number(userCount.total),
        albums: Number(albumCount.total),
        photos: Number(photoCount.total),
        reviews: Number(reviewCount.total),
        cardCopies: Number(cardCopyCount.total),
        messages: Number(msgCount.total),
        unreadMessages: Number(unreadMsgCount.total),
      };
    }),

  reviews: publicQuery
    .input(z.object({ password: z.string() }))
    .query(async ({ input }) => {
      checkAdmin(input.password);
      const db = getDb();
      return db.select().from(supportReviews).orderBy(sql`${supportReviews.createdAt} DESC`);
    }),

  messages: publicQuery
    .input(z.object({ password: z.string() }))
    .query(async ({ input }) => {
      checkAdmin(input.password);
      const db = getDb();
      return db.select().from(supportMessages).orderBy(sql`${supportMessages.createdAt} DESC`);
    }),

  markMessageRead: publicQuery
    .input(z.object({ password: z.string(), id: z.number() }))
    .mutation(async ({ input }) => {
      checkAdmin(input.password);
      const db = getDb();
      await db.update(supportMessages).set({ isRead: true }).where(eq(supportMessages.id, input.id));
      return { success: true };
    }),

  deleteMessage: publicQuery
    .input(z.object({ password: z.string(), id: z.number() }))
    .mutation(async ({ input }) => {
      checkAdmin(input.password);
      const db = getDb();
      await db.delete(supportMessages).where(eq(supportMessages.id, input.id));
      return { success: true };
    }),

  trackCardCopy: publicQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    const ip = ctx.req.headers.get("x-forwarded-for") ||
      ctx.req.headers.get("x-real-ip") || "unknown";
    const userAgent = ctx.req.headers.get("user-agent") || "";
    await db.insert(cardCopyStats).values({ ip, userAgent });
    return { success: true };
  }),

  createMessage: publicQuery
    .input(
      z.object({
        name: z.string().optional(),
        email: z.string().email().optional(),
        message: z.string().min(1, "Сообщение обязательно"),
        type: z.enum(["support", "idea", "bug", "other"]).default("support"),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(supportMessages).values({
        name: input.name || null,
        email: input.email || null,
        message: input.message,
        type: input.type,
      });
      return { success: true };
    }),
});
