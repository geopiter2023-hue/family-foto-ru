import { Hono } from "hono";
import { writeFileSync, existsSync, mkdirSync } from "node:fs";
import path from "node:path";

// Find project root by looking for package.json
function findProjectRoot(): string {
  let dir = process.cwd();
  while (dir !== "/" && dir !== ".") {
    if (existsSync(path.join(dir, "package.json"))) {
      return dir;
    }
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

const projectRoot = findProjectRoot();
const uploadDir = path.join(projectRoot, "public", "uploads", "photos");

if (!existsSync(uploadDir)) {
  mkdirSync(uploadDir, { recursive: true });
}

export const uploadApp = new Hono();

uploadApp.post("/", async (c) => {
  try {
    const body = await c.req.parseBody();
    const file = body.file;

    if (!file || !(file instanceof File)) {
      return c.json({ error: "No file provided" }, 400);
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Generate unique filename: timestamp-random.jpg
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
    const safeExt = ["jpg", "jpeg", "png", "webp", "gif"].includes(ext) ? ext : "jpg";
    const filename = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${safeExt}`;
    const filepath = path.join(uploadDir, filename);

    writeFileSync(filepath, buffer);

    // Return public URL path
    const publicPath = `/uploads/photos/${filename}`;
    return c.json({ success: true, url: publicPath });
  } catch (err) {
    console.error("Upload error:", err);
    return c.json({ error: "Upload failed" }, 500);
  }
});
