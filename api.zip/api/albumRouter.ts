import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  findAlbumsByUser,
  findAlbumById,
  findAlbumByIdShared,
  createAlbum,
  updateAlbum,
  deleteAlbum,
} from "./queries/familyAlbum";
import { albumShares } from "@db/schema";
import { eq, and } from "drizzle-orm";
import { Errors } from "@contracts/errors";

export const albumRouter = createRouter({
  list: authedQuery.query(({ ctx }) =>
    findAlbumsByUser(ctx.user.id),
  ),

  listShared: authedQuery.query(async ({ ctx }) => {
    try {
      const db = getDb();
      // Find all shares where current user is the recipient
      const shares = await db.select().from(albumShares)
        .where(eq(albumShares.sharedWithUserId, ctx.user.id));
      // Get full album data with photos for each shared album
      const result = [];
      for (const share of shares) {
        try {
          const album = await findAlbumById(share.albumId, share.ownerUserId);
          if (album) result.push({ ...album, isShared: true as const });
        } catch { /* skip albums that can't be loaded */ }
      }
      return result;
    } catch {
      // Return empty array if albumShares table doesn't exist yet
      return [];
    }
  }),

  getById: authedQuery
    .input(z.object({ id: z.number().min(1) }))
    .query(async ({ ctx, input }) => {
      // First try: user's own album
      let album = await findAlbumById(input.id, ctx.user.id);
      // Second try: shared album
      if (!album) {
        album = await findAlbumByIdShared(input.id, ctx.user.id);
      }
      if (!album) throw Errors.notFound("Альбом не найден");
      return album;
    }),

  create: authedQuery
    .input(
      z.object({
        year: z.number().min(1900).max(2100),
        title: z.string().min(1, "Название обязательно").max(255),
        location: z.string().max(255).optional(),
        description: z.string().optional(),
      }),
    )
    .mutation(({ ctx, input }) =>
      createAlbum({ userId: ctx.user.id, ...input }),
    ),

  update: authedQuery
    .input(
      z.object({
        id: z.number().min(1),
        year: z.number().min(1900).max(2100).optional(),
        title: z.string().min(1).max(255).optional(),
        location: z.string().max(255).optional().nullable(),
        description: z.string().optional().nullable(),
        coverPhotoId: z.number().optional().nullable(),
        photosPerPage: z.number().min(1).max(4).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      const album = await updateAlbum(id, ctx.user.id, data);
      if (!album) throw Errors.notFound("Альбом не найден");
      return album;
    }),

  setCover: authedQuery
    .input(
      z.object({
        id: z.number().min(1),
        coverPhotoId: z.number().min(1),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const album = await updateAlbum(input.id, ctx.user.id, { coverPhotoId: input.coverPhotoId });
      if (!album) throw Errors.notFound("Альбом не найден");
      return album;
    }),

  delete: authedQuery
    .input(z.object({ id: z.number().min(1) }))
    .mutation(async ({ ctx, input }) => {
      await deleteAlbum(input.id, ctx.user.id);
      return { success: true };
    }),
});
