import mysql from "mysql2/promise";
import { env } from "./lib/env";

export async function runMigrations() {
  const pool = mysql.createPool(env.databaseUrl);
  const connection = await pool.getConnection();

  try {
    console.log("[MIGRATE] Checking database tables...");

    // Check if users table exists
    const [rows] = await connection.execute(
      "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users'"
    );

    if ((rows as any[]).length > 0) {
      console.log("[MIGRATE] Tables already exist, skipping.");
      return;
    }

    console.log("[MIGRATE] Creating tables...");

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(320) NOT NULL UNIQUE,
        name VARCHAR(255),
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL,
        updatedAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS otpCodes (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(320) NOT NULL,
        code VARCHAR(6) NOT NULL,
        expiresAt TIMESTAMP NOT NULL,
        used TINYINT(1) DEFAULT 0 NOT NULL,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS familyMembers (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        userId BIGINT UNSIGNED NOT NULL,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(320),
        avatar LONGTEXT,
        color VARCHAR(20) DEFAULT '#c9a87c' NOT NULL,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS albums (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        userId BIGINT UNSIGNED NOT NULL,
        year INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        location VARCHAR(255),
        description TEXT,
        coverPhotoId BIGINT UNSIGNED,
        photosPerPage INT DEFAULT 1 NOT NULL,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL,
        updatedAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS photos (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        albumId BIGINT UNSIGNED NOT NULL,
        familyMemberId BIGINT UNSIGNED,
        url LONGTEXT NOT NULL,
        caption VARCHAR(255),
        emotion VARCHAR(50),
        emotionNote TEXT,
        dateTaken TIMESTAMP,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL,
        updatedAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS photoBookPages (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        albumId BIGINT UNSIGNED NOT NULL,
        pageNumber INT NOT NULL,
        layoutType VARCHAR(50) NOT NULL,
        title VARCHAR(255),
        subtitle VARCHAR(255),
        backgroundColor VARCHAR(20) DEFAULT '#faf8f5',
        accentColor VARCHAR(20) DEFAULT '#c9a87c',
        pageData LONGTEXT,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS albumInvites (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        albumId BIGINT UNSIGNED NOT NULL,
        email VARCHAR(320) NOT NULL,
        name VARCHAR(255),
        token VARCHAR(64) NOT NULL UNIQUE,
        status VARCHAR(20) DEFAULT 'pending' NOT NULL,
        invitedBy BIGINT UNSIGNED NOT NULL,
        acceptedAt TIMESTAMP,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS albumShares (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        albumId BIGINT UNSIGNED NOT NULL,
        ownerUserId BIGINT UNSIGNED NOT NULL,
        sharedWithUserId BIGINT UNSIGNED NOT NULL,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS pageAssignments (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        albumId BIGINT UNSIGNED NOT NULL,
        pageNumber INT NOT NULL,
        photoId BIGINT UNSIGNED NOT NULL,
        position INT DEFAULT 0 NOT NULL,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS supportReviews (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        rating INT NOT NULL,
        comment TEXT,
        thanks TEXT,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS cardCopyStats (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(45),
        userAgent TEXT,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS supportMessages (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255),
        email VARCHAR(320),
        message TEXT NOT NULL,
        type VARCHAR(20) DEFAULT 'support' NOT NULL,
        isRead TINYINT(1) DEFAULT 0 NOT NULL,
        createdAt TIMESTAMP DEFAULT NOW() NOT NULL
      )
    `);

    console.log("[MIGRATE] All tables created successfully!");
  } catch (err) {
    console.error("[MIGRATE] Migration failed:", err);
    throw err;
  } finally {
    connection.release();
    await pool.end();
  }
}
