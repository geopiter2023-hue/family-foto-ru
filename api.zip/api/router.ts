import { createRouter, publicQuery } from "./middleware";
import { authRouter } from "./authRouter";
import { albumRouter } from "./albumRouter";
import { photoRouter } from "./photoRouter";
import { familyMemberRouter } from "./familyMemberRouter";
import { photoBookRouter } from "./photoBookRouter";
import { inviteRouter } from "./inviteRouter";
import { supportRouter } from "./supportRouter";
import { adminRouter } from "./adminRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  album: albumRouter,
  photo: photoRouter,
  familyMember: familyMemberRouter,
  photoBook: photoBookRouter,
  invite: inviteRouter,
  support: supportRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
