import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { supportReviews } from "@db/schema";
import { count, avg, sql } from "drizzle-orm";

export const supportRouter = createRouter({
  stats: publicQuery.query(async () => {
    try {
      const db = getDb();
      const [result] = await db
        .select({
          total: count(supportReviews.id),
          avgRating: avg(supportReviews.rating),
        })
        .from(supportReviews);

      return {
        count: Number(result?.total ?? 0),
        avgRating: result?.avgRating ? Number(result.avgRating).toFixed(1) : null,
      };
    } catch {
      return { count: 0, avgRating: null };
    }
  }),

  create: publicQuery
    .input(
      z.object({
        rating: z.number().min(1).max(5),
        comment: z.string().optional(),
        thanks: z.string().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(supportReviews).values({
        rating: input.rating,
        comment: input.comment || null,
        thanks: input.thanks || null,
      });
      return { success: true };
    }),
});
