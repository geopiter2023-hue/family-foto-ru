import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { photoBookPages, albums, photos, pageAssignments } from "@db/schema";
import { eq, and, asc } from "drizzle-orm";
import { Errors } from "@contracts/errors";

interface PhotoInfo {
  id: number;
  url: string;
  caption: string | null;
  emotion: string | null;
}

interface PageLayout {
  pageNumber: number;
  layoutType: string;
  title: string | null;
  subtitle: string | null;
  backgroundColor: string;
  accentColor: string;
  pageData: string;
}

function pickLayout(count: number, variant: number): string {
  const layouts: Record<number, string[]> = {
    1: ["full", "hero"],
    2: ["duo", "split", "mirror"],
    3: ["featured", "collage3", "triptych"],
    4: ["collage4", "grid2x2", "masonry4"],
  };
  const options = layouts[count] || layouts[1];
  return options[variant % options.length];
}

const accentPalette = [
  { primary: "#c9a87c", secondary: "#e8ddd0" },
  { primary: "#e8927c", secondary: "#f5ddd8" },
  { primary: "#7cb5e8", secondary: "#dde8f5" },
  { primary: "#a3d977", secondary: "#e0f0d5" },
  { primary: "#d4a5e8", secondary: "#f0e5f5" },
  { primary: "#e8c97c", secondary: "#f5ebd8" },
  { primary: "#e87c8a", secondary: "#f5d8dc" },
  { primary: "#7ce8d4", secondary: "#d8f5f0" },
];

const emotionTitles: Record<string, string> = {
  "Счастье": "Моменты счастья",
  "Любовь": "С любовью",
  "Радость": "Радостные дни",
  "Восторг": "В восторге",
  "Спокойствие": "Спокойные моменты",
  "Ностальгия": "Тёплые воспоминания",
  "Волнение": "Волнительные моменты",
  "Уют": "Уютные деньки",
};

// Build pages from user assignments + auto-fill remaining
async function buildPagesFromAssignments(
  albumId: number,
  albumTitle: string,
  albumYear: number,
  albumLocation: string | null,
  allPhotos: PhotoInfo[],
): Promise<PageLayout[]> {
  // Get existing assignments
  const assignments = await getDb().select().from(pageAssignments)
    .where(eq(pageAssignments.albumId, albumId))
    .orderBy(asc(pageAssignments.pageNumber), asc(pageAssignments.position));

  // Group assignments by pageNumber
  const pageMap = new Map<number, number[]>(); // pageNumber -> photoIds[]
  for (const a of assignments) {
    if (!pageMap.has(a.pageNumber)) pageMap.set(a.pageNumber, []);
    pageMap.get(a.pageNumber)!.push(a.photoId);
  }

  // Get assigned photo ids
  const assignedIds = new Set(assignments.map((a) => a.photoId));
  const unassigned = allPhotos.filter((p) => !assignedIds.has(p.id));

  const pages: PageLayout[] = [];
  let pageNum = 0;

  // COVER — full-spread first page
  const coverPhoto = allPhotos[0];
  pages.push({
    pageNumber: pageNum++,
    layoutType: "cover",
    title: albumTitle,
    subtitle: `${albumYear}${albumLocation ? ` · ${albumLocation}` : ""}`,
    backgroundColor: accentPalette[0].secondary,
    accentColor: accentPalette[0].primary,
    pageData: JSON.stringify({
      photos: coverPhoto ? [{ photoId: coverPhoto.id, url: coverPhoto.url, position: 0, caption: coverPhoto.caption }] : [],
      perPage: 1,
    }),
  });

  // Get all content page numbers (exclude cover page 0)
  const contentPageNumbers = Array.from(pageMap.keys())
    .filter((n) => n > 0)
    .sort((a, b) => a - b);

  // Build content pages from assignments
  let paletteIdx = 1;
  for (const pgNum of contentPageNumbers) {
    const photoIds = pageMap.get(pgNum) || [];
    const pagePhotos = photoIds.map((id) => allPhotos.find((p) => p.id === id)).filter(Boolean) as PhotoInfo[];
    if (pagePhotos.length === 0) continue;

    const layout = pickLayout(pagePhotos.length, paletteIdx);
    const palette = accentPalette[paletteIdx % accentPalette.length];

    const emotions = pagePhotos.map((p) => p.emotion).filter(Boolean) as string[];
    const counts: Record<string, number> = {};
    emotions.forEach((e) => { counts[e] = (counts[e] || 0) + 1; });
    const dominant = Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0];

    let title: string | null = null;
    if (dominant && emotionTitles[dominant]) title = emotionTitles[dominant];

    pages.push({
      pageNumber: pageNum++,
      layoutType: layout,
      title,
      subtitle: null,
      backgroundColor: palette.secondary,
      accentColor: palette.primary,
      pageData: JSON.stringify({
        photos: pagePhotos.map((ph, i) => ({ photoId: ph.id, url: ph.url, position: i, caption: ph.caption, emotion: ph.emotion })),
        perPage: pagePhotos.length,
      }),
    });
    paletteIdx++;
  }

  // Auto-fill any remaining unassigned photos into new pages
  if (unassigned.length > 0) {
    let idx = 0;
    while (idx < unassigned.length) {
      const count = Math.min(2, unassigned.length - idx); // Default 2 per auto page
      const pagePhotos = unassigned.slice(idx, idx + count);
      const layout = pickLayout(count, paletteIdx);
      const palette = accentPalette[paletteIdx % accentPalette.length];

      pages.push({
        pageNumber: pageNum++,
        layoutType: layout,
        title: null,
        subtitle: null,
        backgroundColor: palette.secondary,
        accentColor: palette.primary,
        pageData: JSON.stringify({
          photos: pagePhotos.map((ph, i) => ({ photoId: ph.id, url: ph.url, position: i, caption: ph.caption, emotion: ph.emotion })),
          perPage: count,
        }),
      });
      paletteIdx++;
      idx += count;
    }
  }

  // CLOSING page
  pages.push({
    pageNumber: pageNum++,
    layoutType: "closing",
    title: "С любовью",
    subtitle: `Наша семья · ${albumYear}`,
    backgroundColor: accentPalette[1].secondary,
    accentColor: accentPalette[1].primary,
    pageData: JSON.stringify({ photos: [], perPage: 1 }),
  });

  return pages;
}

export const photoBookRouter = createRouter({
  list: authedQuery
    .input(z.object({ albumId: z.number().min(1) }))
    .query(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");
      return getDb().query.photoBookPages.findMany({
        where: eq(photoBookPages.albumId, input.albumId),
        orderBy: [asc(photoBookPages.pageNumber)],
      });
    }),

  // Assign a photo to a specific page
  assignPhoto: authedQuery
    .input(z.object({
      albumId: z.number().min(1),
      pageNumber: z.number().min(1), // page 0 is cover
      photoId: z.number().min(1),
      position: z.number().default(0),
    }))
    .mutation(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");

      // Verify photo belongs to album
      const photo = await getDb().query.photos.findFirst({
        where: and(eq(photos.id, input.photoId), eq(photos.albumId, input.albumId)),
      });
      if (!photo) throw Errors.notFound("Фото не найдено в альбоме");

      // Remove existing assignment for this photo
      await getDb().delete(pageAssignments)
        .where(and(eq(pageAssignments.albumId, input.albumId), eq(pageAssignments.photoId, input.photoId)));

      // Insert new assignment
      await getDb().insert(pageAssignments).values({
        albumId: input.albumId,
        pageNumber: input.pageNumber,
        photoId: input.photoId,
        position: input.position,
      });

      return { success: true };
    }),

  // Remove photo from a page
  removePhoto: authedQuery
    .input(z.object({
      albumId: z.number().min(1),
      photoId: z.number().min(1),
    }))
    .mutation(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");

      await getDb().delete(pageAssignments)
        .where(and(eq(pageAssignments.albumId, input.albumId), eq(pageAssignments.photoId, input.photoId)));

      return { success: true };
    }),

  // Get assignments for an album
  getAssignments: authedQuery
    .input(z.object({ albumId: z.number().min(1) }))
    .query(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");

      return getDb().select().from(pageAssignments)
        .where(eq(pageAssignments.albumId, input.albumId))
        .orderBy(asc(pageAssignments.pageNumber), asc(pageAssignments.position));
    }),

  // Regenerate book from assignments
  generate: authedQuery
    .input(z.object({ albumId: z.number().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");

      // Fetch ALL photos
      const allPhotos = await getDb().select().from(photos)
        .where(eq(photos.albumId, input.albumId))
        .orderBy(asc(photos.createdAt));

      // Delete old pages
      await getDb().delete(photoBookPages).where(eq(photoBookPages.albumId, input.albumId));

      // Build pages from assignments
      const layouts = await buildPagesFromAssignments(
        input.albumId,
        album.title,
        album.year,
        album.location,
        allPhotos.map((p) => ({ id: p.id, url: p.url, caption: p.caption, emotion: p.emotion })),
      );

      for (const layout of layouts) {
        await getDb().insert(photoBookPages).values({
          albumId: input.albumId,
          pageNumber: layout.pageNumber,
          layoutType: layout.layoutType,
          title: layout.title,
          subtitle: layout.subtitle,
          backgroundColor: layout.backgroundColor,
          accentColor: layout.accentColor,
          pageData: layout.pageData,
        });
      }

      return getDb().query.photoBookPages.findMany({
        where: eq(photoBookPages.albumId, input.albumId),
        orderBy: [asc(photoBookPages.pageNumber)],
      });
    }),

  // Reset all assignments and regenerate fresh
  resetAssignments: authedQuery
    .input(z.object({ albumId: z.number().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");

      // Delete all assignments
      await getDb().delete(pageAssignments).where(eq(pageAssignments.albumId, input.albumId));

      // Regenerate fresh
      const allPhotos = await getDb().select().from(photos)
        .where(eq(photos.albumId, input.albumId))
        .orderBy(asc(photos.createdAt));

      await getDb().delete(photoBookPages).where(eq(photoBookPages.albumId, input.albumId));

      const layouts = await buildPagesFromAssignments(
        input.albumId,
        album.title,
        album.year,
        album.location,
        allPhotos.map((p) => ({ id: p.id, url: p.url, caption: p.caption, emotion: p.emotion })),
      );

      for (const layout of layouts) {
        await getDb().insert(photoBookPages).values({
          albumId: input.albumId,
          pageNumber: layout.pageNumber,
          layoutType: layout.layoutType,
          title: layout.title,
          subtitle: layout.subtitle,
          backgroundColor: layout.backgroundColor,
          accentColor: layout.accentColor,
          pageData: layout.pageData,
        });
      }

      return getDb().query.photoBookPages.findMany({
        where: eq(photoBookPages.albumId, input.albumId),
        orderBy: [asc(photoBookPages.pageNumber)],
      });
    }),

  clear: authedQuery
    .input(z.object({ albumId: z.number().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");
      await getDb().delete(photoBookPages).where(eq(photoBookPages.albumId, input.albumId));
      await getDb().delete(pageAssignments).where(eq(pageAssignments.albumId, input.albumId));
      return { success: true };
    }),
});
