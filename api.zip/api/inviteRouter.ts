import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { albumInvites, albums, photos, familyMembers, albumShares } from "@db/schema";
import { eq, and, asc, desc } from "drizzle-orm";
import { Errors } from "@contracts/errors";
import crypto from "crypto";

function generateToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

export const inviteRouter = createRouter({
  // Create invite for an album
  create: authedQuery
    .input(z.object({
      albumId: z.number().min(1),
      email: z.string().email("Неверный email"),
      name: z.string().min(1, "Введите имя").max(100),
    }))
    .mutation(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");

      // Check if invite already exists for this email+album
      const existing = await getDb().query.albumInvites.findFirst({
        where: and(
          eq(albumInvites.albumId, input.albumId),
          eq(albumInvites.email, input.email),
          eq(albumInvites.status, "pending")
        ),
      });
      if (existing) {
        // Return existing token
        return { token: existing.token, name: existing.name, email: existing.email };
      }

      const token = generateToken();
      await getDb().insert(albumInvites).values({
        albumId: input.albumId,
        email: input.email,
        name: input.name,
        token,
        status: "pending",
        invitedBy: ctx.user.id,
      });

      return { token, name: input.name, email: input.email };
    }),

  // Verify invite token and get album access
  verify: publicQuery
    .input(z.object({ token: z.string().min(1) }))
    .query(async ({ input }) => {
      const invite = await getDb().query.albumInvites.findFirst({
        where: eq(albumInvites.token, input.token),
      });
      if (!invite) throw Errors.notFound("Приглашение не найдено");
      if (invite.status === "declined") throw Errors.badRequest("Приглашение отклонено");

      const album = await getDb().query.albums.findFirst({
        where: eq(albums.id, invite.albumId),
      });
      if (!album) throw Errors.notFound("Альбом не найден");

      const albumPhotos = await getDb().select().from(photos)
        .where(eq(photos.albumId, album.id))
        .orderBy(asc(photos.createdAt));

      return {
        invite: { id: invite.id, name: invite.name, email: invite.email, albumId: invite.albumId, status: invite.status },
        album: { ...album, photos: albumPhotos },
      };
    }),

  // Upload photo as invited guest
  upload: publicQuery
    .input(z.object({
      token: z.string().min(1),
      url: z.string().min(1, "Фото обязательно"),
      caption: z.string().max(500).optional(),
      emotion: z.string().max(50).optional(),
      emotionNote: z.string().max(500).optional(),
    }))
    .mutation(async ({ input }) => {
      const invite = await getDb().query.albumInvites.findFirst({
        where: eq(albumInvites.token, input.token),
      });
      if (!invite) throw Errors.notFound("Приглашение не найдено");
      if (invite.status === "declined") throw Errors.badRequest("Приглашение отклонено");

      // Insert photo
      const result = await getDb().insert(photos).values({
        albumId: invite.albumId,
        url: input.url,
        caption: input.caption || null,
        emotion: input.emotion || null,
        emotionNote: input.emotionNote || null,
        familyMemberId: null,
      }).$returningId();

      return { id: result[0].id, albumId: invite.albumId };
    }),

  // Accept invite (marks as accepted)
  accept: authedQuery
    .input(z.object({ token: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const invite = await getDb().query.albumInvites.findFirst({
        where: eq(albumInvites.token, input.token),
      });
      if (!invite) throw Errors.notFound("Приглашение не найдено");

      // Update status
      await getDb().update(albumInvites)
        .set({ status: "accepted", acceptedAt: new Date() })
        .where(eq(albumInvites.id, invite.id));

      // Create family member if not exists
      const existingMember = await getDb().query.familyMembers.findFirst({
        where: and(
          eq(familyMembers.userId, ctx.user.id),
          eq(familyMembers.email, invite.email)
        ),
      });

      let memberId = existingMember?.id;
      if (!existingMember) {
        const result = await getDb().insert(familyMembers).values({
          userId: ctx.user.id,
          name: invite.name,
          email: invite.email,
          color: ["#c9a87c", "#e8927c", "#7cb5e8", "#a3d977", "#d4a5e8", "#e8c97c"][
            Math.floor(Math.random() * 6)
          ],
        }).$returningId();
        memberId = result[0]?.id;
      }

      // Create album share — link the album to the accepting user
      // First find the album owner
      const album = await getDb().query.albums.findFirst({
        where: eq(albums.id, invite.albumId),
      });
      if (album) {
        // Check if share already exists
        const existingShare = await getDb().query.albumShares.findFirst({
          where: and(
            eq(albumShares.albumId, invite.albumId),
            eq(albumShares.sharedWithUserId, ctx.user.id)
          ),
        });
        if (!existingShare) {
          await getDb().insert(albumShares).values({
            albumId: invite.albumId,
            ownerUserId: album.userId,
            sharedWithUserId: ctx.user.id,
          });
        }
      }

      return {
        invite: { ...invite, status: "accepted" as const },
        familyMemberId: memberId,
      };
    }),

  // List invites for an album
  listByAlbum: authedQuery
    .input(z.object({ albumId: z.number().min(1) }))
    .query(async ({ ctx, input }) => {
      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, input.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.notFound("Альбом не найден");

      return getDb().query.albumInvites.findMany({
        where: eq(albumInvites.albumId, input.albumId),
        orderBy: [desc(albumInvites.createdAt)],
      });
    }),

  // Cancel invite
  cancel: authedQuery
    .input(z.object({ id: z.number().min(1) }))
    .mutation(async ({ ctx, input }) => {
      const invite = await getDb().query.albumInvites.findFirst({
        where: eq(albumInvites.id, input.id),
      });
      if (!invite) throw Errors.notFound("Приглашение не найдено");

      const album = await getDb().query.albums.findFirst({
        where: and(eq(albums.id, invite.albumId), eq(albums.userId, ctx.user.id)),
      });
      if (!album) throw Errors.forbidden("Нет доступа");

      await getDb().delete(albumInvites).where(eq(albumInvites.id, input.id));
      return { success: true };
    }),
});
