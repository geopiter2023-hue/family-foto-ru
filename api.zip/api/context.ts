import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import { jwtVerify } from "jose";
import { env } from "./lib/env";
import { getDb } from "./queries/connection";
import { users } from "@db/schema";
import { eq } from "drizzle-orm";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: { id: number; email: string; name: string | null };
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const authHeader = opts.req.headers.get("authorization");
  let user: TrpcContext["user"] = undefined;

  if (authHeader?.startsWith("Bearer ")) {
    const token = authHeader.slice(7);
    try {
      const secret = new TextEncoder().encode(env.jwtSecret);
      const { payload } = await jwtVerify(token, secret, { clockTolerance: 60 });
      if (payload.sub && typeof payload.sub === "string") {
        const userId = parseInt(payload.sub, 10);
        if (!isNaN(userId)) {
          const dbUser = await getDb().query.users.findFirst({
            where: eq(users.id, userId),
          });
          if (dbUser) {
            user = {
              id: dbUser.id,
              email: dbUser.email,
              name: dbUser.name,
            };
          }
        }
      }
    } catch {
      // Invalid token, ignore
    }
  }

  return { req: opts.req, resHeaders: opts.resHeaders, user };
}
