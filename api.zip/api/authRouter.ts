import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import {
  findUserByEmail,
  createUser,
  createOtpCode,
  findValidOtpCode,
  markOtpCodeUsed,
} from "./queries/familyAlbum";
import { SignJWT } from "jose";
import { env } from "./lib/env";
import { Errors } from "@contracts/errors";
import nodemailer from "nodemailer";

function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Create SMTP transporter if credentials are configured
function getMailer() {
  if (!env.smtpHost || !env.smtpUser || !env.smtpPass) {
    return null;
  }
  return nodemailer.createTransport({
    host: env.smtpHost,
    port: env.smtpPort ? parseInt(env.smtpPort, 10) : 587,
    secure: env.smtpPort === "465",
    auth: {
      user: env.smtpUser,
      pass: env.smtpPass,
    },
  });
}

export const authRouter = createRouter({
  // Request OTP code
  sendOtp: publicQuery
    .input(z.object({ email: z.string().email("Введите корректный email") }))
    .mutation(async ({ input }) => {
      const code = generateOtp();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
      await createOtpCode(input.email, code, expiresAt);

      const mailer = getMailer();
      if (mailer) {
        try {
          await mailer.sendMail({
            from: env.smtpFrom || `"Семейный Альбом" <${env.smtpUser}>`,
            to: input.email,
            subject: "Код подтверждения — Семейный Альбом",
            text: `Ваш код подтверждения: ${code}\n\nКод действует 10 минут.\n\nЕсли вы не запрашивали код, просто проигнорируйте это письмо.`,
            html: `
              <div style="font-family:system-ui,sans-serif;max-width:400px;margin:0 auto;padding:24px;background:#faf8f5;border-radius:16px;">
                <h2 style="color:#6B4226;margin-top:0;">Семейный Альбом</h2>
                <p style="color:#4a4a4a;">Ваш код подтверждения:</p>
                <div style="background:#fff;padding:16px 32px;border-radius:12px;text-align:center;margin:16px 0;border:2px solid #c9a87c;">
                  <span style="font-size:32px;font-weight:bold;letter-spacing:8px;color:#c9a87c;">${code}</span>
                </div>
                <p style="color:#8a8279;font-size:14px;">Код действует 10 минут.</p>
                <p style="color:#8a8279;font-size:12px;margin-top:24px;">Если вы не запрашивали код, просто проигнорируйте это письмо.</p>
              </div>
            `,
          });
          return {
            success: true,
            message: "Код отправлен на ваш email",
            demoCode: undefined,
          };
        } catch (err) {
          console.error("Email send failed:", err);
          // Fallback: return code in response for demo
          return {
            success: true,
            message: "Не удалось отправить письмо. Код отображён ниже.",
            demoCode: code,
          };
        }
      }

      // Demo mode: log and show code on screen
      console.log(`OTP for ${input.email}: ${code}`);
      return {
        success: true,
        message: "Код отправлен на ваш email (для демо: проверьте консоль сервера)",
        demoCode: code,
      };
    }),

  // Verify OTP and create/login user
  verifyOtp: publicQuery
    .input(
      z.object({
        email: z.string().email(),
        code: z.string().length(6, "Код должен быть 6 цифр"),
        name: z.string().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const otpRecord = await findValidOtpCode(input.email, input.code);
      if (!otpRecord) {
        throw Errors.badRequest("Неверный или истекший код");
      }
      if (otpRecord.expiresAt < new Date()) {
        throw Errors.badRequest("Код истек");
      }

      await markOtpCodeUsed(otpRecord.id);

      let user = await findUserByEmail(input.email);
      if (!user) {
        user = await createUser(input.email, input.name || undefined);
      }
      if (!user) {
        throw Errors.internal("Не удалось создать пользователя");
      }

      const secret = new TextEncoder().encode(env.jwtSecret);
      const token = await new SignJWT({ email: user.email, name: user.name })
        .setProtectedHeader({ alg: "HS256" })
        .setSubject(user.id.toString())
        .setIssuedAt()
        .setExpirationTime("7d")
        .sign(secret);

      return {
        token,
        user: { id: user.id, email: user.email, name: user.name },
      };
    }),

  // Get current user
  me: authedQuery.query(({ ctx }) => {
    return ctx.user;
  }),
});
