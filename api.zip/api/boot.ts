import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { serveStaticFiles } from "./lib/vite";
import { uploadApp } from "./uploadRouter";
import { runMigrations } from "./migrate";

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 100 * 1024 * 1024 }));

// File upload endpoint (must be before tRPC)
app.route("/api/upload", uploadApp);

app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

// Always serve static files and SPA fallback
serveStaticFiles(app);

export default app;

// Auto-start server if not imported (i.e., running directly)
const shouldStart = env.isProduction || process.argv[1]?.includes("boot.js") || process.argv[1]?.includes("boot.ts");
if (shouldStart) {
  try {
    // Run migrations before starting server
    await runMigrations();
    const { serve } = await import("@hono/node-server");
    const port = parseInt(process.env.PORT || "3000", 10);
    serve({ fetch: app.fetch, port });
    console.log("Server running on port", port);
  } catch (err) {
    console.error("Failed to start server:", err);
    process.exit(1);
  }
}
