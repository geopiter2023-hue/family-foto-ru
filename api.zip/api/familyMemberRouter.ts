import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import {
  findFamilyMembersByUser,
  createFamilyMember,
  updateFamilyMember,
  deleteFamilyMember,
} from "./queries/familyAlbum";

const memberColors = [
  "#c9a87c", "#e8927c", "#7cb5e8", "#a3d977",
  "#d4a5e8", "#7ce8d5", "#e8c97c", "#e87cb5",
];

export const familyMemberRouter = createRouter({
  list: authedQuery.query(({ ctx }) =>
    findFamilyMembersByUser(ctx.user.id),
  ),

  create: authedQuery
    .input(
      z.object({
        name: z.string().min(1, "Имя обязательно").max(255),
        email: z.string().email("Неверный email").optional(),
        avatar: z.string().optional(),
        color: z.string().optional(),
      }),
    )
    .mutation(({ ctx, input }) =>
      createFamilyMember({
        userId: ctx.user.id,
        name: input.name,
        email: input.email || null,
        avatar: input.avatar,
        color: input.color || memberColors[Math.floor(Math.random() * memberColors.length)],
      }),
    ),

  update: authedQuery
    .input(
      z.object({
        id: z.number().min(1),
        name: z.string().min(1).max(255).optional(),
        avatar: z.string().optional(),
        color: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      return updateFamilyMember(id, ctx.user.id, data);
    }),

  delete: authedQuery
    .input(z.object({ id: z.number().min(1) }))
    .mutation(async ({ ctx, input }) => {
      await deleteFamilyMember(input.id, ctx.user.id);
      return { success: true };
    }),
});
