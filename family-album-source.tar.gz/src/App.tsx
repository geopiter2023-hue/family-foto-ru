import { Routes, Route, Navigate } from 'react-router'
import { useAuth } from '@/hooks/useAuth'
import Login from '@/pages/Login'
import Dashboard from '@/pages/Dashboard'
import CreateAlbum from '@/pages/CreateAlbum'
import AlbumPage from '@/pages/AlbumPage'
import AdminPage from '@/pages/AdminPage'

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="min-h-screen bg-[#f5efe6] flex items-center justify-center text-[#8a8279]">Загрузка...</div>
  if (!user) return <Navigate to="/login" replace />
  return <>{children}</>
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<AuthGuard><Dashboard /></AuthGuard>} />
      <Route path="/create" element={<AuthGuard><CreateAlbum /></AuthGuard>} />
      <Route path="/album/:id" element={<AuthGuard><AlbumPage /></AuthGuard>} />
      <Route path="/mariana" element={<AdminPage />} />
    </Routes>
  )
}
