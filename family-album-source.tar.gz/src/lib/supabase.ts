import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://your-project.supabase.co";
const SUPABASE_ANON_KEY = "your-anon-key";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export type Album = {
  id: string;
  user_id: string;
  owner_email?: string;
  year: number;
  title: string;
  location?: string;
  description?: string;
  cover_photo?: string;
  album_format?: string;
  cover_type?: "classic" | "color" | "custom";
  cover_color?: string;
  cover_image_url?: string;
  created_at: string;
};

export type Photo = {
  id: string;
  album_id: string;
  url: string;
  caption?: string;
  emotion?: string;
  created_at: string;
};

export type Feedback = {
  id: string;
  rating: number;
  comment?: string;
  created_at: string;
};

export type Notification = {
  id: string;
  user_id: string;
  album_id?: string;
  photo_id?: string;
  message: string;
  read: boolean;
  created_at: string;
};

// Album formats (cm)
export const ALBUM_FORMATS = [
  { label: "45 × 30", value: "45x30" },
  { label: "30 × 30", value: "30x30" },
  { label: "28 × 28", value: "28x28" },
  { label: "25 × 25", value: "25x25" },
  { label: "22 × 30", value: "22x30" },
  { label: "20 × 30", value: "20x30" },
  { label: "23 × 23", value: "23x23" },
  { label: "30 × 20", value: "30x20" },
  { label: "29 × 19", value: "29x19" },
  { label: "18 × 24", value: "18x24" },
  { label: "20 × 20", value: "20x20" },
  { label: "19 × 19", value: "19x19" },
  { label: "15 × 20", value: "15x20" },
  { label: "20 × 15", value: "20x15" },
  { label: "15 × 15", value: "15x15" },
  { label: "8 × 8", value: "8x8" },
];

// Classic covers — solid colors with gold emblem
export const CLASSIC_COVERS = [
  { name: "Бежевый", color: "#C4A882", value: "beige" },
  { name: "Шоколадный", color: "#3E2723", value: "chocolate" },
  { name: "Серо-розовый", color: "#C9A9A0", value: "dusty-rose" },
  { name: "Бирюзовый", color: "#5A9B8E", value: "turquoise" },
  { name: "Светло-коралловый", color: "#D4746A", value: "coral" },
  { name: "Коричневый", color: "#6D4C41", value: "brown" },
  { name: "Синий", color: "#3B6B7A", value: "blue" },
  { name: "Красный", color: "#A94C3D", value: "red" },
  { name: "Серо-зелёный", color: "#6B7B5F", value: "sage" },
  { name: "Бордовый", color: "#5D2A2A", value: "burgundy" },
  { name: "Чёрный", color: "#1A1A1A", value: "black" },
  { name: "Белый", color: "#F5F2ED", value: "white" },
];

// Color covers — floral patterns (CSS-based)
export const COLOR_COVERS = [
  { name: "Color-201", value: "c201", bg: "bg-gradient-to-br from-[#5A9B8E] via-[#6BAFA3] to-[#4A8A7D]" },
  { name: "Color-202", value: "c202", bg: "bg-gradient-to-br from-[#B8B8B8] via-[#D0D0D0] to-[#A8A8A8]" },
  { name: "Color-203", value: "c203", bg: "bg-gradient-to-br from-[#E8C547] via-[#F0D86A] to-[#D4B43A]" },
  { name: "Color-204", value: "c204", bg: "bg-gradient-to-br from-[#E8A8B0] via-[#F0C0C8] to-[#D89098]" },
  { name: "Color-205", value: "c205", bg: "bg-gradient-to-br from-[#C4A882] via-[#D8C0A0] to-[#B09070]" },
  { name: "Color-206", value: "c206", bg: "bg-gradient-to-br from-[#7A9E6E] via-[#8FB080] to-[#6A8E60]" },
  { name: "Color-207", value: "c207", bg: "bg-gradient-to-br from-[#8FA3C0] via-[#A8BBD0] to-[#7A90A8]" },
  { name: "Color-208", value: "c208", bg: "bg-gradient-to-br from-[#D4A06A] via-[#E0B888] to-[#C89050]" },
];
