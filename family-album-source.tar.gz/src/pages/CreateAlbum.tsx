import { useState, useRef } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { supabase, ALBUM_FORMATS, CLASSIC_COVERS, COLOR_COVERS } from "@/lib/supabase";
import {
  ArrowLeft, Upload, ImageIcon, X, Calendar, MapPin, FileText,
  Plus, Loader2, BookOpen, Palette, ImagePlus, Check
} from "lucide-react";
import { Toaster, toast } from "sonner";

type CoverTab = "classic" | "color" | "custom";

export default function CreateAlbum() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState("");
  const [year, setYear] = useState(new Date().getFullYear().toString());
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [albumFormat, setAlbumFormat] = useState("20x30");
  const [coverTab, setCoverTab] = useState<CoverTab>("classic");
  const [selectedClassic, setSelectedClassic] = useState(CLASSIC_COVERS[0].value);
  const [selectedColor, setSelectedColor] = useState(COLOR_COVERS[0].value);
  const [customCover, setCustomCover] = useState<string | null>(null);
  const [customCoverFile, setCustomCoverFile] = useState<File | null>(null);

  const [files, setFiles] = useState<{ file: File; preview: string }[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files;
    if (!selected) return;
    const newFiles = Array.from(selected);
    const withPreview = newFiles.map((file) => ({
      file,
      preview: URL.createObjectURL(file),
    }));
    setFiles((prev) => [...prev, ...withPreview]);
  };

  const removeFile = (idx: number) => {
    setFiles((prev) => {
      URL.revokeObjectURL(prev[idx].preview);
      return prev.filter((_, i) => i !== idx);
    });
  };

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (customCover) URL.revokeObjectURL(customCover);
    const preview = URL.createObjectURL(file);
    setCustomCover(preview);
    setCustomCoverFile(file);
    setCoverTab("custom");
  };

  const getSelectedCoverInfo = () => {
    if (coverTab === "classic") {
      const c = CLASSIC_COVERS.find((x) => x.value === selectedClassic);
      return { type: "classic", color: c?.color, name: c?.name };
    }
    if (coverTab === "color") {
      const c = COLOR_COVERS.find((x) => x.value === selectedColor);
      return { type: "color", bg: c?.bg, name: c?.name };
    }
    return { type: "custom", url: customCover };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) { toast.error("Введите название альбома"); return; }
    if (!year.trim()) { toast.error("Введите год"); return; }
    if (files.length === 0) { toast.error("Добавьте хотя бы одно фото"); return; }

    setUploading(true);
    setProgress(0);

    try {
      // 1. Upload custom cover if needed
      let coverImageUrl: string | null = null;
      if (coverTab === "custom" && customCoverFile) {
        const coverFileName = `covers/${user!.id}/${Date.now()}_${customCoverFile.name.replace(/[^a-zA-Z0-9.]/g, "_")}`;
        const { error: coverUploadError } = await supabase.storage
          .from("photos")
          .upload(coverFileName, customCoverFile, { cacheControl: "3600", upsert: false });
        if (!coverUploadError) {
          const { data: urlData } = supabase.storage.from("photos").getPublicUrl(coverFileName);
          coverImageUrl = urlData.publicUrl;
        }
      }

      // 2. Create album
      const { data: albumData, error: albumError } = await supabase
        .from("albums")
        .insert({
          user_id: user!.id,
          owner_email: user!.email || null,
          title: title.trim(),
          year: parseInt(year),
          location: location.trim() || null,
          description: description.trim() || null,
          album_format: albumFormat,
          cover_type: coverTab,
          cover_color: coverTab === "classic" ? selectedClassic : coverTab === "color" ? selectedColor : null,
          cover_image_url: coverTab === "custom" ? coverImageUrl : null,
        })
        .select()
        .single();

      if (albumError || !albumData) throw albumError || new Error("Не удалось создать альбом");

      const albumId = albumData.id;

      // 3. Upload photos to Storage
      const total = files.length;
      for (let i = 0; i < total; i++) {
        const { file } = files[i];
        const fileName = `${albumId}/${Date.now()}_${i}_${file.name.replace(/[^a-zA-Z0-9.]/g, "_")}`;

        const { error: uploadError } = await supabase.storage
          .from("photos")
          .upload(fileName, file, { cacheControl: "3600", upsert: false });

        if (uploadError) {
          console.error("Upload error:", uploadError);
          continue;
        }

        const { data: urlData } = supabase.storage.from("photos").getPublicUrl(fileName);
        const publicUrl = urlData.publicUrl;

        await supabase.from("photos").insert({
          album_id: albumId,
          url: publicUrl,
        });

        if (i === 0) {
          await supabase.from("albums").update({ cover_photo: publicUrl }).eq("id", albumId);
        }

        setProgress(Math.round(((i + 1) / total) * 100));
      }

      toast.success("Альбом создан!");
      navigate(`/album/${albumId}`);
    } catch (err: any) {
      toast.error(err.message || "Ошибка создания альбома");
    } finally {
      setUploading(false);
    }
  };

  const coverInfo = getSelectedCoverInfo();

  return (
    <div className="min-h-screen bg-[#f5efe6]">
      <Toaster position="top-center" />

      {/* Header */}
      <header className="bg-gradient-to-r from-[#c9a87c] to-[#b8976a]">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <button onClick={() => navigate("/")} className="flex items-center gap-2 text-white/90 hover:text-white">
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm">Назад</span>
          </button>
          <h1 className="text-white font-serif text-lg">Новый альбом</h1>
          <div className="w-16" />
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">

          {/* Album Info */}
          <div className="bg-white rounded-2xl p-6 shadow-sm space-y-4">
            <div>
              <label className="block text-sm font-medium text-[#4a4a4a] mb-2">Название альбома *</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Например: Летний отдых 2024"
                className="w-full px-4 py-3 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">Год *</label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#c9a87c]" />
                  <input
                    type="number"
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    min="1900"
                    max={new Date().getFullYear()}
                    className="w-full pl-10 pr-4 py-3 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                    required
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">Локация</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#c9a87c]" />
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Город, страна"
                    className="w-full pl-10 pr-4 py-3 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#4a4a4a] mb-2">Описание</label>
              <div className="relative">
                <FileText className="absolute left-3 top-3 w-4 h-4 text-[#c9a87c]" />
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Расскажите о событии..."
                  rows={3}
                  className="w-full pl-10 pr-4 py-3 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] resize-none"
                />
              </div>
            </div>
          </div>

          {/* Format Selection */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <label className="block text-sm font-medium text-[#4a4a4a] mb-3">Формат альбома</label>
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
              {ALBUM_FORMATS.map((fmt) => (
                <button
                  key={fmt.value}
                  type="button"
                  onClick={() => setAlbumFormat(fmt.value)}
                  className={`px-2 py-2 rounded-lg text-xs sm:text-sm font-medium border transition-colors ${
                    albumFormat === fmt.value
                      ? "bg-[#c9a87c] text-white border-[#c9a87c]"
                      : "bg-[#f5efe6] text-[#4a4a4a] border-[#e5ddd0] hover:border-[#c9a87c]"
                  }`}
                >
                  {fmt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Cover Selection */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <label className="block text-sm font-medium text-[#4a4a4a] mb-3">Обложка</label>

            {/* Tabs */}
            <div className="flex gap-1 p-1 bg-[#f5efe6] rounded-xl mb-5">
              {([
                { key: "classic", label: "Classic", icon: BookOpen },
                { key: "color", label: "Color", icon: Palette },
                { key: "custom", label: "Своя", icon: ImagePlus },
              ] as const).map((t) => (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => setCoverTab(t.key)}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    coverTab === t.key
                      ? "bg-white text-[#c9a87c] shadow-sm"
                      : "text-[#8a8279] hover:text-[#4a4a4a]"
                  }`}
                >
                  <t.icon className="w-4 h-4" /> {t.label}
                </button>
              ))}
            </div>

            {/* Preview */}
            <div className="mb-5">
              <div
                className={`w-full aspect-[4/3] rounded-xl overflow-hidden relative flex items-center justify-center shadow-md ${
                  coverInfo.type === "classic" && coverInfo.color
                    ? ""
                    : coverInfo.type === "color" && coverInfo.bg
                    ? coverInfo.bg
                    : coverInfo.type === "custom" && coverInfo.url
                    ? ""
                    : "bg-[#e5ddd0]"
                }`}
                style={coverInfo.type === "classic" && coverInfo.color ? { backgroundColor: coverInfo.color } : undefined}
              >
                {coverInfo.type === "custom" && coverInfo.url ? (
                  <img src={coverInfo.url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <>
                    <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPjxyZWN0IHdpZHRoPSI0IiBoZWlnaHQ9IjQiIGZpbGw9Im5vbmUiLz48cGF0aCBkPSJNMCw0IEw0LDAiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjA4KSIgc3Ryb2tlLXdpZHRoPSIwLjUiLz48L3N2Zz4=')] opacity-50" />
                    <svg className="w-16 h-16 text-[#c9a87c]/80" viewBox="0 0 64 64" fill="currentColor">
                      <path d="M32 4c-2.5 0-4.8 1.2-6.2 3.1-1.6 2.2-3.8 3.8-6.4 4.3-3.2.6-5.8 2.8-7 5.8-1 2.6-.7 5.6.8 8 1.8 2.8 2.2 6.3 1 9.4-1.4 3.4-.8 7.3 1.6 10.2 2.2 2.6 5.6 3.8 8.9 3.1 3.3-.7 6.8.4 9.2 2.8 1.6 1.6 3.8 2.5 6.1 2.5s4.5-.9 6.1-2.5c2.4-2.4 5.9-3.5 9.2-2.8 3.3.7 6.7-.5 8.9-3.1 2.4-2.9 3-6.8 1.6-10.2-1.2-3.1-.8-6.6 1-9.4 1.5-2.4 1.8-5.4.8-8-1.2-3-3.8-5.2-7-5.8-2.6-.5-4.8-2.1-6.4-4.3C36.8 5.2 34.5 4 32 4zm0 8c1.4 0 2.7.7 3.5 1.9 1.1 1.6 2.7 2.7 4.6 3.1 1.7.3 3.1 1.5 3.8 3.1.5 1.3.3 2.8-.5 4-.9 1.4-1.1 3.1-.5 4.7.7 1.7.4 3.7-.7 5.1-.9 1.1-2.3 1.6-3.7 1.3-1.7-.4-3.5.1-4.9 1.3-.9.8-2.1 1.2-3.3 1.2s-2.4-.4-3.3-1.2c-1.4-1.2-3.2-1.7-4.9-1.3-1.4.3-2.8-.2-3.7-1.3-1.1-1.4-1.4-3.4-.7-5.1.6-1.6.4-3.3-.5-4.7-.8-1.2-1-2.7-.5-4 .7-1.6 2.1-2.8 3.8-3.1 1.9-.4 3.5-1.5 4.6-3.1.8-1.2 2.1-1.9 3.5-1.9z" />
                    </svg>
                  </>
                )}
              </div>
            </div>

            {/* Tab Content */}
            {coverTab === "classic" && (
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                {CLASSIC_COVERS.map((c) => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => setSelectedClassic(c.value)}
                    className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all ${
                      selectedClassic === c.value ? "border-[#c9a87c] shadow-lg scale-105" : "border-transparent"
                    }`}
                    style={{ backgroundColor: c.color }}
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg className="w-6 h-6 text-[#c9a87c]/70" viewBox="0 0 64 64" fill="currentColor">
                        <path d="M32 4c-2.5 0-4.8 1.2-6.2 3.1-1.6 2.2-3.8 3.8-6.4 4.3-3.2.6-5.8 2.8-7 5.8-1 2.6-.7 5.6.8 8 1.8 2.8 2.2 6.3 1 9.4-1.4 3.4-.8 7.3 1.6 10.2 2.2 2.6 5.6 3.8 8.9 3.1 3.3-.7 6.8.4 9.2 2.8 1.6 1.6 3.8 2.5 6.1 2.5s4.5-.9 6.1-2.5c2.4-2.4 5.9-3.5 9.2-2.8 3.3.7 6.7-.5 8.9-3.1 2.4-2.9 3-6.8 1.6-10.2-1.2-3.1-.8-6.6 1-9.4 1.5-2.4 1.8-5.4.8-8-1.2-3-3.8-5.2-7-5.8-2.6-.5-4.8-2.1-6.4-4.3C36.8 5.2 34.5 4 32 4z" />
                      </svg>
                    </div>
                    {selectedClassic === c.value && (
                      <div className="absolute top-1 right-1 w-5 h-5 bg-[#c9a87c] rounded-full flex items-center justify-center">
                        <Check className="w-3 h-3 text-white" />
                      </div>
                    )}
                    <span className="absolute bottom-0 left-0 right-0 bg-black/40 text-white text-[10px] text-center py-0.5 truncate px-1">
                      {c.name}
                    </span>
                  </button>
                ))}
              </div>
            )}

            {coverTab === "color" && (
              <div className="grid grid-cols-4 sm:grid-cols-4 gap-3">
                {COLOR_COVERS.map((c) => (
                  <button
                    key={c.value}
                    type="button"
                    onClick={() => setSelectedColor(c.value)}
                    className={`relative aspect-[3/4] rounded-xl overflow-hidden border-2 transition-all ${
                      selectedColor === c.value ? "border-[#c9a87c] shadow-lg scale-105" : "border-transparent"
                    } ${c.bg}`}
                  >
                    <div className="absolute inset-0 flex items-center justify-center">
                      <svg className="w-6 h-6 text-white/40" viewBox="0 0 64 64" fill="currentColor">
                        <path d="M32 4c-2.5 0-4.8 1.2-6.2 3.1-1.6 2.2-3.8 3.8-6.4 4.3-3.2.6-5.8 2.8-7 5.8-1 2.6-.7 5.6.8 8 1.8 2.8 2.2 6.3 1 9.4-1.4 3.4-.8 7.3 1.6 10.2 2.2 2.6 5.6 3.8 8.9 3.1 3.3-.7 6.8.4 9.2 2.8 1.6 1.6 3.8 2.5 6.1 2.5s4.5-.9 6.1-2.5c2.4-2.4 5.9-3.5 9.2-2.8 3.3.7 6.7-.5 8.9-3.1 2.4-2.9 3-6.8 1.6-10.2-1.2-3.1-.8-6.6 1-9.4 1.5-2.4 1.8-5.4.8-8-1.2-3-3.8-5.2-7-5.8-2.6-.5-4.8-2.1-6.4-4.3C36.8 5.2 34.5 4 32 4z" />
                      </svg>
                    </div>
                    {selectedColor === c.value && (
                      <div className="absolute top-1 right-1 w-5 h-5 bg-[#c9a87c] rounded-full flex items-center justify-center">
                        <Check className="w-3 h-3 text-white" />
                      </div>
                    )}
                    <span className="absolute bottom-0 left-0 right-0 bg-black/40 text-white text-[10px] text-center py-0.5 truncate px-1">
                      {c.name}
                    </span>
                  </button>
                ))}
              </div>
            )}

            {coverTab === "custom" && (
              <div className="text-center">
                <input
                  ref={coverInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleCoverUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => coverInputRef.current?.click()}
                  className="w-full border-2 border-dashed border-[#c9a87c]/40 rounded-2xl p-8 text-center hover:border-[#c9a87c] hover:bg-[#f5efe6]/50 transition-colors"
                >
                  <ImagePlus className="w-8 h-8 text-[#c9a87c]/50 mx-auto mb-2" />
                  <p className="text-sm text-[#4a4a4a]">Загрузить свою обложку</p>
                  <p className="text-xs text-[#8a8279] mt-1">JPG, PNG до 5 МБ</p>
                </button>
              </div>
            )}
          </div>

          {/* Photo Upload */}
          <div className="bg-white rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <label className="block text-sm font-medium text-[#4a4a4a]">Фотографии *</label>
              <span className="text-xs text-[#8a8279]">{files.length} / 50</span>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />

            {files.length === 0 ? (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full border-2 border-dashed border-[#c9a87c]/40 rounded-2xl p-10 text-center hover:border-[#c9a87c] hover:bg-[#f5efe6]/50 transition-colors"
              >
                <Upload className="w-10 h-10 text-[#c9a87c]/50 mx-auto mb-3" />
                <p className="text-[#4a4a4a] font-medium">Нажмите или перетащите фото сюда</p>
                <p className="text-[#8a8279] text-sm mt-1">JPG, PNG до 10 МБ каждое</p>
              </button>
            ) : (
              <>
                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 mb-4">
                  {files.map((f, idx) => (
                    <div key={idx} className="aspect-square rounded-xl overflow-hidden relative group bg-[#e5ddd0]">
                      <img src={f.preview} alt="" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => removeFile(idx)}
                        className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  {files.length < 50 && (
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="aspect-square border-2 border-dashed border-[#c9a87c]/40 rounded-xl flex items-center justify-center hover:border-[#c9a87c] hover:bg-[#f5efe6]/50 transition-colors"
                    >
                      <Plus className="w-6 h-6 text-[#c9a87c]" />
                    </button>
                  )}
                </div>
                {files.length < 50 && (
                  <p className="text-xs text-[#8a8279] text-center">
                    Нажмите + чтобы добавить ещё (макс. 50)
                  </p>
                )}
              </>
            )}
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={uploading}
            className="w-full bg-[#c9a87c] text-white py-4 rounded-xl font-medium hover:bg-[#b8976a] transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
          >
            {uploading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Создание альбома... {progress}%
              </>
            ) : (
              <>
                <ImageIcon className="w-5 h-5" />
                Создать альбом
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
