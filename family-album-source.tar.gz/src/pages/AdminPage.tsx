import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { supabase, type Album, type Photo, type Notification } from "@/lib/supabase";
import {
  ArrowLeft, ImageIcon, Star, MessageSquare, Trash2,
  BarChart3, Calendar, Bell
} from "lucide-react";
import { Toaster, toast } from "sonner";

interface Feedback {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
}

export default function AdminPage() {
  const navigate = useNavigate();
  const [albums, setAlbums] = useState<Album[]>([]);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [feedback, setFeedback] = useState<Feedback[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [password, setPassword] = useState("");
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    if (authenticated) loadData();
  }, [authenticated]);

  async function loadData() {
    const [{ data: albumsData }, { data: photosData }, { data: feedbackData }, { data: notifData }] = await Promise.all([
      supabase.from("albums").select("*").order("created_at", { ascending: false }),
      supabase.from("photos").select("*"),
      supabase.from("feedback").select("*").order("created_at", { ascending: false }),
      supabase.from("notifications").select("*").eq("read", false).order("created_at", { ascending: false }),
    ]);
    if (albumsData) setAlbums(albumsData);
    if (photosData) setPhotos(photosData);
    if (feedbackData) setFeedback(feedbackData);
    if (notifData) setNotifications(notifData);
    setLoading(false);
  }

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "mariana2024") {
      setAuthenticated(true);
    } else {
      toast.error("Неверный пароль");
    }
  };

  const deleteAlbum = async (id: string) => {
    if (!confirm("Удалить альбом и все фото?")) return;
    // Get album owner before delete
    const { data: albumData } = await supabase.from("albums").select("user_id, title").eq("id", id).single();
    const { data: albumPhotos } = await supabase.from("photos").select("url").eq("album_id", id);
    if (albumPhotos) {
      for (const p of albumPhotos) {
        const path = p.url.split("/photos/").pop();
        if (path) await supabase.storage.from("photos").remove([path]);
      }
    }
    await supabase.from("photos").delete().eq("album_id", id);
    await supabase.from("albums").delete().eq("id", id);
    // Notify owner
    if (albumData) {
      await supabase.from("notifications").insert({
        user_id: albumData.user_id,
        album_id: id,
        message: `Альбом "${albumData.title}" был удалён администратором`,
      });
    }
    toast.success("Альбом удалён");
    loadData();
  };

  const avgRating = feedback.length > 0
    ? (feedback.reduce((s, f) => s + f.rating, 0) / feedback.length).toFixed(1)
    : "0";

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-[#f5efe6] flex items-center justify-center p-4">
        <div className="w-full max-w-sm">
          <div className="text-center mb-6">
            <BarChart3 className="w-12 h-12 text-[#c9a87c] mx-auto mb-3" />
            <h1 className="text-2xl font-serif text-[#6B4226]">Админ-панель</h1>
          </div>
          <form onSubmit={handleLogin} className="bg-white rounded-2xl shadow-lg p-6 space-y-4">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Пароль"
              className="w-full px-4 py-3 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
              autoFocus
            />
            <button
              type="submit"
              className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium hover:bg-[#b8976a] transition-colors"
            >
              Войти
            </button>
            <button
              type="button"
              onClick={() => navigate("/")}
              className="w-full text-[#8a8279] text-sm hover:text-[#c9a87c] py-2"
            >
              На главную
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f5efe6] flex items-center justify-center text-[#8a8279]">
        Загрузка...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f5efe6]">
      <Toaster position="top-center" />

      {/* Header */}
      <header className="bg-gradient-to-r from-[#c9a87c] to-[#b8976a]">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <button onClick={() => navigate("/")} className="flex items-center gap-2 text-white/90 hover:text-white">
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm">Назад</span>
          </button>
          <h1 className="text-white font-serif text-lg">Админ-панель</h1>
          <div className="w-16" />
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <AlbumsIcon className="w-5 h-5 text-[#c9a87c]" />
              <span className="text-sm text-[#8a8279]">Альбомы</span>
            </div>
            <p className="text-2xl font-bold text-[#4a4a4a]">{albums.length}</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <ImageIcon className="w-5 h-5 text-[#c9a87c]" />
              <span className="text-sm text-[#8a8279]">Фото</span>
            </div>
            <p className="text-2xl font-bold text-[#4a4a4a]">{photos.length}</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <Star className="w-5 h-5 text-yellow-400" />
              <span className="text-sm text-[#8a8279]">Средняя оценка</span>
            </div>
            <p className="text-2xl font-bold text-[#4a4a4a]">{avgRating}</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="w-5 h-5 text-[#c9a87c]" />
              <span className="text-sm text-[#8a8279]">Отзывы</span>
            </div>
            <p className="text-2xl font-bold text-[#4a4a4a]">{feedback.length}</p>
          </div>
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <Bell className="w-5 h-5 text-red-400" />
              <span className="text-sm text-[#8a8279]">Уведомления</span>
            </div>
            <p className="text-2xl font-bold text-[#4a4a4a]">{notifications.length}</p>
          </div>
        </div>

        {/* Notifications */}
        {notifications.length > 0 && (
          <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-[#e5ddd0] flex items-center justify-between">
              <h2 className="font-serif text-lg text-[#4a4a4a]">Новые уведомления</h2>
              <button
                onClick={async () => {
                  await supabase.from("notifications").update({ read: true }).eq("read", false);
                  toast.success("Все уведомления прочитаны");
                  loadData();
                }}
                className="text-xs text-[#c9a87c] hover:underline"
              >
                Прочитать все
              </button>
            </div>
            <div className="divide-y divide-[#e5ddd0]">
              {notifications.map((n) => (
                <div key={n.id} className="px-5 py-4 hover:bg-[#f5efe6]/50 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-400 rounded-full mt-2 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm text-[#4a4a4a]">{n.message}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-xs text-[#8a8279]">
                          {new Date(n.created_at).toLocaleDateString("ru-RU", {
                            day: "numeric",
                            month: "short",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                        {n.album_id && (
                          <button
                            onClick={() => navigate(`/album/${n.album_id}`)}
                            className="text-xs text-[#c9a87c] hover:underline"
                          >
                            Перейти к альбому
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Albums List */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[#e5ddd0] flex items-center justify-between">
            <h2 className="font-serif text-lg text-[#4a4a4a]">Все альбомы</h2>
          </div>
          {albums.length === 0 ? (
            <div className="p-8 text-center text-[#8a8279]">Нет альбомов</div>
          ) : (
            <div className="divide-y divide-[#e5ddd0]">
              {albums.map((album) => (
                <div key={album.id} className="px-5 py-4 flex items-center gap-4 hover:bg-[#f5efe6]/50 transition-colors">
                  <div
                    className="w-14 h-14 rounded-xl bg-[#e5ddd0] overflow-hidden flex-shrink-0 cursor-pointer"
                    onClick={() => navigate(`/album/${album.id}`)}
                  >
                    {album.cover_photo ? (
                      <img src={album.cover_photo} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <ImageIcon className="w-5 h-5 text-[#b8a088]" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3
                      className="font-medium text-[#4a4a4a] truncate cursor-pointer hover:text-[#c9a87c]"
                      onClick={() => navigate(`/album/${album.id}`)}
                    >
                      {album.title}
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-[#8a8279] mt-0.5">
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {album.year}</span>
                      <span>{photos.filter((p) => p.album_id === album.id).length} фото</span>
                    </div>
                  </div>
                  <button
                    onClick={() => deleteAlbum(album.id)}
                    className="p-2 text-red-400 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Feedback */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-[#e5ddd0]">
            <h2 className="font-serif text-lg text-[#4a4a4a]">Отзывы и оценки</h2>
          </div>
          {feedback.length === 0 ? (
            <div className="p-8 text-center text-[#8a8279]">Нет отзывов</div>
          ) : (
            <div className="divide-y divide-[#e5ddd0]">
              {feedback.map((f) => (
                <div key={f.id} className="px-5 py-4">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          className={`w-4 h-4 ${s <= f.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-[#8a8279]">
                      {new Date(f.created_at).toLocaleDateString("ru-RU")}
                    </span>
                  </div>
                  {f.comment && <p className="text-sm text-[#4a4a4a]">{f.comment}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AlbumsIcon(props: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={props.className}
    >
      <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
      <line x1="3" x2="21" y1="9" y2="9" />
      <line x1="9" x2="9" y1="21" y2="9" />
    </svg>
  );
}
