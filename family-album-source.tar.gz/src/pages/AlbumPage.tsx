import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { supabase, type Album, type Photo, CLASSIC_COVERS, COLOR_COVERS } from "@/lib/supabase";
import {
  ArrowLeft, Calendar, MapPin, ImageIcon, ChevronLeft, ChevronRight,
  X, Download, Trash2, MessageCircle, Play, Square, FolderDown, Loader2,
  Share2, Printer, Link, Check, Send
} from "lucide-react";
import { Toaster, toast } from "sonner";

export default function AlbumPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [album, setAlbum] = useState<Album | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [slideshow, setSlideshow] = useState(false);
  const [captionText, setCaptionText] = useState("");
  const slideshowTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const [displayCount, setDisplayCount] = useState(30);
  const [isAdmin, setIsAdmin] = useState(false);
  const [downloadingAll, setDownloadingAll] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  useEffect(() => {
    if (user?.email === "mariana" || user?.email?.includes("admin")) {
      setIsAdmin(true);
    }
  }, [user]);

  async function loadAlbum() {
    if (!id) return;
    const { data: albumData } = await supabase.from("albums").select("*").eq("id", id).single();
    const { data: photosData } = await supabase.from("photos").select("*").eq("album_id", id).order("created_at", { ascending: true });
    if (albumData) setAlbum(albumData);
    if (photosData) setPhotos(photosData);
    setLoading(false);
  }

  useEffect(() => {
    loadAlbum();
  }, [id]);

  useEffect(() => {
    if (slideshow && selectedIdx !== null) {
      slideshowTimer.current = setInterval(() => {
        setSelectedIdx((prev) => (prev !== null ? (prev + 1) % photos.length : 0));
      }, 3000);
    }
    return () => {
      if (slideshowTimer.current) clearInterval(slideshowTimer.current);
    };
  }, [slideshow, selectedIdx, photos.length]);

  const albumUrl = typeof window !== "undefined" ? `${window.location.origin}/#/album/${id}` : "";

  const handleShare = (type: "telegram" | "whatsapp" | "vk" | "copy") => {
    const text = `Посмотрите альбом "${album?.title}"!`;
    const url = albumUrl;
    if (type === "telegram") {
      window.open(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`, "_blank");
    } else if (type === "whatsapp") {
      window.open(`https://wa.me/?text=${encodeURIComponent(text + " " + url)}`, "_blank");
    } else if (type === "vk") {
      window.open(`https://vk.com/share.php?url=${encodeURIComponent(url)}`, "_blank");
    } else if (type === "copy") {
      navigator.clipboard.writeText(url).then(() => {
        setLinkCopied(true);
        toast.success("Ссылка скопирована!");
        setTimeout(() => setLinkCopied(false), 2000);
      });
    }
  };

  const handlePrintOrder = () => {
    toast("Функция печати в разработке. Скоро вы сможете заказать печать альбома!", {
      duration: 5000,
      icon: "🖨️",
    });
  };

  const downloadPhotoUrl = useCallback(async (url: string, filename: string) => {
    try {
      const response = await fetch(url, { mode: "cors" });
      if (!response.ok) throw new Error("fetch failed");
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(blobUrl);
      return true;
    } catch {
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      return false;
    }
  }, []);

  const handleDownload = useCallback(async () => {
    if (selectedIdx === null) return;
    const photo = photos[selectedIdx];
    const ext = photo.url.split("?")[0].split(".").pop() || "jpg";
    const filename = `${album?.title || "photo"}_${selectedIdx + 1}.${ext}`;
    const ok = await downloadPhotoUrl(photo.url, filename);
    if (ok) {
      toast.success("Фото скачано");
    } else {
      toast("Фото открыто в новой вкладке — нажмите ПКМ → 'Сохранить как'", { duration: 4000 });
    }
  }, [selectedIdx, photos, album, downloadPhotoUrl]);

  const handleDownloadSingle = useCallback(async (photo: Photo, idx: number) => {
    const ext = photo.url.split("?")[0].split(".").pop() || "jpg";
    const filename = `${album?.title || "photo"}_${idx + 1}.${ext}`;
    const ok = await downloadPhotoUrl(photo.url, filename);
    if (ok) {
      toast.success("Фото скачано");
    } else {
      toast("Фото открыто в новой вкладке — нажмите ПКМ → 'Сохранить как'", { duration: 4000 });
    }
  }, [album, downloadPhotoUrl]);

  const handleDownloadAll = useCallback(async () => {
    if (photos.length === 0) return;
    setDownloadingAll(true);
    toast.loading(`Скачивание ${photos.length} фото...`);
    let success = 0;
    for (let i = 0; i < photos.length; i++) {
      const photo = photos[i];
      const ext = photo.url.split("?")[0].split(".").pop() || "jpg";
      const filename = `${album?.title || "album"}_${i + 1}.${ext}`;
      const ok = await downloadPhotoUrl(photo.url, filename);
      if (ok) success++;
      await new Promise((r) => setTimeout(r, 300));
    }
    toast.dismiss();
    if (success === photos.length) {
      toast.success(`Все ${photos.length} фото скачаны!`);
    } else if (success > 0) {
      toast.success(`Скачано ${success} из ${photos.length} фото. Остальные открыты в новых вкладках.`);
    } else {
      toast("Фото открыты в новых вкладках — нажмите ПКМ → 'Сохранить как'", { duration: 5000 });
    }
    setDownloadingAll(false);
  }, [photos, album, downloadPhotoUrl]);

  const isAlbumOwner = user?.id === album?.user_id;
  const canDelete = isAdmin || isAlbumOwner;

  const handleDeletePhoto = async (photoId: string) => {
    if (!canDelete) {
      toast.error("Только владелец альбома может удалять фото");
      return;
    }
    if (!confirm("Удалить фото?")) return;
    if (album && user?.id !== album.user_id) {
      await supabase.from("notifications").insert({
        user_id: album.user_id,
        album_id: album.id,
        photo_id: photoId,
        message: `Администратор удалил фото из вашего альбома "${album.title}"`,
      });
    }
    await supabase.from("photos").delete().eq("id", photoId);
    toast.success("Фото удалено");
    setSelectedIdx(null);
    loadAlbum();
  };

  const handleAddCaption = async () => {
    if (selectedIdx === null || !captionText.trim()) return;
    const photo = photos[selectedIdx];
    await supabase.from("photos").update({ caption: captionText.trim() }).eq("id", photo.id);
    toast.success("Комментарий добавлен");
    setCaptionText("");
    loadAlbum();
  };

  const handleExportPDF = async () => {
    if (!album || photos.length === 0) return;
    toast.loading("Создание PDF...");
    try {
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF("p", "mm", "a4");
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();

      doc.setFillColor(245, 239, 230);
      doc.rect(0, 0, pageWidth, pageHeight, "F");
      doc.setTextColor(107, 66, 38);
      doc.setFontSize(28);
      doc.text(album.title, pageWidth / 2, 80, { align: "center" });
      doc.setFontSize(14);
      doc.text(`${album.year}`, pageWidth / 2, 100, { align: "center" });
      if (album.location) {
        doc.text(`${album.location}`, pageWidth / 2, 115, { align: "center" });
      }
      if (album.album_format) {
        doc.setFontSize(11);
        doc.text(`Формат: ${album.album_format}`, pageWidth / 2, 130, { align: "center" });
      }
      doc.setFontSize(10);
      doc.setTextColor(138, 130, 121);
      doc.text(`family-foto.ru`, pageWidth / 2, pageHeight - 30, { align: "center" });

      for (let i = 0; i < Math.min(photos.length, 50); i++) {
        doc.addPage();
        doc.setFillColor(250, 248, 245);
        doc.rect(0, 0, pageWidth, pageHeight, "F");
        try {
          const img = await loadImage(photos[i].url);
          const imgRatio = img.width / img.height;
          const maxW = pageWidth - 30;
          const maxH = pageHeight - 60;
          let w = maxW, h = w / imgRatio;
          if (h > maxH) { h = maxH; w = h * imgRatio; }
          const x = (pageWidth - w) / 2;
          const y = 25;
          doc.addImage(img.data, "JPEG", x, y, w, h);
          if (photos[i].caption) {
            doc.setTextColor(74, 74, 74);
            doc.setFontSize(11);
            doc.text(photos[i].caption!, pageWidth / 2, y + h + 12, { align: "center" });
          }
          doc.setTextColor(180, 170, 160);
          doc.setFontSize(9);
          doc.text(`${i + 1} / ${photos.length}`, pageWidth / 2, pageHeight - 15, { align: "center" });
        } catch {
          doc.setTextColor(180, 170, 160);
          doc.setFontSize(12);
          doc.text("Не удалось загрузить фото", pageWidth / 2, pageHeight / 2, { align: "center" });
        }
      }

      doc.addPage();
      doc.setFillColor(245, 239, 230);
      doc.rect(0, 0, pageWidth, pageHeight, "F");
      doc.setTextColor(107, 66, 38);
      doc.setFontSize(22);
      doc.text("Спасибо за просмотр!", pageWidth / 2, pageHeight / 2 - 20, { align: "center" });
      doc.setFontSize(12);
      doc.setTextColor(138, 130, 121);
      doc.text("Создайте свой альбом на", pageWidth / 2, pageHeight / 2 + 10, { align: "center" });
      doc.setTextColor(201, 168, 124);
      doc.text("family-foto.ru", pageWidth / 2, pageHeight / 2 + 25, { align: "center" });

      doc.save(`${album.title}_${album.year}.pdf`);
      toast.dismiss();
      toast.success("PDF готов!");
    } catch {
      toast.dismiss();
      toast.error("Ошибка создания PDF");
    }
  };

  const getCoverStyle = () => {
    if (!album) return {};
    if (album.cover_type === "classic" && album.cover_color) {
      const c = CLASSIC_COVERS.find((x) => x.value === album.cover_color);
      return { backgroundColor: c?.color || "#C4A882" };
    }
    if (album.cover_type === "custom" && album.cover_image_url) {
      return { backgroundImage: `url(${album.cover_image_url})`, backgroundSize: "cover", backgroundPosition: "center" };
    }
    return { backgroundColor: "#e5ddd0" };
  };

  const getCoverBgClass = () => {
    if (!album) return "";
    if (album.cover_type === "color" && album.cover_color) {
      const c = COLOR_COVERS.find((x) => x.value === album.cover_color);
      return c?.bg || "bg-[#e5ddd0]";
    }
    return "";
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f5efe6] flex items-center justify-center">
        <div className="text-[#8a8279]">Загрузка альбома...</div>
      </div>
    );
  }

  if (!album) {
    return (
      <div className="min-h-screen bg-[#f5efe6] flex flex-col items-center justify-center gap-4">
        <p className="text-[#8a8279]">Альбом не найден</p>
        <button onClick={() => navigate("/")} className="text-[#c9a87c] hover:underline">На главную</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f5efe6]">
      <Toaster position="top-center" />

      {/* Header */}
      <header className="bg-gradient-to-r from-[#c9a87c] to-[#b8976a] sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <button onClick={() => navigate("/")} className="flex items-center gap-2 text-white/90 hover:text-white">
            <ArrowLeft className="w-5 h-5" />
            <span className="text-sm hidden sm:inline">Назад</span>
          </button>
          <div className="text-center px-2">
            <h1 className="text-white font-serif text-base sm:text-lg truncate max-w-[150px] sm:max-w-md">{album.title}</h1>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => setShareOpen(true)}
              className="p-2 bg-white/90 rounded-xl text-[#c9a87c] hover:bg-white transition-colors"
              title="Поделиться"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <button
              onClick={handleDownloadAll}
              disabled={downloadingAll || photos.length === 0}
              className="p-2 bg-white/90 rounded-xl text-[#c9a87c] hover:bg-white disabled:opacity-50 transition-colors"
              title="Скачать все фото"
            >
              {downloadingAll ? <Loader2 className="w-4 h-4 animate-spin" /> : <FolderDown className="w-4 h-4" />}
            </button>
            <button onClick={handleExportPDF} className="p-2 bg-white/90 rounded-xl text-[#c9a87c] hover:bg-white transition-colors" title="Экспорт PDF">
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Cover Preview */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 shadow-sm mb-6">
          <div className="flex flex-col md:flex-row gap-5">
            {/* Cover Book */}
            <div className="flex-shrink-0 mx-auto md:mx-0">
              <div
                className={`w-40 h-56 rounded-r-xl rounded-l-md shadow-lg relative overflow-hidden flex items-center justify-center ${getCoverBgClass()}`}
                style={getCoverStyle()}
              >
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPjxyZWN0IHdpZHRoPSI0IiBoZWlnaHQ9IjQiIGZpbGw9Im5vbmUiLz48cGF0aCBkPSJNMCw0IEw0LDAiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjA4KSIgc3Ryb2tlLXdpZHRoPSIwLjUiLz48L3N2Zz4=')] opacity-50" />
                <svg className="w-10 h-10 text-[#c9a87c]/80 relative z-10" viewBox="0 0 64 64" fill="currentColor">
                  <path d="M32 4c-2.5 0-4.8 1.2-6.2 3.1-1.6 2.2-3.8 3.8-6.4 4.3-3.2.6-5.8 2.8-7 5.8-1 2.6-.7 5.6.8 8 1.8 2.8 2.2 6.3 1 9.4-1.4 3.4-.8 7.3 1.6 10.2 2.2 2.6 5.6 3.8 8.9 3.1 3.3-.7 6.8.4 9.2 2.8 1.6 1.6 3.8 2.5 6.1 2.5s4.5-.9 6.1-2.5c2.4-2.4 5.9-3.5 9.2-2.8 3.3.7 6.7-.5 8.9-3.1 2.4-2.9 3-6.8 1.6-10.2-1.2-3.1-.8-6.6 1-9.4 1.5-2.4 1.8-5.4.8-8-1.2-3-3.8-5.2-7-5.8-2.6-.5-4.8-2.1-6.4-4.3C36.8 5.2 34.5 4 32 4z" />
                </svg>
                {/* Spine */}
                <div className="absolute left-0 top-0 bottom-0 w-2 bg-black/10 rounded-l-md" />
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 text-center md:text-left">
              <h2 className="font-serif text-xl text-[#4a4a4a] mb-2">{album.title}</h2>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 text-sm text-[#8a8279]">
                <span className="flex items-center gap-1"><Calendar className="w-4 h-4 text-[#c9a87c]" /> {album.year}</span>
                {album.location && <span className="flex items-center gap-1"><MapPin className="w-4 h-4 text-[#c9a87c]" /> {album.location}</span>}
                <span className="flex items-center gap-1"><ImageIcon className="w-4 h-4 text-[#c9a87c]" /> {photos.length} фото</span>
                {album.album_format && (
                  <span className="flex items-center gap-1 bg-[#f5efe6] px-2 py-0.5 rounded-lg text-xs font-medium">
                    {album.album_format.replace("x", " × ")} см
                  </span>
                )}
              </div>
              {album.description && <p className="text-[#4a4a4a] mt-3 text-sm">{album.description}</p>}

              {/* Action buttons */}
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mt-4">
                <button
                  onClick={() => setShareOpen(true)}
                  className="flex items-center gap-1.5 px-4 py-2 bg-[#f5efe6] text-[#4a4a4a] rounded-xl text-sm hover:bg-[#ebe3d5] transition-colors"
                >
                  <Share2 className="w-4 h-4 text-[#c9a87c]" /> Поделиться
                </button>
                <button
                  onClick={handlePrintOrder}
                  className="flex items-center gap-1.5 px-4 py-2 bg-[#c9a87c] text-white rounded-xl text-sm hover:bg-[#b8976a] transition-colors"
                >
                  <Printer className="w-4 h-4" /> Заказать печать
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Photos Grid */}
        {photos.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center">
            <ImageIcon className="w-16 h-16 text-[#c9a87c]/30 mx-auto mb-4" />
            <p className="text-[#8a8279]">В этом альбоме пока нет фото</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {photos.slice(0, displayCount).map((photo, idx) => (
                <div
                  key={photo.id}
                  className="aspect-square bg-[#e5ddd0] rounded-xl overflow-hidden cursor-pointer group relative"
                  onClick={() => { setSelectedIdx(idx); setSlideshow(false); }}
                >
                  <img src={photo.url} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                  {photo.caption && (
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2">
                      <p className="text-white text-xs truncate">{photo.caption}</p>
                    </div>
                  )}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownloadSingle(photo, idx);
                    }}
                    className="absolute top-2 right-2 p-2 bg-black/50 hover:bg-black/70 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10"
                    title="Скачать фото"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
            {photos.length > displayCount && (
              <div className="mt-6 text-center">
                <button
                  onClick={() => setDisplayCount((prev) => prev + 30)}
                  className="px-6 py-3 bg-white text-[#c9a87c] border border-[#c9a87c]/30 rounded-xl hover:bg-[#f5efe6] transition-colors text-sm font-medium"
                >
                  Показать ещё 30 фото ({photos.length - displayCount} осталось)
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Lightbox */}
      {selectedIdx !== null && (
        <div className="fixed inset-0 bg-black/95 z-50 flex flex-col">
          <div className="flex items-center justify-between px-4 py-3">
            <span className="text-white/70 text-sm">{selectedIdx + 1} / {photos.length}</span>
            <div className="flex items-center gap-2">
              <button onClick={() => setSlideshow(!slideshow)} className="p-2 text-white/70 hover:text-white rounded-lg hover:bg-white/10">
                {slideshow ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <button onClick={handleDownload} className="p-2 text-white/70 hover:text-white rounded-lg hover:bg-white/10" title="Скачать фото">
                <Download className="w-4 h-4" />
              </button>
              {canDelete && (
                <button onClick={() => handleDeletePhoto(photos[selectedIdx].id)} className="p-2 text-red-400 hover:text-red-300 rounded-lg hover:bg-white/10">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button onClick={() => { setSelectedIdx(null); setSlideshow(false); }} className="p-2 text-white/70 hover:text-white rounded-lg hover:bg-white/10">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="flex-1 flex items-center justify-center relative px-4">
            <button
              onClick={() => { setSlideshow(false); setSelectedIdx(selectedIdx > 0 ? selectedIdx - 1 : photos.length - 1); }}
              className="absolute left-2 md:left-4 p-2 text-white/50 hover:text-white hover:bg-white/10 rounded-full z-10"
            >
              <ChevronLeft className="w-6 h-6 md:w-8 md:h-8" />
            </button>
            <img
              src={photos[selectedIdx]?.url}
              alt=""
              className="max-h-full max-w-full object-contain rounded-lg"
            />
            <button
              onClick={() => { setSlideshow(false); setSelectedIdx(selectedIdx < photos.length - 1 ? selectedIdx + 1 : 0); }}
              className="absolute right-2 md:right-4 p-2 text-white/50 hover:text-white hover:bg-white/10 rounded-full z-10"
            >
              <ChevronRight className="w-6 h-6 md:w-8 md:h-8" />
            </button>
          </div>

          <div className="px-4 py-3 bg-black/50">
            {photos[selectedIdx]?.caption && (
              <p className="text-white/80 text-sm text-center mb-2">{photos[selectedIdx].caption}</p>
            )}
            <div className="flex gap-2 max-w-md mx-auto">
              <input
                type="text"
                value={captionText}
                onChange={(e) => setCaptionText(e.target.value)}
                placeholder="Добавить комментарий..."
                className="flex-1 px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white text-sm placeholder:text-white/40 focus:outline-none focus:ring-1 focus:ring-[#c9a87c]"
                onKeyDown={(e) => e.key === "Enter" && handleAddCaption()}
              />
              <button onClick={handleAddCaption} className="px-3 py-2 bg-[#c9a87c] text-white rounded-lg text-sm hover:bg-[#b8976a]">
                <MessageCircle className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share Modal */}
      {shareOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 relative">
            <button onClick={() => setShareOpen(false)} className="absolute top-4 right-4 p-1 text-[#8a8279] hover:text-[#4a4a4a]">
              <X className="w-5 h-5" />
            </button>
            <h2 className="text-xl font-serif text-[#4a4a4a] mb-5">Поделиться альбомом</h2>
            <div className="grid grid-cols-3 gap-3 mb-5">
              <button
                onClick={() => handleShare("telegram")}
                className="flex flex-col items-center gap-2 p-3 rounded-xl bg-[#f5efe6] hover:bg-[#ebe3d5] transition-colors"
              >
                <div className="w-10 h-10 bg-[#2AABEE] rounded-full flex items-center justify-center">
                  <Send className="w-5 h-5 text-white" />
                </div>
                <span className="text-xs text-[#4a4a4a]">Telegram</span>
              </button>
              <button
                onClick={() => handleShare("whatsapp")}
                className="flex flex-col items-center gap-2 p-3 rounded-xl bg-[#f5efe6] hover:bg-[#ebe3d5] transition-colors"
              >
                <div className="w-10 h-10 bg-[#25D366] rounded-full flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-white" />
                </div>
                <span className="text-xs text-[#4a4a4a]">WhatsApp</span>
              </button>
              <button
                onClick={() => handleShare("vk")}
                className="flex flex-col items-center gap-2 p-3 rounded-xl bg-[#f5efe6] hover:bg-[#ebe3d5] transition-colors"
              >
                <div className="w-10 h-10 bg-[#4C75A3] rounded-full flex items-center justify-center">
                  <Share2 className="w-5 h-5 text-white" />
                </div>
                <span className="text-xs text-[#4a4a4a]">VK</span>
              </button>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={albumUrl}
                readOnly
                className="flex-1 px-3 py-2.5 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl text-sm text-[#4a4a4a]"
              />
              <button
                onClick={() => handleShare("copy")}
                className="px-3 py-2.5 bg-[#c9a87c] text-white rounded-xl hover:bg-[#b8976a] transition-colors"
              >
                {linkCopied ? <Check className="w-4 h-4" /> : <Link className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function loadImage(url: string): Promise<{ data: string; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0);
      resolve({ data: canvas.toDataURL("image/jpeg", 0.85), width: img.width, height: img.height });
    };
    img.onerror = reject;
    img.src = url;
  });
}
