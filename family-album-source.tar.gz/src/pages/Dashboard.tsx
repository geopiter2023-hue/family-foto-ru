import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { supabase, type Album, type Notification, CLASSIC_COVERS, COLOR_COVERS } from "@/lib/supabase";
import {
  BookHeart, Plus, Calendar, MapPin, ImageIcon, LogOut, Users,
  Heart, Bell, Trash2
} from "lucide-react";
import SupportModal from "@/components/SupportModal";
import { Toaster, toast } from "sonner";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [albums, setAlbums] = useState<Album[]>([]);
  const [loading, setLoading] = useState(true);
  const [supportOpen, setSupportOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadAlbums();
    loadNotifications();
    // Click outside to close notif dropdown
    function handleClick(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  async function loadAlbums() {
    const { data, error } = await supabase
      .from("albums")
      .select("*")
      .order("created_at", { ascending: false });
    if (!error && data) setAlbums(data);
    setLoading(false);
  }

  async function loadNotifications() {
    if (!user?.id) return;
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", user.id)
      .eq("read", false)
      .order("created_at", { ascending: false });
    if (data) setNotifications(data);
  }

  async function markAllRead() {
    if (!user?.id) return;
    await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    setNotifications([]);
    toast.success("Все уведомления прочитаны");
  }

  async function deleteAlbum(id: string) {
    if (!confirm("Удалить альбом?")) return;
    // Get owner before delete
    const { data: albumData } = await supabase.from("albums").select("user_id, title").eq("id", id).single();
    const { data: albumPhotos } = await supabase.from("photos").select("url").eq("album_id", id);
    if (albumPhotos) {
      for (const photo of albumPhotos) {
        const path = photo.url.split("/photos/").pop();
        if (path) await supabase.storage.from("photos").remove([path]);
      }
    }
    await supabase.from("photos").delete().eq("album_id", id);
    await supabase.from("albums").delete().eq("id", id);
    // Notify owner if deleted by someone else
    if (albumData && user?.id !== albumData.user_id) {
      await supabase.from("notifications").insert({
        user_id: albumData.user_id,
        album_id: id,
        message: `Ваш альбом "${albumData.title}" был удалён`,
      });
    }
    loadAlbums();
  }

  const unreadCount = notifications.length;

  return (
    <div className="min-h-screen bg-[#f5efe6]">
      <Toaster position="top-center" />

      {/* Header */}
      <header className="bg-gradient-to-r from-[#c9a87c] to-[#b8976a]">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/90 rounded-xl flex items-center justify-center">
              <BookHeart className="w-5 h-5 text-[#c9a87c]" />
            </div>
            <div>
              <h1 className="text-lg font-serif text-white">Семейный Альбом</h1>
              <p className="text-xs text-white/80 hidden sm:block">{user?.email}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {/* Notifications */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setNotifOpen((v) => !v)}
                className="p-2 bg-white/90 rounded-xl text-[#8a8279] hover:bg-white transition-colors relative"
                title="Уведомления"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </button>
              {notifOpen && (
                <div className="absolute right-0 top-12 w-80 bg-white rounded-2xl shadow-xl border border-[#e5ddd0] z-50 overflow-hidden">
                  <div className="px-4 py-3 border-b border-[#e5ddd0] flex items-center justify-between">
                    <span className="font-medium text-[#4a4a4a]">Уведомления</span>
                    {unreadCount > 0 && (
                      <button onClick={markAllRead} className="text-xs text-[#c9a87c] hover:underline">
                        Прочитать все
                      </button>
                    )}
                  </div>
                  <div className="max-h-64 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="px-4 py-6 text-center text-sm text-[#8a8279]">
                        Нет новых уведомлений
                      </div>
                    ) : (
                      notifications.map((n) => (
                        <div
                          key={n.id}
                          className="px-4 py-3 border-b border-[#f0e6d8] hover:bg-[#f5efe6] cursor-pointer transition-colors"
                          onClick={() => {
                            if (n.album_id) navigate(`/album/${n.album_id}`);
                            setNotifOpen(false);
                          }}
                        >
                          <p className="text-sm text-[#4a4a4a]">{n.message}</p>
                          <p className="text-xs text-[#b8a088] mt-1">
                            {new Date(n.created_at).toLocaleDateString("ru-RU", {
                              day: "numeric",
                              month: "short",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
            <button
              onClick={() => setSupportOpen(true)}
              className="p-2 bg-white/90 rounded-xl text-red-400 hover:bg-white transition-colors"
              title="Поддержать"
            >
              <Heart className="w-4 h-4" />
            </button>
            <button
              onClick={logout}
              className="flex items-center gap-1.5 px-3 py-2 bg-white/90 text-[#8a8279] rounded-xl text-sm hover:bg-white transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Выйти</span>
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center justify-center gap-2 mb-6">
          <Users className="w-4 h-4 text-[#c9a87c]" />
          <span className="text-sm text-[#8a8279]">Ваши воспоминания</span>
        </div>

        {loading ? (
          <div className="text-center py-16 text-[#8a8279]">Загрузка...</div>
        ) : albums.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center shadow-sm">
            <ImageIcon className="w-16 h-16 text-[#c9a87c]/30 mx-auto mb-4" />
            <h3 className="text-xl text-[#4a4a4a] mb-2">Нет альбомов</h3>
            <p className="text-[#8a8279] mb-6">Создайте первый семейный альбом</p>
            <button
              onClick={() => navigate("/create")}
              className="bg-[#c9a87c] text-white px-6 py-3 rounded-xl hover:bg-[#b8976a] flex items-center gap-2 mx-auto transition-colors"
            >
              <Plus className="w-4 h-4" /> Создать альбом
            </button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {albums.map((album) => {
                // Get cover display style
                const getCoverBg = () => {
                  if (album.cover_type === "classic" && album.cover_color) {
                    const c = CLASSIC_COVERS.find((x) => x.value === album.cover_color);
                    return { backgroundColor: c?.color || "#C4A882" };
                  }
                  if (album.cover_type === "custom" && album.cover_image_url) {
                    return { backgroundImage: `url(${album.cover_image_url})`, backgroundSize: "cover", backgroundPosition: "center" };
                  }
                  return {};
                };
                const getCoverClass = () => {
                  if (album.cover_type === "color" && album.cover_color) {
                    const c = COLOR_COVERS.find((x) => x.value === album.cover_color);
                    return c?.bg || "bg-[#e5ddd0]";
                  }
                  return "bg-[#e5ddd0]";
                };

                return (
                  <div
                    key={album.id}
                    className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-all cursor-pointer group relative"
                    onClick={() => navigate(`/album/${album.id}`)}
                  >
                    <div className="aspect-[4/3] bg-[#e5ddd0] relative overflow-hidden flex items-center justify-center">
                      {/* Cover book preview */}
                      <div
                        className={`w-28 h-40 rounded-r-lg rounded-l-sm shadow-xl relative overflow-hidden flex items-center justify-center ${getCoverClass()}`}
                        style={getCoverBg()}
                      >
                        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPjxyZWN0IHdpZHRoPSI0IiBoZWlnaHQ9IjQiIGZpbGw9Im5vbmUiLz48cGF0aCBkPSJNMCw0IEw0LDAiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjA4KSIgc3Ryb2tlLXdpZHRoPSIwLjUiLz48L3N2Zz4=')] opacity-50" />
                        <svg className="w-6 h-6 text-[#c9a87c]/70 relative z-10" viewBox="0 0 64 64" fill="currentColor">
                          <path d="M32 4c-2.5 0-4.8 1.2-6.2 3.1-1.6 2.2-3.8 3.8-6.4 4.3-3.2.6-5.8 2.8-7 5.8-1 2.6-.7 5.6.8 8 1.8 2.8 2.2 6.3 1 9.4-1.4 3.4-.8 7.3 1.6 10.2 2.2 2.6 5.6 3.8 8.9 3.1 3.3-.7 6.8.4 9.2 2.8 1.6 1.6 3.8 2.5 6.1 2.5s4.5-.9 6.1-2.5c2.4-2.4 5.9-3.5 9.2-2.8 3.3.7 6.7-.5 8.9-3.1 2.4-2.9 3-6.8 1.6-10.2-1.2-3.1-.8-6.6 1-9.4 1.5-2.4 1.8-5.4.8-8-1.2-3-3.8-5.2-7-5.8-2.6-.5-4.8-2.1-6.4-4.3C36.8 5.2 34.5 4 32 4z" />
                        </svg>
                        <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-black/10 rounded-l-sm" />
                      </div>

                      {/* Year badge */}
                      <div className="absolute top-3 left-3 bg-white/95 px-3 py-1 rounded-full text-sm font-semibold text-[#4a4a4a] flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-[#c9a87c]" /> {album.year}
                      </div>
                      {/* Format badge */}
                      {album.album_format && (
                        <div className="absolute bottom-3 left-3 bg-white/95 px-2 py-0.5 rounded-full text-xs font-medium text-[#4a4a4a]">
                          {album.album_format.replace("x", "×")} см
                        </div>
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteAlbum(album.id);
                        }}
                        className="absolute top-3 right-3 p-1.5 bg-white/90 rounded-full text-red-400 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="p-5">
                      <h3 className="font-serif text-lg text-[#4a4a4a] group-hover:text-[#c9a87c] transition-colors">
                        {album.title}
                      </h3>
                      {album.location && (
                        <div className="flex items-center gap-1 text-xs text-[#8a8279] mt-1">
                          <MapPin className="w-3 h-3" /> {album.location}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-8 text-center">
              <button
                onClick={() => navigate("/create")}
                className="bg-[#c9a87c] text-white px-6 py-3 rounded-xl hover:bg-[#b8976a] flex items-center gap-2 mx-auto transition-colors"
              >
                <Plus className="w-4 h-4" /> Новый альбом
              </button>
            </div>
          </>
        )}
      </div>

      <SupportModal open={supportOpen} onClose={() => setSupportOpen(false)} />
    </div>
  );
}
