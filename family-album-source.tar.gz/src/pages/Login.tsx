import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Mail, ArrowRight, KeyRound, BookHeart, Camera } from "lucide-react";

export default function Login() {
  const [step, setStep] = useState<"email" | "otp">("email");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const { sendOtp, verifyOtp } = useAuth();

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      await sendOtp(email);
      setStep("otp");
    } catch (err: any) {
      setError(err.message || "Ошибка отправки");
    }
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      await verifyOtp(email, otp.trim());
    } catch (err: any) {
      setError(err.message || "Неверный код");
    }
  };

  return (
    <div className="min-h-screen bg-[#f5efe6] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-14 h-14 bg-[#c9a87c] rounded-2xl flex items-center justify-center shadow-md">
              <BookHeart className="w-7 h-7 text-white" />
            </div>
            <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-md">
              <Camera className="w-7 h-7 text-[#c9a87c]" />
            </div>
          </div>
          <h1 className="text-3xl font-serif text-[#6B4226]">Семейный Альбом</h1>
          <p className="text-[#8a8279] mt-1">Ваши воспоминания в одном месте</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          {step === "email" ? (
            <form onSubmit={handleSend} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#c9a87c]" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full pl-11 pr-4 py-3 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                    required
                  />
                </div>
              </div>
              {error && <p className="text-red-500 text-sm bg-red-50 p-2 rounded-lg">{error}</p>}
              <button
                type="submit"
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium hover:bg-[#b8976a] transition-colors flex items-center justify-center gap-2"
              >
                Получить код <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerify} className="space-y-4">
              <div className="text-center">
                <KeyRound className="w-10 h-10 text-[#c9a87c] mx-auto mb-2" />
                <p className="text-sm text-[#8a8279]">Код отправлен на {email}</p>
                <p className="text-xs text-[#b8a088] mt-1">
                  Введите код из письма (6 цифр или длинный токен)
                </p>
              </div>
              <input
                type="text"
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder="Введите код из письма..."
                className="w-full px-4 py-3 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl text-center text-lg tracking-wide font-mono focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                autoFocus
                required
              />
              {error && <p className="text-red-500 text-sm text-center bg-red-50 p-2 rounded-lg">{error}</p>}
              <button
                type="submit"
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium hover:bg-[#b8976a] transition-colors"
              >
                Войти
              </button>
              <button
                type="button"
                onClick={() => setStep("email")}
                className="w-full text-[#8a8279] text-sm hover:text-[#c9a87c] transition-colors py-2"
              >
                Вернуться назад
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
