import { useState } from "react";
import { Heart, X, Copy, Check, Star, MessageSquare } from "lucide-react";
import { Toaster, toast } from "sonner";
import { supabase } from "@/lib/supabase";

interface SupportModalProps {
  open: boolean;
  onClose: () => void;
}

const CARD_NUMBER = "5536 9177 5286 1101";

export default function SupportModal({ open, onClose }: SupportModalProps) {
  const [copied, setCopied] = useState(false);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!open) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(CARD_NUMBER.replace(/\s/g, ""));
      setCopied(true);
      toast.success("Номер карты скопирован!");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Не удалось скопировать");
    }
  };

  const handleSubmitFeedback = async () => {
    if (rating === 0) { toast.error("Поставьте оценку"); return; }
    setSubmitting(true);
    const { error } = await supabase.from("feedback").insert({
      rating,
      comment: comment.trim() || null,
    });
    setSubmitting(false);
    if (error) {
      toast.error("Ошибка отправки");
    } else {
      toast.success("Спасибо за отзыв!");
      setRating(0);
      setComment("");
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Toaster position="top-center" />
      <div className="bg-white rounded-2xl max-w-sm w-full p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4 p-1 text-[#8a8279] hover:text-[#4a4a4a]">
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-5">
          <div className="w-14 h-14 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-3">
            <Heart className="w-7 h-7 text-red-400" />
          </div>
          <h2 className="text-xl font-serif text-[#4a4a4a]">Поддержать проект</h2>
          <p className="text-sm text-[#8a8279] mt-1">Ваша поддержка помогает развивать сервис</p>
        </div>

        {/* Card */}
        <div className="bg-gradient-to-br from-[#c9a87c] to-[#b8976a] rounded-xl p-4 mb-5 text-white">
          <p className="text-xs text-white/70 mb-1">Т-Банк (Tinkoff)</p>
          <div className="flex items-center justify-between">
            <p className="text-lg font-mono tracking-wider">{CARD_NUMBER}</p>
            <button
              onClick={handleCopy}
              className="p-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Rating */}
        <div className="mb-4">
          <p className="text-sm text-[#4a4a4a] mb-2">Оцените сервис</p>
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map((s) => (
              <button key={s} onClick={() => setRating(s)} className="p-1">
                <Star
                  className={`w-7 h-7 ${s <= rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"} transition-colors`}
                />
              </button>
            ))}
          </div>
        </div>

        {/* Comment */}
        <div className="mb-4">
          <div className="relative">
            <MessageSquare className="absolute left-3 top-3 w-4 h-4 text-[#c9a87c]" />
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Ваш отзыв или пожелание..."
              rows={3}
              className="w-full pl-10 pr-4 py-3 bg-[#f5efe6] border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] resize-none text-sm"
            />
          </div>
        </div>

        <button
          onClick={handleSubmitFeedback}
          disabled={submitting}
          className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium hover:bg-[#b8976a] transition-colors disabled:opacity-60"
        >
          {submitting ? "Отправка..." : "Отправить отзыв"}
        </button>
      </div>
    </div>
  );
}
