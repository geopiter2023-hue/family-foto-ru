# Полный технический аудит family-foto.ru v59

## 1. Общая архитектура

### Стек технологий
- **Frontend**: React 19 + TypeScript + Vite + Tailwind CSS
- **Роутинг**: HashRouter (react-router-dom)
- **База данных**: Supabase PostgreSQL (опционально) + IndexedDB (основное) + localStorage (legacy)
- **Хранилище файлов**: Supabase Storage (опционально) + base64 inline (fallback)
- **Аутентификация**: Supabase Auth (signInWithPassword + signUp + OTP для recovery)
- **PWA**: Service Worker, manifest.json, beforeinstallprompt

### Структура проекта (19 файлов)
```
src/
  App.tsx                 — роутинг + миграция IndexedDB
  types.ts / types/index.ts — типы Album, Photo, Member
  pages/
    Landing.tsx           — главная, альбомы, настройки, поддержка
    Login.tsx             — вход/регистрация (password-based)
    ResetPassword.tsx     — OTP recovery + смена пароля
    AlbumPage.tsx         — просмотр альбома, фото, удаление
    AddPhoto.tsx          — загрузка фото с компрессией
    CreateAlbum.tsx       — создание альбома
    PhotoBook.tsx         — фотокнига (PDF экспорт)
    FamilyTreePage.tsx    — семейное древо
    TrashPage.tsx         — корзина (30 дней)
    InvitePage.tsx        — приём приглашений
    SupportPage.tsx       — поддержка, отзывы, колесо фортуны
    AdminPage.tsx         — админ-панель
    AdminSettings.tsx     — настройки системы
    AdminSupport.tsx      — обращения в поддержку
    NotFound.tsx          — 404
  components/
    Footer.tsx            — соцсети, копирайт
  lib/
    api.ts                — центральный API (300+ строк)
    photoDb.ts            — IndexedDB wrapper
    pdfDownload.ts        — PDF download helper
```

---

## 2. Критические проблемы (P0) — требуют исправления

### 2.1. Проблема: Некорректный invite flow (InvitePage.tsx)
**Строки**: 44-101
**Описание**: При приёме приглашения:
1. Отправляется OTP на email (signInWithOtp)
2. Но код НЕ вводится пользователем
3. Сразу создаётся локальный пользователь и принимается приглашение
4. OTP сессия теряется

**Фикс**: Добавить шаг ввода OTP-кода после отправки, потом принимать приглашение.

### 2.2. Проблема: window.location.href вместо navigate() в HashRouter
**Файлы**: Landing.tsx (строки 589, 664), AdminPage.tsx (68), AdminSupport.tsx (60)
**Описание**: `window.location.href = "#/create-album"` не работает корректно с HashRouter — должен быть `navigate("/create-album")`.

**Фикс**: Заменить все `window.location.href` на `useNavigate()`.

### 2.3. Проблема: Logout конфликт с роутингом
**Landing.tsx строка**: 378
**Описание**: `logout(); window.location.href = "#/login";` — logout очищает localStorage, но window.location.href перезагружает страницу вместо клиентского перехода.

**Фикс**: `navigate("/login")` после logout.

---

## 3. Важные проблемы (P1)

### 3.1. Landing.tsx — порядок импортов
**Строка**: 20 — `import type { Album }` идёт ПОСЛЕ объявления `ROLE_LABELS` (строки 6-19). TypeScript допускает, но это нарушение стандарта.

### 3.2. FamilyTreePage.tsx — onTouchStart handlers
**Описание**: Используется `onTouchStart` для кнопок, что может вызывать double-fire на некоторых устройствах.

### 3.3. AlbumPage.tsx — handleBook function
**Описание**: Функция `handleBook` объявлена но не используется, вызывает lint warning.

### 3.4. api.ts — export const supabase
**Описание**: `supabase` экспортируется как mutable variable. В Login.tsx/ResetPassword.tsx используется напрямую без проверки на undefined.

### 3.5. photoDb.ts — withStore function
**Описание**: Используется `withStore` внутри `dbMemberRestore` но не экспортируется. На строке 790 `dbMemberRestore` использует `withStore` который определён выше в том же файле — это работает, но типы могут конфликтовать.

### 3.6. AdminSettings.tsx — Footer вызов
**Описание**: `Footer` импортирует `getSettings()` из api.ts, но settings загружаются из localStorage — при смене пароля это может не обновляться сразу.

---

## 4. Умеренные проблемы (P2)

### 4.1. ResetPassword.tsx — navigate импорт
**Описание**: Импорт `useNavigate` удалён, но функция больше не используется — нужно убрать из импорта.

### 4.2. CreateAlbum.tsx — max-w-2xl
**Описание**: Использует `max-w-2xl` вместо `max-w-5xl` как остальные страницы — несогласованная ширина.

### 4.3. TrashPage.tsx — не использует Footer
**Описание**: Страница корзины не имеет Footer в отличие от других страниц.

### 4.4. Login.tsx — useNavigate используется
**Описание**: `useNavigate` импортирован и используется для `navigate("/")`, что корректно — НЕ нужно менять на window.location.

### 4.5. IndexedDB — миграция однократная
**Описание**: `migrateLocalStorageToIndexedDB()` вызывается в App.tsx useEffect, но если данные добавляются ПОСЛЕ миграции — они остаются в localStorage. Нет периодической синхронизации.

---

## 5. Проблемы производительности

### 5.1. Bundle size — 1.06 MB JS
**Описание**: Основной chunk 1,059 KB (312 KB gzip). Включает:
- jsPDF (для PDF экспорта)
- html2canvas (для скриншотов)
- lucide-react (иконки, tree-shakeable)
- framer-motion

**Рекомендация**: Разбить на lazy-loaded chunks:
```typescript
const PhotoBook = lazy(() => import("./pages/PhotoBook"));
const AdminPage = lazy(() => import("./pages/AdminPage"));
```

### 5.2. Base64 фото в памяти
**Описание**: Каждое фото хранится как base64 string в IndexedDB. Для 100 фото по 500KB = 50MB в памяти.

**Рекомендация**: Хранить миниатюры как base64, оригиналы как Blob в IndexedDB.

---

## 6. Проблемы безопасности

### 6.1. Admin пароль в localStorage
**Описание**: `settings.adminPassword` хранится в localStorage в plaintext.

### 6.2. Auth user в localStorage
**Описание**: `auth_user` с токеном хранится в localStorage — уязвимость для XSS.

### 6.3. No CSRF protection
**Описание**: Нет защиты от CSRF для localStorage-based API.

---

## 7. Что работает корректно ✅

| Функция | Статус | Примечание |
|---------|--------|------------|
| Создание альбома | ✅ | IndexedDB + Supabase dual-write |
| Добавление фото | ✅ | IndexedDB, компрессия 800px/75% |
| Удаление альбома (soft delete) | ✅ | IndexedDB + localStorage + Supabase |
| Удаление фото (soft delete) | ✅ | IndexedDB + localStorage + Supabase |
| Корзина (30 дней) | ✅ | cleanupOldDeletedItems |
| Вход/регистрация (password) | ✅ | signInWithPassword + signUp |
| OTP recovery | ✅ | signInWithOtp + verifyOtp + updateUser |
| Фотокнига | ✅ | String albumId, jsPDF |
| Семейное древо | ✅ | Soft delete, Russian roles |
| Админ-панель | ✅ | getSettings(), не hardcoded |
| PWA установка | ✅ | beforeinstallprompt |
| PDF экспорт (iOS) | ✅ | window.open для Safari |
| Колесо фортуны | ✅ | Canvas + CSS transition |
| Footer соцсети | ✅ | getSettings() |

---

## 8. Рекомендации

### Срочно (v60):
1. Исправить InvitePage.tsx — добавить шаг ввода OTP
2. Заменить window.location.href на navigate() в Landing.tsx

### Важно (v61):
3. Добавить lazy loading для PhotoBook, AdminPage
4. Убрать unused imports (ResetPassword.tsx — useNavigate)
5. Согласовать max-width на всех страницах

### Желательно (v62+):
6. Хранить оригиналы фото как Blob в IndexedDB
7. Добавить Service Worker для офлайн-режима
8. Реализовать periodic background sync для Supabase
9. Добавить тесты (Jest/React Testing Library)

---

## 9. Сводка

| Категория | Количество |
|-----------|------------|
| Критические (P0) | 3 |
| Важные (P1) | 6 |
| Умеренные (P2) | 5 |
| Производительность | 2 |
| Безопасность | 3 |
| Работает корректно | 14 |

**Общая оценка**: Система стабильна. Основные функции работают. 3 критических бага связаны с роутингом и invite flow.
