import { Link } from "react-router-dom";
import { FileQuestion, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#f5efe6] flex items-center justify-center p-4">
      <div className="text-center">
        <div className="w-24 h-24 bg-[#f5efe6] rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-sm">
          <FileQuestion className="w-12 h-12 text-[#c9a87c]/50" />
        </div>
        <h1 className="text-5xl font-serif text-[#4a4a4a] mb-2">404</h1>
        <p className="text-[#8a8279] mb-8">Страница не найдена</p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 bg-[#c9a87c] text-white px-6 py-3 rounded-xl hover:bg-[#b8976a] transition-all font-medium shadow-md hover:shadow-lg"
        >
          <ArrowLeft className="w-4 h-4" />
          На главную
        </Link>
      </div>
    </div>
  );
}
