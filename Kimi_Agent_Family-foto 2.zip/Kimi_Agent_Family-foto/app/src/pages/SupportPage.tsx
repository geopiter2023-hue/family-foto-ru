import { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supportApi } from "../lib/api";
import { ArrowLeft, Star, Heart, MessageCircle, CreditCard, Copy, Check, Sparkles, Loader2, Users } from "lucide-react";

const T_BANK_CARD = "5536 9177 5286 1101";

const WHEEL_WISHES = [
  "🌞 Радость",
  "👨‍👩‍👧‍👦 Семья",
  "🍀 Счастье",
  "😊 Улыбка",
  "🕯️ Тепло",
  "❤️ Любовь",
  "📸 Моменты",
  "✨ Вдохновение",
];

const WHEEL_FULL_WISHES = [
  "Пусть каждый день приносит радость!",
  "Семья — главное. Берегите друг друга!",
  "Любовь и счастье вашей семье!",
  "Улыбайтесь чаще — вы прекрасны!",
  "Пусть дом будет полон смеха и тепла!",
  "Цените моменты — они бесценны!",
  "Пусть воспоминания согревают всегда!",
  "Пусть каждая фото расскажет историю!",
];

const WHEEL_COLORS = [
  "#c9a87c", "#6b4226", "#a08060", "#d4a574",
  "#8a8279", "#c9a87c", "#6b4226", "#a08060",
];

function getWheelShown(): boolean {
  return localStorage.getItem("wheel_of_fortune_shown") === "true";
}

function setWheelShown() {
  localStorage.setItem("wheel_of_fortune_shown", "true");
}

export default function SupportPage() {
  const navigate = useNavigate();
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [thanks, setThanks] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);
  const [stats, setStats] = useState({ count: 0, avgRating: 0 });

  // Wheel of Fortune
  const [showWheel, setShowWheel] = useState(false);
  const [wheelSpinning, setWheelSpinning] = useState(false);
  const [wheelResult, setWheelResult] = useState<string | null>(null);
  const [wheelRotation, setWheelRotation] = useState(0);
  const wheelCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const s = supportApi.stats();
    setStats(s);
  }, []);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (rating === 0) return;
    setSubmitting(true);
    supportApi.create({ rating, comment, thanks });
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      setStats(supportApi.stats());
      // Show wheel of fortune once after first review
      if (!getWheelShown()) {
        setTimeout(() => setShowWheel(true), 600);
      }
    }, 500);
  }

  // Draw the wheel on canvas
  const drawWheel = useCallback(() => {
    const canvas = wheelCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const size = canvas.width;
    const cx = size / 2;
    const cy = size / 2;
    const radius = size * 0.42;
    const segAngle = (Math.PI * 2) / WHEEL_WISHES.length;

    ctx.clearRect(0, 0, size, size);

    // Background circle
    ctx.beginPath();
    ctx.arc(cx, cy, radius + 4, 0, Math.PI * 2);
    ctx.fillStyle = "#e5ddd0";
    ctx.fill();

    // Sectors
    for (let i = 0; i < WHEEL_WISHES.length; i++) {
      const startAngle = i * segAngle - Math.PI / 2;
      const endAngle = startAngle + segAngle;

      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = WHEEL_COLORS[i];
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.3)";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Text — single word, large, radial (from center to edge)
      const midAngle = startAngle + segAngle / 2;
      const textR = radius * 0.52;
      const tx = cx + Math.cos(midAngle) * textR;
      const ty = cy + Math.sin(midAngle) * textR;

      ctx.save();
      ctx.translate(tx, ty);
      // Rotate text to align radially (pointing from center outward)
      ctx.rotate(midAngle);
      ctx.fillStyle = "#ffffff";
      ctx.font = `bold ${Math.max(16, size * 0.032)}px serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.shadowColor = "rgba(0,0,0,0.25)";
      ctx.shadowBlur = 3;
      ctx.fillText(WHEEL_WISHES[i], 0, 0);
      ctx.restore();
    }

    // Center circle
    ctx.beginPath();
    ctx.arc(cx, cy, radius * 0.12, 0, Math.PI * 2);
    ctx.fillStyle = "#ffffff";
    ctx.fill();
    ctx.strokeStyle = "#c9a87c";
    ctx.lineWidth = 3;
    ctx.stroke();

    // Center dot
    ctx.beginPath();
    ctx.arc(cx, cy, 4, 0, Math.PI * 2);
    ctx.fillStyle = "#c9a87c";
    ctx.fill();
  }, []);

  useEffect(() => {
    if (showWheel && !wheelResult) {
      drawWheel();
    }
  }, [showWheel, wheelResult, drawWheel]);

  function spinWheel() {
    if (wheelSpinning) return;
    setWheelSpinning(true);

    const randomIndex = Math.floor(Math.random() * WHEEL_WISHES.length);
    const segAngle = 360 / WHEEL_WISHES.length;
    // Spin 5-7 full rotations + landing on random sector
    const extraSpins = 5 + Math.floor(Math.random() * 3);
    const targetAngle = extraSpins * 360 + (randomIndex * segAngle) + segAngle / 2;
    const newRotation = wheelRotation + targetAngle;

    setWheelRotation(newRotation);

    setTimeout(() => {
      setWheelSpinning(false);
      setWheelResult(WHEEL_FULL_WISHES[randomIndex]);
      setWheelShown();
    }, 4500);
  }

  function copyCard() {
    navigator.clipboard.writeText(T_BANK_CARD).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      const ta = document.createElement("textarea");
      ta.value = T_BANK_CARD;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-[#e5ddd0]">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center gap-4">
          <button
            onClick={() => navigate("/")}
            className="text-[#8a8279] active:text-[#c9a87c]"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-serif text-[#4a4a4a]">Поддержка проекта</h1>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {/* Stats */}
        <div className="bg-white rounded-2xl p-4 shadow-sm text-center">
          <div className="flex items-center justify-center gap-1 mb-2">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star
                key={s}
                className="w-5 h-5 text-[#c9a87c] fill-[#c9a87c]"
              />
            ))}
          </div>
          <p className="text-2xl font-serif text-[#4a4a4a]">{stats.avgRating.toFixed(1)}</p>
          <p className="text-sm text-[#8a8279]">
            {stats.count} оценок · {stats.count} отзывов
          </p>
        </div>

        {/* User count */}
        <div className="bg-white rounded-2xl p-4 shadow-sm text-center">
          <div className="flex items-center justify-center gap-2 mb-1">
            <Users className="w-5 h-5 text-[#c9a87c]" />
            <p className="text-2xl font-serif text-[#4a4a4a]">
              {(JSON.parse(localStorage.getItem("ff_users") || "[]") as string[]).length}
            </p>
          </div>
          <p className="text-sm text-[#8a8279]">пользователей в системе</p>
        </div>

        {/* T-Bank Card */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-[#e5ddd0]">
          <h2 className="text-lg font-serif text-[#4a4a4a] mb-3 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-[#c9a87c]" />
            Поддержать проект
          </h2>
          <p className="text-sm text-[#8a8279] mb-3">
            Меня зовут Марьяна, мне 7 лет. Мы с папой сделали сервис, чтобы делиться эмоциями с близкими. Поддержите наш проект, если он вам нравится. Спасибо!
          </p>
          <div className="bg-[#f5f0ea] rounded-xl p-3 flex items-center justify-between">
            <span className="font-mono text-[#4a4a4a] tracking-wider">{T_BANK_CARD}</span>
            <button
              onClick={copyCard}
              className="flex items-center gap-1 text-sm text-[#c9a87c] active:text-[#a6875a] font-medium"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4" />
                  Скопировано
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Копировать
                </>
              )}
            </button>
          </div>
          <p className="text-xs text-[#8a8279] mt-2">
            Скопируйте номер карты и переведите любую сумму через ваше приложение банка.
          </p>
        </div>

        {/* About the project */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <p className="text-sm text-[#4a4a4a] leading-relaxed whitespace-pre-line">
            {`Сервис, который помогает не терять важные моменты.

📱 Память телефона — на вес золота, особенно сейчас. Наш альбом хранит всё в облаке: загрузили фото, и можно удалить с телефона. Место есть, а воспоминания никуда не делись.

👨‍👩‍👧‍👦 Для родных и друзей — всё в одном месте, не нужно пересылать сотню фото в мессенджеры. Отправили ссылку — и близкие видят ваши истории с эмоциями, датами и местами.

💼 Для работы — туроператор покажет отели, строитель — этапы ремонта, дизайнер — идеи клиенту. Красивые альбомы с подписями, можно выгрузить в PDF.

Просто, душевно и удобно. Марьяна и папа старались для вас ✨`}
          </p>
        </div>

        {/* Instructions */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <h2 className="text-lg font-serif text-[#4a4a4a] mb-3">Как пользоваться сервисом</h2>
          <div className="space-y-3 text-sm text-[#4a4a4a]">
            <div className="flex gap-3">
              <span className="w-6 h-6 rounded-full bg-[#c9a87c] text-white flex items-center justify-center text-xs flex-shrink-0">1</span>
              <p>Создайте новый альбом и загрузите фотографии</p>
            </div>
            <div className="flex gap-3">
              <span className="w-6 h-6 rounded-full bg-[#c9a87c] text-white flex items-center justify-center text-xs flex-shrink-0">2</span>
              <p>Добавьте подписи, места и эмоции к каждой фотографии</p>
            </div>
            <div className="flex gap-3">
              <span className="w-6 h-6 rounded-full bg-[#c9a87c] text-white flex items-center justify-center text-xs flex-shrink-0">3</span>
              <p>Пригласите близких через ссылку-приглашение</p>
            </div>
            <div className="flex gap-3">
              <span className="w-6 h-6 rounded-full bg-[#c9a87c] text-white flex items-center justify-center text-xs flex-shrink-0">4</span>
              <p>Выгрузите альбом в PDF или сделайте фотокнигу</p>
            </div>
            <div className="flex gap-3">
              <span className="w-6 h-6 rounded-full bg-[#c9a87c] text-white flex items-center justify-center text-xs flex-shrink-0">5</span>
              <p>Установите приложение на экран телефона для быстрого доступа</p>
            </div>
          </div>
        </div>

        {/* Review Form */}
        {!submitted ? (
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-5 shadow-sm space-y-4">
            <h2 className="text-lg font-serif text-[#4a4a4a]">Оставить отзыв</h2>

            <div>
              <label className="block text-sm text-[#8a8279] mb-2">Ваша оценка</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setRating(s)}
                    className="w-10 h-10 rounded-xl flex items-center justify-center transition-colors"
                    style={{
                      background: s <= rating ? "#c9a87c" : "#f5f0ea",
                    }}
                  >
                    <Star
                      className="w-5 h-5"
                      style={{
                        color: s <= rating ? "#fff" : "#8a8279",
                        fill: s <= rating ? "#fff" : "none",
                      }}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm text-[#8a8279] mb-2">Что вам понравилось?</label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                rows={3}
                className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] resize-none"
                placeholder="Расскажите о ваших впечатлениях..."
              />
            </div>

            <div>
              <label className="block text-sm text-[#8a8279] mb-2">
                <Heart className="w-4 h-4 inline text-[#c9a87c] mr-1" />
                Что можно улучшить?
              </label>
              <textarea
                value={thanks}
                onChange={(e) => setThanks(e.target.value)}
                rows={2}
                className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] resize-none"
                placeholder="Ваши пожелания..."
              />
            </div>

            <button
              type="submit"
              disabled={rating === 0 || submitting}
              className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium active:bg-[#a6875a] disabled:opacity-50"
            >
              {submitting ? "Отправка..." : "Отправить отзыв"}
            </button>
          </form>
        ) : (
          <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
            <div className="w-16 h-16 bg-[#c9a87c]/10 rounded-full flex items-center justify-center mx-auto mb-3">
              <MessageCircle className="w-8 h-8 text-[#c9a87c]" />
            </div>
            <h3 className="text-lg font-serif text-[#4a4a4a] mb-2">
              Спасибо за ваш отзыв!
            </h3>
            <p className="text-sm text-[#8a8279]">
              Ваша обратная связь помогает нам становиться лучше.
            </p>
          </div>
        )}

        {/* Wheel of Fortune */}
        {showWheel && (
          <div className="bg-white rounded-2xl p-5 shadow-sm text-center">
            {!wheelResult ? (
              <>
                <h3 className="text-lg font-serif text-[#4a4a4a] mb-1 flex items-center justify-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#c9a87c]" />
                  Колесо пожеланий
                </h3>
                <p className="text-sm text-[#8a8279] mb-4">
                  Крутите колесо — получите искреннее пожелание!
                </p>

                {/* Wheel */}
                <div className="relative mx-auto mb-4" style={{ width: 320, height: 320 }}>
                  {/* Pointer */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 z-10">
                    <div
                      style={{
                        width: 0, height: 0,
                        borderLeft: "12px solid transparent",
                        borderRight: "12px solid transparent",
                        borderTop: "18px solid #c9a87c",
                        filter: "drop-shadow(0 2px 2px rgba(0,0,0,0.2))",
                      }}
                    />
                  </div>

                  <canvas
                    ref={wheelCanvasRef}
                    width={640}
                    height={640}
                    className="w-full h-full"
                    style={{
                      transform: `rotate(${wheelRotation}deg)`,
                      transition: wheelSpinning ? "transform 4.5s cubic-bezier(0.2, 0, 0.1, 1)" : "none",
                    }}
                  />
                </div>

                <button
                  type="button"
                  onClick={spinWheel}
                  disabled={wheelSpinning}
                  className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-3 font-medium disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {wheelSpinning ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Крутится...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      Крутить
                    </>
                  )}
                </button>
              </>
            ) : (
              <div className="py-6">
                <div className="w-16 h-16 bg-[#c9a87c]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="w-8 h-8 text-[#c9a87c]" />
                </div>
                <p className="text-sm text-[#8a8279] mb-2">Ваше пожелание:</p>
                <p className="text-xl font-serif text-[#6b4226] leading-relaxed mb-4">
                  {wheelResult}
                </p>
                <p className="text-xs text-[#8a8279]">
                  Сохраните этот скриншот — пусть сбудется!
                </p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
