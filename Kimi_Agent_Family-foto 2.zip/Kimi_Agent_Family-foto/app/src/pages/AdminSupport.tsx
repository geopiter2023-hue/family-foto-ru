import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, MessageCircle, Mail, Clock, User, CheckCircle, XCircle } from "lucide-react";
import Footer from "../components/Footer";

interface SupportTicket {
  id: string;
  name: string;
  email: string;
  message: string;
  createdAt: string;
  status: "new" | "read" | "replied";
}

export default function AdminSupport() {
  const navigate = useNavigate();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("support_tickets") || "[]");
    setTickets(data.sort((a: SupportTicket, b: SupportTicket) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));
  }, []);

  function updateStatus(id: string, status: "new" | "read" | "replied") {
    const updated = tickets.map((t) => t.id === id ? { ...t, status } : t);
    localStorage.setItem("support_tickets", JSON.stringify(updated));
    setTickets(updated);
  }

  function deleteTicket(id: string) {
    const updated = tickets.filter((t) => t.id !== id);
    localStorage.setItem("support_tickets", JSON.stringify(updated));
    setTickets(updated);
  }

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleString("ru-RU", {
      day: "2-digit", month: "2-digit", year: "numeric",
      hour: "2-digit", minute: "2-digit",
    });
  };

  const statusBadge = (s: string) => {
    if (s === "new") return <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs">Новое</span>;
    if (s === "read") return <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs">Прочитано</span>;
    return <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs">Отвечено</span>;
  };

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      {/* Header */}
      <div className="bg-gradient-to-br from-[#8a8279] to-[#6b5d4e] text-white">
        <div className="max-w-lg mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => navigate("/")}
              className="flex items-center gap-2 text-white/80 active:text-white"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="text-sm">Назад</span>
            </button>
            <h1 className="text-lg font-serif">Админ — Обращения</h1>
            <div className="w-16" />
          </div>
        </div>
      </div>

      <main className="max-w-lg mx-auto px-4 py-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-medium text-[#8a8279]">
            Всего обращений: {tickets.length}
          </h2>
          <p className="text-xs text-[#8a8279]">help@family-foto.ru</p>
        </div>

        {tickets.length === 0 && (
          <div className="text-center py-12 text-[#8a8279]">
            <MessageCircle className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>Пока нет обращений</p>
          </div>
        )}

        {tickets.map((ticket) => (
          <div
            key={ticket.id}
            className={`bg-white rounded-2xl p-4 shadow-sm border-l-4 ${
              ticket.status === "new" ? "border-l-amber-400" :
              ticket.status === "read" ? "border-l-blue-400" : "border-l-green-400"
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-[#c9a87c]" />
                <span className="text-sm font-medium text-[#4a4a4a]">
                  {ticket.name}
                </span>
              </div>
              {statusBadge(ticket.status)}
            </div>

            {ticket.email && (
              <div className="flex items-center gap-2 mb-1 text-xs text-[#8a8279]">
                <Mail className="w-3 h-3" />
                <span>{ticket.email}</span>
              </div>
            )}

            <div className="flex items-center gap-2 mb-2 text-xs text-[#8a8279]">
              <Clock className="w-3 h-3" />
              <span>{formatDate(ticket.createdAt)}</span>
            </div>

            <p className="text-sm text-[#4a4a4a] bg-[#faf8f5] rounded-xl p-3 mb-3">
              {ticket.message}
            </p>

            <div className="flex gap-2">
              {ticket.status === "new" && (
                <button
                  type="button"
                  onClick={() => updateStatus(ticket.id, "read")}
                  className="flex-1 bg-blue-50 text-blue-600 rounded-lg py-2 text-xs font-medium flex items-center justify-center gap-1"
                >
                  <CheckCircle className="w-3 h-3" />
                  Прочитано
                </button>
              )}
              {ticket.status !== "replied" && (
                <button
                  type="button"
                  onClick={() => updateStatus(ticket.id, "replied")}
                  className="flex-1 bg-green-50 text-green-600 rounded-lg py-2 text-xs font-medium flex items-center justify-center gap-1"
                >
                  <CheckCircle className="w-3 h-3" />
                  Отвечено
                </button>
              )}
              <button
                type="button"
                onClick={() => deleteTicket(ticket.id)}
                className="px-3 bg-red-50 text-red-500 rounded-lg py-2 text-xs font-medium flex items-center justify-center"
              >
                <XCircle className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </main>

      <Footer />
    </div>
  );
}
