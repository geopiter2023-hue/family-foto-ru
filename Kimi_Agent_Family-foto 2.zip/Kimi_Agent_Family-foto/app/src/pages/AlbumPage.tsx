import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { albumApi, photoApi, inviteApi } from "../lib/api";
import Footer from "../components/Footer";
import type { Album, Photo } from "../types";
import FamilyTreePage from "./FamilyTreePage";
import {
  Plus,
  Trash2,
  BookOpen,
  Calendar,
  MapPin,
  Image,
  ChevronRight,
  Users,
  Loader2,
  FileText,
  Share2,
  X,
  Copy,
  Check,
  CheckSquare,
  Square,
} from "lucide-react";

import { jsPDF } from "jspdf";

export default function AlbumPage() {
  const { id } = useParams<{ id: string }>();
  const basePath = window.location.pathname;
  const albumId = id || "";
  const navigate = useNavigate();

  const [album, setAlbum] = useState<Album | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteLink, setInviteLink] = useState("");
  const [copied, setCopied] = useState(false);
  const [pdfLoading, setPdfLoading] = useState(false);

  const [showShareModal, setShowShareModal] = useState(false);
  const [pdfBlobForShare, setPdfBlobForShare] = useState<Blob | null>(null);
  const [pdfFileName, setPdfFileName] = useState("");

  // Custom message for final PDF page
  const [customMessage, setCustomMessage] = useState("");
  const [customFont, setCustomFont] = useState<"serif" | "sans-serif">("serif");
  const [customSize, setCustomSize] = useState<"small" | "medium" | "large">("medium");
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [showBgModal, setShowBgModal] = useState(false);
  const [selectedBg, setSelectedBg] = useState<string>("classic");
  const [customBgUrl, setCustomBgUrl] = useState<string | null>(null);
  const [customBgColor, setCustomBgColor] = useState<string>("#ffffff");
  const [finalPageFont, setFinalPageFont] = useState<string>("serif");
  const [finalPageSize, setFinalPageSize] = useState<string>("medium");
  const [finalPageTextColor, setFinalPageTextColor] = useState<string>("#ffffff");

  const bgPreviewRef = useRef<HTMLCanvasElement>(null);

  // Delete mode state
  const [deleteMode, setDeleteMode] = useState(false);
  const [selectedToDelete, setSelectedToDelete] = useState<(number | string)[]>([]);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    loadAlbum();
  }, [albumId]);

  // Draw background preview whenever selection changes
  useEffect(() => {
    if (!showBgModal || !bgPreviewRef.current) return;
    const canvas = bgPreviewRef.current;
    const ctx = canvas.getContext("2d")!;
    const w = canvas.width;
    const h = canvas.height;

    if (customBgUrl) {
      const img = document.createElement("img");
      img.crossOrigin = "anonymous";
      img.onload = () => {
        ctx.drawImage(img, 0, 0, w, h);
        drawPreviewText(ctx, w, h, finalPageFont, finalPageSize, finalPageTextColor);
      };
      img.onerror = () => {
        drawClassicBg(ctx, w, h);
        drawPreviewText(ctx, w, h, finalPageFont, finalPageSize, finalPageTextColor);
      };
      img.src = customBgUrl;
    } else if (selectedBg === "none") {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, w, h);
      drawPreviewText(ctx, w, h, finalPageFont, finalPageSize, finalPageTextColor);
    } else if (selectedBg === "color") {
      ctx.fillStyle = customBgColor;
      ctx.fillRect(0, 0, w, h);
      drawPreviewText(ctx, w, h, finalPageFont, finalPageSize, finalPageTextColor);
    } else {
      applyBackground(ctx, w, h);
      drawPreviewText(ctx, w, h, finalPageFont, finalPageSize, finalPageTextColor);
    }
  }, [showBgModal, selectedBg, customBgUrl, customBgColor, finalPageFont, finalPageSize, finalPageTextColor]);

  function drawPreviewText(ctx: CanvasRenderingContext2D, w: number, h: number, fontFamily: string, fontSize: string, textColor: string) {
    const sizeFactor = fontSize === "small" ? 0.06 : fontSize === "large" ? 0.12 : 0.08;

    // Title
    ctx.fillStyle = textColor;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = `bold ${Math.max(18, w * sizeFactor)}px ${fontFamily}`;
    ctx.shadowColor = "rgba(0,0,0,0.4)";
    ctx.shadowBlur = 6;
    ctx.fillText("Альбом", w / 2, h * 0.35);
    ctx.shadowColor = "transparent";

    // Decorative line
    ctx.strokeStyle = textColor + "80";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(w * 0.25, h * 0.48);
    ctx.lineTo(w * 0.75, h * 0.48);
    ctx.stroke();

    // Subtitle
    ctx.fillStyle = textColor + "D9";
    ctx.font = `${Math.max(10, w * sizeFactor * 0.45)}px ${fontFamily}`;
    ctx.fillText("2025", w / 2, h * 0.56);

    // Bottom text
    ctx.fillStyle = textColor + "99";
    ctx.font = `${Math.max(9, w * sizeFactor * 0.35)}px ${fontFamily}`;
    ctx.fillText("family-foto.ru", w / 2, h * 0.88);
  }

  async function loadAlbum() {
    setLoading(true);
    const data = await albumApi.getById(albumId);
    setAlbum(data || null);
    setLoading(false);
  }

  async function handleDeletePhoto(photoId: number | string) {
    setSelectedPhoto(null);
    try {
      await photoApi.delete(photoId);
    } catch (e: any) {
      console.error("[handleDeletePhoto] error:", e?.message || e);
    }
    loadAlbum();
  }

  function toggleDeleteMode() {
    if (deleteMode) {
      setDeleteMode(false);
      setSelectedToDelete([]);
    } else {
      setDeleteMode(true);
      setSelectedToDelete([]);
    }
  }

  function togglePhotoSelection(photoId: number | string) {
    setSelectedToDelete((prev) =>
      prev.includes(photoId)
        ? prev.filter((id) => id !== photoId)
        : [...prev, photoId]
    );
  }

  function selectAll() {
    if (!album) return;
    const allIds = album.photos?.map((p) => p.id) || [];
    if (selectedToDelete.length === allIds.length) {
      setSelectedToDelete([]);
    } else {
      setSelectedToDelete(allIds);
    }
  }

  function handleBulkDelete() {
    if (selectedToDelete.length === 0) return;
    setShowDeleteConfirm(true);
  }

  async function confirmBulkDelete() {
    try {
      for (const pid of selectedToDelete) {
        await photoApi.delete(pid);
      }
    } catch (e: any) {
      console.error("[confirmBulkDelete] error:", e?.message || e);
    }
    setSelectedToDelete([]);
    setDeleteMode(false);
    setShowDeleteConfirm(false);
    await loadAlbum();
  }

  async function handleInvite() {
    try {
      // Get current user email for tracking
      let userEmail = "";
      try {
        const authUser = JSON.parse(localStorage.getItem("auth_user") || "{}");
        userEmail = authUser.email || "";
      } catch { /* ignore */ }
      const invite = await inviteApi.create({ type: "album", albumId, role: "viewer", email: userEmail });
      const link = `${window.location.origin}/#/invite/${(invite as any).token}`;
      setInviteLink(link);
      setShowInviteModal(true);
      setCopied(false);
    } catch (e: any) {
      console.error("Invite error:", e?.message || e);
      alert("Ошибка при создании приглашения: " + (e?.message || "Неизвестная ошибка"));
    }
  }

  async function handleShareInvite() {
    if (!inviteLink) return;
    try {
      if ((navigator as any).share) {
        await (navigator as any).share({
          title: album?.title || "Семейный альбом",
          text: `Приглашение в альбом "${album?.title || ""}" на family-foto.ru`,
          url: inviteLink,
        });
      } else {
        alert("Отправка ссылки: скопируйте ссылку и отправьте в мессенджер.");
      }
    } catch (e: any) {
      if (e.name !== "AbortError") {
        console.error("Share invite error:", e);
      }
    }
  }

  function copyLink() {
    if (!inviteLink) return;
    navigator.clipboard.writeText(inviteLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      const textArea = document.createElement("textarea");
      textArea.value = inviteLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  function handleBook() {
    navigate(`/album/${albumId}/book`);
  }

  // ===== BACKGROUND DRAWERS =====
  function drawClassicBg(ctx: CanvasRenderingContext2D, w: number, h: number) {
    ctx.fillStyle = "#2a2520";
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#c9a87c";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(w * 0.15, h * 0.08);
    ctx.lineTo(w * 0.85, h * 0.08);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w * 0.15, h * 0.92);
    ctx.lineTo(w * 0.85, h * 0.92);
    ctx.stroke();
  }

  function drawNewYearBg(ctx: CanvasRenderingContext2D, w: number, h: number) {
    ctx.fillStyle = "#8B0000";
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = "#D4AF37";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(w * 0.10, h * 0.10);
    ctx.lineTo(w * 0.90, h * 0.10);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w * 0.10, h * 0.90);
    ctx.lineTo(w * 0.90, h * 0.90);
    ctx.stroke();
    ctx.fillStyle = "#FFFFFF";
    const seed = 42;
    for (let i = 0; i < 25; i++) {
      const sx = ((Math.sin(seed + i * 7.3) + 1) / 2) * w;
      const sy = ((Math.cos(seed + i * 5.1) + 1) / 2) * h;
      const size = 2 + ((i % 4) + 1) * 1.5;
      ctx.beginPath();
      ctx.arc(sx, sy, size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = "#D4AF37";
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.arc(w * 0.05 + i * 8, h * 0.04, 3, 0, Math.PI * 2);
      ctx.stroke();
    }
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.arc(w * 0.95 - i * 8, h * 0.96, 3, 0, Math.PI * 2);
      ctx.stroke();
    }
  }

  function drawBirthdayBg(ctx: CanvasRenderingContext2D, w: number, h: number) {
    ctx.fillStyle = "#FFF8F0";
    ctx.fillRect(0, 0, w, h);
    const colors = ["#FF6B6B", "#FFD93D", "#6BCB77", "#4D96FF", "#C9A87C", "#FF8C42"];
    for (let i = 0; i < 35; i++) {
      const cx = ((Math.sin(i * 3.7) + 1) / 2) * w;
      const cy = ((Math.cos(i * 2.9) + 1) / 2) * h;
      const r = 3 + (i % 5) * 1.2;
      ctx.fillStyle = colors[i % colors.length];
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = "#C9A87C";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(w * 0.15, h * 0.08);
    ctx.lineTo(w * 0.85, h * 0.08);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w * 0.15, h * 0.92);
    ctx.lineTo(w * 0.85, h * 0.92);
    ctx.stroke();
  }

  function drawWeddingBg(ctx: CanvasRenderingContext2D, w: number, h: number) {
    ctx.fillStyle = "#FFF5F7";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "rgba(201, 168, 124, 0.15)";
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 12; col++) {
        const cx = (col + 0.5) * (w / 12);
        const cy = (row + 0.5) * (h / 8);
        ctx.beginPath();
        ctx.arc(cx, cy, 4, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.strokeStyle = "#D4A5A5";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(w * 0.20, h * 0.08);
    ctx.lineTo(w * 0.80, h * 0.08);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w * 0.20, h * 0.92);
    ctx.lineTo(w * 0.80, h * 0.92);
    ctx.stroke();
  }

  function drawTravelBg(ctx: CanvasRenderingContext2D, w: number, h: number) {
    ctx.fillStyle = "#E8F4FD";
    ctx.fillRect(0, 0, w, h);
    const cx = w * 0.5, cy = h * 0.5;
    ctx.strokeStyle = "rgba(107, 66, 38, 0.10)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, Math.min(w, h) * 0.30, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cx, cy, Math.min(w, h) * 0.20, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = "rgba(107, 66, 38, 0.06)";
    ctx.beginPath();
    ctx.moveTo(cx, h * 0.10);
    ctx.lineTo(cx, h * 0.90);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w * 0.10, cy);
    ctx.lineTo(w * 0.90, cy);
    ctx.stroke();
    ctx.strokeStyle = "#8AB4D0";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(w * 0.15, h * 0.08);
    ctx.lineTo(w * 0.85, h * 0.08);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w * 0.15, h * 0.92);
    ctx.lineTo(w * 0.85, h * 0.92);
    ctx.stroke();
  }

  function drawNatureBg(ctx: CanvasRenderingContext2D, w: number, h: number) {
    ctx.fillStyle = "#F0F5E8";
    ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = "rgba(107, 142, 35, 0.10)";
    for (let i = 0; i < 18; i++) {
      const lx = ((Math.sin(i * 4.1) + 1) / 2) * w;
      const ly = ((Math.cos(i * 3.3) + 1) / 2) * h;
      const lw = 20 + (i % 5) * 8;
      const lh = 10 + (i % 3) * 5;
      ctx.beginPath();
      ctx.ellipse(lx, ly, lw, lh, (i * 0.5) % Math.PI, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.strokeStyle = "#6B8E23";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(w * 0.15, h * 0.08);
    ctx.lineTo(w * 0.85, h * 0.08);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(w * 0.15, h * 0.92);
    ctx.lineTo(w * 0.85, h * 0.92);
    ctx.stroke();
  }

  function applyBackground(ctx: CanvasRenderingContext2D, w: number, h: number) {
    const bgType = customBgUrl ? "custom" : selectedBg;
    switch (bgType) {
      case "none":
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, w, h);
        break;
      case "color":
        ctx.fillStyle = customBgColor;
        ctx.fillRect(0, 0, w, h);
        break;
      case "classic": drawClassicBg(ctx, w, h); break;
      case "newyear": drawNewYearBg(ctx, w, h); break;
      case "birthday": drawBirthdayBg(ctx, w, h); break;
      case "wedding": drawWeddingBg(ctx, w, h); break;
      case "travel": drawTravelBg(ctx, w, h); break;
      case "nature": drawNatureBg(ctx, w, h); break;
      default: drawClassicBg(ctx, w, h); break;
    }
  }

  async function handleExportPDF(skipMessage = false) {
    if (!album || photos.length === 0) {
      alert("Нет фото для PDF");
      return;
    }
    setPdfLoading(true);
    alert("Создаю PDF...");

    try {
      const pdf = new jsPDF("p", "mm", "a4");
      const PW_MM = 210;
      const PH_MM = 297;
      const DPI = 150;
      const PW_PX = Math.round((PW_MM * DPI) / 25.4);
      const PH_PX = Math.round((PH_MM * DPI) / 25.4);

      const safeName = (album.title || "album").replace(/[^a-zA-Z0-9\u0400-\u04FF]/g, "_");
      const fileName = `${safeName}_${year}.pdf`;
      const albumHeader = `${album.title} ${year}`;

      // ============ COVER PAGE (full-bleed photo + overlay text) ============
      const coverCanvas = document.createElement("canvas");
      coverCanvas.width = PW_PX;
      coverCanvas.height = PH_PX;
      const cctx = coverCanvas.getContext("2d")!;

      // Apply selected background (preset or custom)
      if (customBgUrl) {
        try {
          const bgImg = await loadImage(customBgUrl);
          cctx.drawImage(bgImg, 0, 0, PW_PX, PH_PX);
        } catch {
          applyBackground(cctx, PW_PX, PH_PX);
        }
      } else {
        applyBackground(cctx, PW_PX, PH_PX);
      }

      const coverUrl = album.coverPhoto || (photos.find(p => p.isCover)?.url) || photos[0]?.url;
      if (coverUrl) {
        try {
          const img = await loadImage(coverUrl);
          const aspect = img.width / img.height;
          const pageAspect = PW_PX / PH_PX;
          let sw = img.width, sh = img.height, sx = 0, sy = 0;
          if (aspect > pageAspect) {
            sw = img.height * pageAspect;
            sx = (img.width - sw) / 2;
          } else {
            sh = img.width / pageAspect;
            sy = (img.height - sh) / 2;
          }
          cctx.drawImage(img, sx, sy, sw, sh, 0, 0, PW_PX, PH_PX);
        } catch {
          // leave bg
        }
      }

      const overlay = cctx.createLinearGradient(0, 0, 0, PH_PX);
      overlay.addColorStop(0, "rgba(0,0,0,0.55)");
      overlay.addColorStop(0.25, "rgba(0,0,0,0.20)");
      overlay.addColorStop(0.7, "rgba(0,0,0,0.30)");
      overlay.addColorStop(1, "rgba(0,0,0,0.60)");
      cctx.fillStyle = overlay;
      cctx.fillRect(0, 0, PW_PX, PH_PX);

      // Title block at top, large
      cctx.fillStyle = "#ffffff";
      cctx.textAlign = "center";
      cctx.textBaseline = "top";

      // Large title — auto-scale to fit width
      const maxTitleW = PW_PX * 0.80;
      let titleSize = Math.max(52, PW_PX * 0.065);
      cctx.font = `bold ${titleSize}px serif`;
      let tw = cctx.measureText(album.title).width;
      if (tw > maxTitleW) {
        titleSize = Math.floor(titleSize * (maxTitleW / tw));
        cctx.font = `bold ${titleSize}px serif`;
      }
      const titleY = PH_PX * 0.10;
      cctx.fillText(album.title, PW_PX / 2, titleY);

      // Decorative line under title
      cctx.strokeStyle = "rgba(255,255,255,0.5)";
      cctx.lineWidth = 1.5;
      cctx.beginPath();
      const lineY = titleY + titleSize + PH_PX * 0.02;
      cctx.moveTo(PW_PX * 0.25, lineY);
      cctx.lineTo(PW_PX * 0.75, lineY);
      cctx.stroke();

      // Year
      cctx.font = `300 ${Math.max(22, titleSize * 0.40)}px sans-serif`;
      cctx.fillStyle = "rgba(255,255,255,0.85)";
      cctx.textBaseline = "top";
      cctx.fillText(String(year), PW_PX / 2, lineY + PH_PX * 0.018);

      // Location
      if (album.description) {
        cctx.font = `300 ${Math.max(14, titleSize * 0.22)}px sans-serif`;
        cctx.fillStyle = "rgba(255,255,255,0.65)";
        cctx.fillText(album.description.toUpperCase(), PW_PX / 2, lineY + PH_PX * 0.055);
      }

      // Bottom decorative line
      cctx.strokeStyle = "rgba(255,255,255,0.35)";
      cctx.lineWidth = 1;
      cctx.beginPath();
      cctx.moveTo(PW_PX * 0.30, PH_PX * 0.82);
      cctx.lineTo(PW_PX * 0.70, PH_PX * 0.82);
      cctx.stroke();

      // family-foto.ru
      cctx.font = `400 ${Math.max(11, PW_PX * 0.018)}px sans-serif`;
      cctx.fillStyle = "rgba(255,255,255,0.45)";
      cctx.fillText("family-foto.ru", PW_PX / 2, PH_PX * 0.94);

      pdf.addImage(coverCanvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, PW_MM, PH_MM);

      // ============ PHOTO PAGES (rounded frame + shadow + header + footer) ============
      for (let i = 0; i < photos.length; i++) {
        pdf.addPage();
        const photo = photos[i];
        const pCanvas = document.createElement("canvas");
        pCanvas.width = PW_PX;
        pCanvas.height = PH_PX;
        const pctx = pCanvas.getContext("2d")!;

        // Clean white background
        pctx.fillStyle = "#ffffff";
        pctx.fillRect(0, 0, PW_PX, PH_PX);

        // Header: album title + year
        pctx.fillStyle = "#8a8279";
        pctx.textAlign = "center";
        pctx.textBaseline = "top";
        pctx.font = `400 ${Math.max(12, PW_PX * 0.018)}px sans-serif`;
        pctx.fillText(albumHeader, PW_PX / 2, PH_PX * 0.025);

        // Photo area — MAXIMUM size with safe margins for text
        const marginTop = PH_PX * 0.04;      // space for header text
        const marginBottom = PH_PX * 0.04;   // space for footer/page number
        const availW = PW_PX * 0.94;         // max 94% width
        const availH = PH_PX - marginTop - marginBottom; // full remaining height

        try {
          const img = await loadImage(photo.url);
          const aspect = img.width / img.height;
          const maxAspect = availW / availH;

          let dw, dh, dx, dy;
          if (aspect > maxAspect) {
            // Landscape / wide photo — limited by width
            dw = availW;
            dh = dw / aspect;
            dx = (PW_PX - dw) / 2;
            dy = marginTop + (availH - dh) / 2; // center vertically
          } else {
            // Portrait / tall photo — limited by height
            dh = availH;
            dw = dh * aspect;
            dx = (PW_PX - dw) / 2; // center horizontally
            dy = marginTop;
          }

          // ===== PHOTO CARD: white mat + shadow + rounded photo =====
          const mat = 16;        // mat width (white border around photo)
          const r = Math.max(16, Math.min(dw, dh) * 0.02); // corner radius
          const cardR = r + 6;  // card corner radius slightly larger

          // Card dimensions (photo + mat padding)
          const cx = dx - mat;
          const cy = dy - mat;
          const cw = dw + mat * 2;
          const ch = dh + mat * 2;

          // Helper: rounded rect path
          function rrPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, rad: number) {
            ctx.beginPath();
            ctx.moveTo(x + rad, y);
            ctx.lineTo(x + w - rad, y);
            ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
            ctx.lineTo(x + w, y + h - rad);
            ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
            ctx.lineTo(x + rad, y + h);
            ctx.quadraticCurveTo(x, y + h, x, y + h - rad);
            ctx.lineTo(x, y + rad);
            ctx.quadraticCurveTo(x, y, x + rad, y);
            ctx.closePath();
          }

          // 1. Draw white card with soft shadow (the "mat")
          pctx.save();
          pctx.shadowColor = "rgba(0,0,0,0.12)";
          pctx.shadowBlur = 30;
          pctx.shadowOffsetX = 0;
          pctx.shadowOffsetY = 10;
          rrPath(pctx, cx, cy, cw, ch, cardR);
          pctx.fillStyle = "#ffffff";
          pctx.fill();
          pctx.restore();

          // 2. Draw photo with rounded corners inside the card
          pctx.save();
          rrPath(pctx, dx, dy, dw, dh, r);
          pctx.clip();
          pctx.drawImage(img, dx, dy, dw, dh);
          pctx.restore();

          // 3. Subtle inner border on photo
          pctx.save();
          rrPath(pctx, dx, dy, dw, dh, r);
          pctx.strokeStyle = "rgba(0,0,0,0.05)";
          pctx.lineWidth = 1;
          pctx.stroke();
          pctx.restore();

          // 4. Card border (very subtle)
          pctx.save();
          rrPath(pctx, cx, cy, cw, ch, cardR);
          pctx.strokeStyle = "rgba(0,0,0,0.04)";
          pctx.lineWidth = 1;
          pctx.stroke();
          pctx.restore();

          // ===== CAPTION & EMOTION OVERLAY on photo bottom (inside photo bounds) =====
          const overlayH = dh * 0.16; // 16% of photo height for text
          const overlayY = dy + dh - overlayH;

          // Gradient within rounded photo area
          const grad = pctx.createLinearGradient(0, overlayY, 0, dy + dh);
          grad.addColorStop(0, "rgba(0,0,0,0.0)");
          grad.addColorStop(0.40, "rgba(0,0,0,0.30)");
          grad.addColorStop(1, "rgba(0,0,0,0.55)");
          pctx.fillStyle = grad;

          pctx.save();
          rrPath(pctx, dx, dy, dw, dh, r);
          pctx.clip();
          pctx.fillRect(dx, overlayY, dw, overlayH);
          pctx.restore();

          // Caption text (inside photo, bottom area)
          if (photo.caption) {
            pctx.fillStyle = "#ffffff";
            pctx.textAlign = "center";
            pctx.textBaseline = "bottom";
            pctx.font = `bold ${Math.max(15, PW_PX * 0.026)}px sans-serif`;
            pctx.shadowColor = "rgba(0,0,0,0.4)";
            pctx.shadowBlur = 3;
            pctx.fillText(photo.caption, PW_PX / 2, dy + dh - PH_PX * 0.015);
            pctx.shadowColor = "transparent";
          }

          // Emotion tag (inside photo, very bottom)
          if (photo.emotion) {
            const emo = photo.emotion === "Счастье" ? "🌞 Счастье" :
                        photo.emotion === "Любовь" ? "❤️ Любовь" :
                        photo.emotion === "Ностальгия" ? "🏛️ Ностальгия" :
                        photo.emotion === "Уют" ? "🕯️ Уют" :
                        photo.emotion === "Вдохновение" ? "✨ Вдохновение" : photo.emotion;
            pctx.fillStyle = "rgba(255,255,255,0.80)";
            pctx.font = `400 ${Math.max(11, PW_PX * 0.018)}px sans-serif`;
            pctx.textBaseline = "bottom";
            pctx.fillText(emo, PW_PX / 2, dy + dh - PH_PX * 0.005);
          }
        } catch {
          pctx.fillStyle = "#e5ddd0";
          pctx.fillRect(PW_PX * 0.03, marginTop + 20, PW_PX * 0.94, availH - 40);
          pctx.fillStyle = "#8a8279";
          pctx.textAlign = "center";
          pctx.font = `300 ${PW_PX * 0.03}px sans-serif`;
          pctx.fillText("Не удалось загрузить фото", PW_PX / 2, PH_PX * 0.45);
        }

        // Page number at very bottom
        pctx.fillStyle = "#8a8279";
        pctx.textAlign = "center";
        pctx.textBaseline = "bottom";
        pctx.font = `300 ${Math.max(11, PW_PX * 0.018)}px sans-serif`;
        pctx.fillText(`${i + 1} / ${photos.length}`, PW_PX / 2, PH_PX * 0.98);

        pdf.addImage(pCanvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, PW_MM, PH_MM);
      }

      // ============ FINAL PAGE ============
      pdf.addPage();
      const fCanvas = document.createElement("canvas");
      fCanvas.width = PW_PX;
      fCanvas.height = PH_PX;
      const fctx = fCanvas.getContext("2d")!;

      // Apply selected background (preset or custom)
      if (customBgUrl) {
        try {
          const bgImg = await loadImage(customBgUrl);
          fctx.drawImage(bgImg, 0, 0, PW_PX, PH_PX);
        } catch {
          applyBackground(fctx, PW_PX, PH_PX);
        }
      } else {
        applyBackground(fctx, PW_PX, PH_PX);
      }

      fctx.strokeStyle = "#c9a87c";
      fctx.lineWidth = 2;
      fctx.beginPath();
      fctx.moveTo(PW_PX * 0.15, PH_PX * 0.06);
      fctx.lineTo(PW_PX * 0.85, PH_PX * 0.06);
      fctx.stroke();
      fctx.beginPath();
      fctx.moveTo(PW_PX * 0.15, PH_PX * 0.94);
      fctx.lineTo(PW_PX * 0.85, PH_PX * 0.94);
      fctx.stroke();

      // Custom message on final page (if provided)
      const msg = customMessage.trim();
      const msgFont = customFont === "serif" ? "serif" : "sans-serif";
      const msgSizePx = customSize === "small" ? Math.max(14, PW_PX * 0.022) :
                        customSize === "large" ? Math.max(24, PW_PX * 0.04) :
                        Math.max(18, PW_PX * 0.028);

      // Final page font, size and color settings
      const finalFont = finalPageFont || "serif";
      const finalColor = finalPageTextColor || "#6b4226";
      const finalSizeFactor = finalPageSize === "small" ? 0.035 :
                              finalPageSize === "large" ? 0.055 : 0.045;

      if (msg) {
        fctx.fillStyle = finalColor;
        fctx.textAlign = "center";
        fctx.textBaseline = "middle";
        fctx.font = `400 ${msgSizePx}px ${msgFont}`;

        // Word wrap for long messages
        const maxWidth = PW_PX * 0.75;
        const words = msg.split(" ");
        const lines: string[] = [];
        let currentLine = "";
        for (const word of words) {
          const test = currentLine ? currentLine + " " + word : word;
          const width = fctx.measureText(test).width;
          if (width > maxWidth && currentLine) {
            lines.push(currentLine);
            currentLine = word;
          } else {
            currentLine = test;
          }
        }
        if (currentLine) lines.push(currentLine);

        // If single word is too long, force break
        if (lines.length === 0) lines.push(msg);

        const lineHeight = msgSizePx * 1.4;
        const totalHeight = lines.length * lineHeight;
        const startY = PH_PX * 0.28 - totalHeight / 2 + lineHeight / 2;

        lines.forEach((line, idx) => {
          fctx.fillText(line, PW_PX / 2, startY + idx * lineHeight);
        });
      }

      // "Thank you" text — uses final page settings
      fctx.fillStyle = finalColor;
      fctx.textAlign = "center";
      fctx.textBaseline = "middle";
      fctx.font = `bold ${Math.max(28, PW_PX * finalSizeFactor)}px ${finalFont}`;
      const thanksY = msg ? PH_PX * 0.62 : PH_PX * 0.42;
      fctx.fillText("Спасибо за просмотр!", PW_PX / 2, thanksY);

      // Subtitle
      fctx.font = `300 ${Math.max(16, PW_PX * finalSizeFactor * 0.55)}px ${finalFont}`;
      fctx.fillStyle = finalColor + "CC"; // 80% opacity
      fctx.fillText("Создайте свой альбом на", PW_PX / 2, msg ? PH_PX * 0.72 : PH_PX * 0.52);

      // family-foto.ru
      fctx.fillStyle = finalColor;
      fctx.font = `600 ${Math.max(18, PW_PX * finalSizeFactor * 0.6)}px ${finalFont}`;
      fctx.fillText("family-foto.ru", PW_PX / 2, msg ? PH_PX * 0.77 : PH_PX * 0.58);

      pdf.addImage(fCanvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, PW_MM, PH_MM);

      // Save blob
      const blob = pdf.output("blob");
      setPdfBlobForShare(blob);
      setPdfFileName(fileName);

      // Show message input modal first (all platforms)
      if (!skipMessage) {
        setShowMessageModal(true);
      } else {
        setShowShareModal(true);
      }
    } catch (e: any) {
      console.error("PDF error:", e);
      alert("Ошибка PDF: " + (e?.message || "неизвестная ошибка"));
    } finally {
      setPdfLoading(false);
    }
  }

  function handleApplyMessage() {
    setShowMessageModal(false);
    // Re-generate PDF with the custom message included
    handleExportPDF(true);
  }

  function handleOpenPDF() {
    if (!pdfBlobForShare) return;
    const url = URL.createObjectURL(pdfBlobForShare);
    const newWindow = window.open(url, "_blank");
    if (!newWindow) {
      window.location.href = url;
    }
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  async function handleSharePDF() {
    if (!pdfBlobForShare) return;
    try {
      const file = new File([pdfBlobForShare], pdfFileName || "album.pdf", { type: "application/pdf" });
      if ((navigator as any).share && (navigator as any).canShare && (navigator as any).canShare({ files: [file] })) {
        await (navigator as any).share({
          title: album?.title || "Семейный альбом",
          text: `Альбом "${album?.title}" на family-foto.ru`,
          files: [file],
        });
      } else if ((navigator as any).share) {
        await (navigator as any).share({
          title: album?.title || "Семейный альбом",
          text: `Альбом "${album?.title}" на family-foto.ru`,
        });
      } else {
        alert("Для отправки PDF: на iOS нажмите 'Поделиться' в Safari внизу экрана. На Android используйте кнопку меню браузера.");
      }
      // Close share modal after successful share
      setShowShareModal(false);
    } catch (e: any) {
      if (e.name !== "AbortError") {
        console.error("Share error:", e);
      }
      // Also close on error (user cancelled or share completed)
      setShowShareModal(false);
    }
  }

  function loadImage(url: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const img = document.createElement("img");
      // Only set crossOrigin for external URLs, not for base64 data URLs
      if (!url.startsWith("data:")) {
        img.crossOrigin = "anonymous";
      }
      img.onload = () => resolve(img);
      img.onerror = (e) => {
        console.error("Image load failed:", url.substring(0, 50), e);
        reject(new Error("Failed to load image"));
      };
      img.src = url;
    });
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#c9a87c] animate-spin" />
      </div>
    );
  }

  if (!album) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center">
        <div className="text-center">
          <p className="text-[#8a8279] mb-4">Альбом не найден</p>
          <button
            type="button"
            onClick={() => { window.location.href = basePath + "#/"; }}
            className="bg-[#c9a87c] text-white px-6 py-2 rounded-xl"
          >
            На главную
          </button>
        </div>
      </div>
    );
  }

  const photos = album.photos || [];
  const year = album.year || new Date(album.createdAt).getFullYear();
  const month = album.month;
  const monthLabel = month
    ? [
        "Янв","Фев","Мар","Апр","Май","Июн",
        "Июл","Авг","Сен","Окт","Ноя","Дек",
      ][month - 1]
    : null;

  // For family_tree albums, render the family tree page
  if (album && album.albumType === "family_tree") {
    return <FamilyTreePage />;
  }

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      {/* Header — gradient only, cover photo removed to prevent button overlap */}
      <div
        className="relative px-4 py-4"
        style={{
          background: `linear-gradient(135deg, ${album.accentColor}25 0%, ${album.backgroundColor} 60%, ${album.accentColor}15 100%)`,
        }}
      >
        <div className="max-w-lg mx-auto">
          {/* Breadcrumbs */}
          <div className="flex items-center mb-3">
            <div className="flex items-center gap-1.5 text-sm">
              <span
                onClick={() => { window.location.href = window.location.pathname + "#/"; }}
                className="text-[#8a8279] hover:text-[#c9a87c] transition-colors cursor-pointer"
                style={{ touchAction: "manipulation" }}
              >
                Альбомы
              </span>
              <ChevronRight className="w-3.5 h-3.5 text-[#8a8279]" />
              <span className="text-[#4a4a4a] font-medium">{album.title}</span>
            </div>
          </div>

          {/* Year */}
          <p className="text-sm text-[#8a8279] mb-1">
            {year}
            {monthLabel ? ` · ${monthLabel}` : ""}
          </p>

          {/* Title */}
          <h1 className="text-3xl font-serif text-[#4a4a4a] mb-3">
            {album.title}
          </h1>

          {/* Tags */}
          <div className="flex items-center gap-2 flex-wrap mb-4">
            <span className="bg-white/80 backdrop-blur-sm rounded-full px-3 py-1 text-xs text-[#4a4a4a] flex items-center gap-1.5">
              <Calendar className="w-3 h-3" />
              {year}{monthLabel ? ` · ${monthLabel}` : ""}
            </span>
            <span className="bg-white/80 backdrop-blur-sm rounded-full px-3 py-1 text-xs text-[#4a4a4a] flex items-center gap-1.5">
              <MapPin className="w-3 h-3" />
              {album.description || "Локация"}
            </span>
            <span className="bg-white/80 backdrop-blur-sm rounded-full px-3 py-1 text-xs text-[#4a4a4a] flex items-center gap-1.5">
              <Image className="w-3 h-3" />
              {photos.length} фото
            </span>
          </div>

          {/* Action buttons — <button type="button"> most reliable on iOS */}
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={(e) => { e.stopPropagation(); handleInvite(); }}
              className="bg-white rounded-xl py-2.5 flex items-center justify-center gap-1 text-sm text-[#4a4a4a] shadow-sm border border-[#e5ddd0] active:bg-[#f0ebe3]"
              style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
            >
              <Users className="w-4 h-4" />
              <span>Пригласить</span>
            </button>
            <button
              type="button"
              onClick={handleBook}
              className="bg-white rounded-xl py-2.5 flex items-center justify-center gap-1 text-sm text-[#4a4a4a] shadow-sm border border-[#e5ddd0] active:bg-[#f0ebe3]"
              style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
            >
              <BookOpen className="w-4 h-4" />
              <span>Книга</span>
            </button>
            <button
              type="button"
              onClick={() => { if (!pdfLoading) setShowBgModal(true); }}
              disabled={pdfLoading}
              className="bg-white rounded-xl py-2.5 px-1 flex flex-col items-center justify-center gap-0.5 text-xs text-[#4a4a4a] shadow-sm border border-[#e5ddd0] active:bg-[#f0ebe3] disabled:opacity-50 leading-tight"
              style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
            >
              {pdfLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <FileText className="w-3.5 h-3.5" />
              )}
              <span>Скачать</span>
              <span>альбом</span>
            </button>
          </div>
        </div>
      </div>

      <main className="max-w-5xl xl:max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        {/* Add + Delete buttons */}
        <div className="flex gap-3 mb-4">
          <button
            type="button"
            onClick={() => {
              if (deleteMode) setDeleteMode(false);
              window.location.href = window.location.pathname + "#/album/" + albumId + "/add-photo";
            }}
            className="flex-1 bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-2xl py-3 flex items-center justify-center gap-2 font-medium shadow-sm"
            style={{ touchAction: "manipulation" }}
          >
            <Plus className="w-4 h-4" />
            Добавить
          </button>
          <button
            type="button"
            onClick={toggleDeleteMode}
            className={`flex-1 rounded-2xl py-3 flex items-center justify-center gap-2 font-medium border ${
              deleteMode
                ? "bg-red-50 text-red-500 border-red-200"
                : "bg-white text-[#4a4a4a] border-[#e5ddd0] active:bg-red-50 active:text-red-500"
            }`}
            style={{ touchAction: "manipulation" }}
          >
            {deleteMode ? (
              <>
                <X className="w-4 h-4" />
                Отмена
              </>
            ) : (
              <>
                <Trash2 className="w-4 h-4" />
                Удалить
              </>
            )}
          </button>
        </div>

        {/* Delete mode toolbar */}
        {deleteMode && (
          <div className="flex items-center justify-between bg-white rounded-2xl px-4 py-3 mb-4 shadow-sm border border-[#e5ddd0]">
            <button
              type="button"
              onClick={selectAll}
              className="flex items-center gap-2 text-sm text-[#4a4a4a] active:text-[#c9a87c] transition-colors"
              style={{ touchAction: "manipulation" }}
            >
              {selectedToDelete.length === photos.length && photos.length > 0 ? (
                <CheckSquare className="w-4 h-4 text-[#c9a87c]" />
              ) : (
                <Square className="w-4 h-4 text-[#8a8279]" />
              )}
              {selectedToDelete.length === photos.length && photos.length > 0
                ? "Снять все"
                : "Выбрать все"}
            </button>
            {selectedToDelete.length > 0 && (
              <button
                type="button"
                onClick={handleBulkDelete}
                className="bg-red-500 active:bg-red-600 text-white text-sm px-4 py-2 rounded-xl font-medium"
                style={{ touchAction: "manipulation" }}
              >
                Удалить ({selectedToDelete.length})
              </button>
            )}
          </div>
        )}

        {/* Photo counter */}
        <p className="text-sm text-[#8a8279] mb-3">
          {photos.length} фотографий
        </p>

        {/* Photos Grid */}
        {photos.length > 0 ? (
          <div className="grid grid-cols-2 gap-3">
            {photos.map((photo: Photo) => {
              const isSelected = selectedToDelete.includes(photo.id);
              return (
                <div
                  key={photo.id}
                  className="relative rounded-2xl overflow-hidden bg-[#e5ddd0] shadow-sm"
                  onClick={() => {
                    if (deleteMode) {
                      togglePhotoSelection(photo.id);
                    } else {
                      setSelectedPhoto(photo);
                    }
                  }}
                >
                  <img
                    src={photo.url}
                    alt={photo.caption || ""}
                    className="w-full aspect-square object-cover"
                  />

                  {/* Delete mode checkbox */}
                  {deleteMode && (
                    <div className="absolute top-2 left-2">
                      <div
                        className={`w-6 h-6 rounded-md flex items-center justify-center border-2 transition-colors ${
                          isSelected
                            ? "bg-[#c9a87c] border-[#c9a87c]"
                            : "bg-white/80 border-white"
                        }`}
                      >
                        {isSelected && <Check className="w-4 h-4 text-white" />}
                      </div>
                    </div>
                  )}

                  {/* Cover indicator */}
                  {!deleteMode && photo.isCover && (
                    <span className="absolute bottom-2 left-2 bg-[#c9a87c] text-white text-[10px] px-2 py-0.5 rounded-full">
                      Обложка
                    </span>
                  )}

                  {/* Emotion tag */}
                  {!deleteMode && photo.emotion && (
                    <span className="absolute top-2 right-2 bg-white/90 rounded-full px-1.5 py-0.5 text-[10px] shadow-sm">
                      {photo.emotion === "Счастье" ? "🌞" :
                       photo.emotion === "Любовь" ? "❤️" :
                       photo.emotion === "Ностальгия" ? "🏛️" :
                       photo.emotion === "Уют" ? "🕯️" :
                       photo.emotion === "Вдохновение" ? "✨" : "🎭"}
                    </span>
                  )}

                  {/* Selected overlay */}
                  {deleteMode && isSelected && (
                    <div className="absolute inset-0 bg-[#c9a87c]/20 border-2 border-[#c9a87c] rounded-2xl pointer-events-none" />
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16">
            <Image className="w-12 h-12 text-[#c9a87c]/30 mx-auto mb-4" />
            <p className="text-[#8a8279] mb-4">
              В этом альбоме пока нет фотографий
            </p>
            <button
              type="button"
              onClick={() => { window.location.href = basePath + "#/album/" + albumId + "/add-photo"; }}
              className="bg-[#c9a87c] text-white px-6 py-2 rounded-xl text-sm font-medium"
            >
              Добавить первое фото
            </button>
          </div>
        )}
      </main>

      {/* Photo Modal — simple iOS-safe layout */}
      {selectedPhoto && !deleteMode && (
        <div
          className="fixed inset-0 bg-black/90 z-50 overflow-y-auto"
          style={{ touchAction: "none", overscrollBehavior: "none" }}
          onClick={(e) => {
            // Close modal when clicking on backdrop (not on photo/buttons)
            if (e.target === e.currentTarget) {
              setSelectedPhoto(null);
            }
          }}
        >
          {/* Top bar */}
          <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3 bg-black/50">
            {/* Emotions */}
            <div className="flex items-center gap-1.5">
              {[
                { key: "Счастье", icon: "🌞" },
                { key: "Любовь", icon: "❤️" },
                { key: "Ностальгия", icon: "🏛️" },
                { key: "Уют", icon: "🕯️" },
                { key: "Вдохновение", icon: "✨" },
              ].map((emo) => {
                const active = selectedPhoto.emotion === emo.key;
                return (
              <button
                    key={emo.key}
                    type="button"
                    onClick={async () => {
                      const newEmotion = active ? null : emo.key;
                      // Local update for instant visual feedback
                      setSelectedPhoto((prev) => prev ? { ...prev, emotion: newEmotion } : null);
                      await photoApi.update(selectedPhoto.id, { emotion: newEmotion });
                      await loadAlbum();
                    }}
                    className={`text-[10px] px-2 py-1 rounded-full border select-none transition-colors ${
                      active
                        ? "bg-[#c9a87c] text-white border-[#c9a87c]"
                        : "bg-white/20 text-white border-white/30"
                    }`}
                    style={{ touchAction: "manipulation" }}
                  >
                    {emo.icon}
                  </button>
                );
              })}
            </div>
            {/* Close */}
            <button
              type="button"
              onClick={() => setSelectedPhoto(null)}
              className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center text-white"
              style={{ touchAction: "manipulation" }}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Photo */}
          <div className="px-4 py-2">
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.caption || ""}
              className="w-full rounded-xl"
              draggable={false}
            />
          </div>

          {/* Caption */}
          {selectedPhoto.caption && (
            <div className="px-4 py-2 text-center">
              <span className="text-white/80 text-sm">{selectedPhoto.caption}</span>
            </div>
          )}

          {/* Bottom actions */}
          <div className="px-4 py-4 flex items-center justify-between gap-3" style={{ paddingBottom: "max(20px, env(safe-area-inset-bottom))" }}>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={async () => {
                  setSelectedPhoto((prev) => prev ? { ...prev, isCover: true } : null);
                  await photoApi.setCover(albumId, selectedPhoto.id);
                  await albumApi.update(albumId, { coverPhoto: selectedPhoto.url });
                  await loadAlbum();
                }}
                className={`text-white text-sm px-5 py-3 rounded-full transition-colors min-h-[44px] min-w-[90px] font-medium select-none ${
                  selectedPhoto.isCover
                    ? "bg-[#c9a87c]"
                    : "bg-white/20 border border-white/30 active:bg-white/40"
                }`}
                style={{ touchAction: "manipulation" }}
              >
                {selectedPhoto.isCover ? "✓ Обложка" : "Обложкой"}
              </button>
            </div>
            <button
              type="button"
              onClick={() => handleDeletePhoto(selectedPhoto.id)}
              className="bg-red-600 active:bg-red-700 text-white text-sm px-6 py-3 rounded-full min-h-[44px] min-w-[80px] font-medium select-none"
              style={{ touchAction: "manipulation" }}
            >
              Удалить
            </button>
          </div>
        </div>
      )}

      {/* Invite Modal */}
      {showInviteModal && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowInviteModal(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">Пригласить</h3>
              <button
                type="button"
                onClick={() => setShowInviteModal(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8a8279] mb-3">
              Отправьте ссылку друзьям и семье
            </p>
            <div className="bg-[#f5f0ea] rounded-xl p-3 mb-3 break-all text-xs text-[#4a4a4a]">
              {inviteLink}
            </div>
            <button
              type="button"
              onClick={handleShareInvite}
              className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-2.5 flex items-center justify-center gap-2 font-medium mb-2"
            >
              <Share2 className="w-4 h-4" />
              Поделиться ссылкой
            </button>
            <button
              type="button"
              onClick={copyLink}
              className="w-full bg-[#f5f0ea] active:bg-[#e5ddd0] text-[#4a4a4a] rounded-xl py-2.5 flex items-center justify-center gap-2 font-medium text-sm"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-green-600" />
                  <span className="text-green-600">Скопировано!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Копировать ссылку
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Message Input Modal */}
      {showMessageModal && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowMessageModal(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">Ваше пожелание</h3>
              <button
                type="button"
                onClick={() => setShowMessageModal(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8a8279] mb-3">
              Добавьте личное послание на последнюю страницу альбома
            </p>
            <textarea
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder="Напишите тёплые слова..."
              rows={3}
              className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm mb-3 resize-none"
            />
            {/* Font selector */}
            <div className="flex gap-2 mb-3">
              <button
                type="button"
                onClick={() => setCustomFont("serif")}
                className={`flex-1 py-2 rounded-xl text-sm border transition-colors ${
                  customFont === "serif"
                    ? "bg-[#c9a87c] text-white border-[#c9a87c]"
                    : "bg-white text-[#4a4a4a] border-[#e5ddd0]"
                }`}
              >
                Классический
              </button>
              <button
                type="button"
                onClick={() => setCustomFont("sans-serif")}
                className={`flex-1 py-2 rounded-xl text-sm border transition-colors ${
                  customFont === "sans-serif"
                    ? "bg-[#c9a87c] text-white border-[#c9a87c]"
                    : "bg-white text-[#4a4a4a] border-[#e5ddd0]"
                }`}
              >
                Современный
              </button>
            </div>
            {/* Size selector */}
            <div className="flex gap-2 mb-4">
              {[
                { key: "small", label: "Мелкий" },
                { key: "medium", label: "Средний" },
                { key: "large", label: "Крупный" },
              ].map((s) => (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => setCustomSize(s.key as any)}
                  className={`flex-1 py-2 rounded-xl text-sm border transition-colors ${
                    customSize === s.key
                      ? "bg-[#c9a87c] text-white border-[#c9a87c]"
                      : "bg-white text-[#4a4a4a] border-[#e5ddd0]"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={handleApplyMessage}
              className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-3 font-medium mb-2"
            >
              Готово
            </button>
            <button
              type="button"
              onClick={() => { setCustomMessage(""); handleApplyMessage(); }}
              className="w-full text-sm text-[#8a8279] py-2"
            >
              Пропустить
            </button>
          </div>
        </div>
      )}

      {/* Share PDF Modal */}
      {showShareModal && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowShareModal(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">PDF готов!</h3>
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8a8279] mb-4">
              PDF создан. Откройте его или отправьте в мессенджер.
            </p>
            <button
              type="button"
              onClick={handleOpenPDF}
              className="w-full bg-[#4a4a4a] active:bg-[#333333] text-white rounded-xl py-3 flex items-center justify-center gap-2 font-medium mb-2"
            >
              <FileText className="w-4 h-4" />
              Открыть PDF
            </button>
            <button
              type="button"
              onClick={handleSharePDF}
              className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-3 flex items-center justify-center gap-2 font-medium mb-3"
            >
              <Share2 className="w-4 h-4" />
              Поделиться альбомом
            </button>
            <p className="text-xs text-center text-[#8a8279]">
              Или нажмите "Поделиться" ↗️ в Safari после открытия PDF
            </p>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowDeleteConfirm(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <h3 className="text-lg font-serif text-[#4a4a4a]">Удалить фото?</h3>
                <p className="text-sm text-[#8a8279]">
                  {selectedToDelete.length} фотографи
                  {selectedToDelete.length === 1 ? "я" : selectedToDelete.length < 5 ? "и" : "й"}
                </p>
              </div>
            </div>
            <p className="text-sm text-[#8a8279] mb-4">
              Фото будут удалены безвозвратно.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 bg-[#f5f0ea] text-[#4a4a4a] rounded-xl py-3 font-medium"
                style={{ touchAction: "manipulation" }}
              >
                Отмена
              </button>
              <button
                type="button"
                onClick={confirmBulkDelete}
                className="flex-1 bg-red-500 active:bg-red-600 text-white rounded-xl py-3 font-medium"
                style={{ touchAction: "manipulation" }}
              >
                Удалить
              </button>
            </div>
          </div>
        </div>
      )}

      {showBgModal && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowBgModal(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-xl max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">Выберите фон</h3>
              <button
                type="button"
                onClick={() => setShowBgModal(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8a8279] mb-3">
              Фон для обложки и последней страницы
            </p>

            {/* Preview canvas */}
            <canvas
              ref={bgPreviewRef}
              width={300}
              height={400}
              className="w-full rounded-xl mb-4 border border-[#e5ddd0] bg-[#2a2520]"
            />

            {/* Preset backgrounds grid */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              {[
                { key: "none", label: "Без фона", icon: "⬜" },
                { key: "classic", label: "Классический", icon: "✨" },
                { key: "newyear", label: "Новый год", icon: "🎄" },
                { key: "birthday", label: "День рождения", icon: "🎂" },
                { key: "wedding", label: "Свадьба", icon: "💍" },
                { key: "travel", label: "Путешествие", icon: "✈️" },
                { key: "nature", label: "Природа", icon: "🌿" },
                { key: "color", label: "Свой цвет", icon: "🎨" },
              ].map((bg) => (
                <button
                  key={bg.key}
                  type="button"
                  onClick={() => { setSelectedBg(bg.key); setCustomBgUrl(null); }}
                  className={`rounded-xl p-3 text-center border transition-all ${
                    selectedBg === bg.key && !customBgUrl
                      ? "bg-[#c9a87c]/20 border-[#c9a87c] ring-2 ring-[#c9a87c]/30"
                      : "bg-[#faf8f5] border-[#e5ddd0]"
                  }`}
                >
                  <div className="text-2xl mb-1">{bg.icon}</div>
                  <div className="text-xs text-[#4a4a4a]">{bg.label}</div>
                </button>
              ))}
            </div>

            {/* Color picker — shown when "color" selected */}
            {selectedBg === "color" && (
              <div className="mb-4">
                <label className="block text-sm text-[#8a8279] mb-2">Выберите цвет фона</label>
                <div className="flex flex-wrap gap-2 mb-3">
                  {[
                    "#ffffff", "#f5f0ea", "#2a2520", "#8B0000", "#1a3a5c",
                    "#4a6741", "#6B3A5B", "#3d3d3d", "#FFF8F0", "#E8F4FD",
                    "#F0F5E8", "#FFF5F7", "#2d3436", "#5D4037", "#263238",
                  ].map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setCustomBgColor(c)}
                      className={`w-8 h-8 rounded-full border-2 transition-transform active:scale-90 ${
                        customBgColor === c ? "border-[#c9a87c] ring-2 ring-[#c9a87c]/40 scale-110" : "border-transparent"
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={customBgColor}
                    onChange={(e) => setCustomBgColor(e.target.value)}
                    className="w-10 h-10 rounded-xl border border-[#e5ddd0] cursor-pointer"
                  />
                  <input
                    type="text"
                    value={customBgColor}
                    onChange={(e) => setCustomBgColor(e.target.value)}
                    placeholder="#RRGGBB"
                    className="flex-1 px-3 py-2 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] uppercase"
                  />
                </div>
              </div>
            )}

            {/* Font & Text Color for final page */}
            <div className="mb-4 border-t border-[#e5ddd0] pt-4">
              <label className="block text-sm text-[#8a8279] mb-2">Шрифт последней страницы</label>
              <select
                value={finalPageFont}
                onChange={(e) => setFinalPageFont(e.target.value)}
                className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] mb-3 focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
              >
                <option value="serif">Классический (serif)</option>
                <option value="sans-serif">Современный (sans-serif)</option>
                <option value="cursive">Рукописный (cursive)</option>
                <option value="Georgia">Georgia</option>
                <option value="Times New Roman">Times New Roman</option>
                <option value="Courier New">Courier New</option>
                <option value="Verdana">Verdana</option>
                <option value="Palatino">Palatino</option>
                <option value="Garamond">Garamond</option>
              </select>

              <label className="block text-sm text-[#8a8279] mb-2">Размер текста</label>
              <div className="flex gap-2 mb-3">
                {[
                  { key: "small", label: "Мелкий" },
                  { key: "medium", label: "Средний" },
                  { key: "large", label: "Крупный" },
                ].map((s) => (
                  <button
                    key={s.key}
                    type="button"
                    onClick={() => setFinalPageSize(s.key)}
                    className={`flex-1 py-2 rounded-xl text-sm border transition-colors ${
                      finalPageSize === s.key
                        ? "bg-[#c9a87c] text-white border-[#c9a87c]"
                        : "bg-white text-[#4a4a4a] border-[#e5ddd0]"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>

              <label className="block text-sm text-[#8a8279] mb-2">Цвет текста</label>
              <div className="flex flex-wrap gap-2 mb-3">
                {[
                  "#ffffff", "#f5f0ea", "#2a2520", "#6b4226", "#8B0000",
                  "#1a3a5c", "#4a6741", "#6B3A5B", "#c9a87c", "#3d3d3d",
                ].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setFinalPageTextColor(c)}
                    className={`w-8 h-8 rounded-full border-2 transition-transform active:scale-90 ${
                      finalPageTextColor === c ? "border-[#c9a87c] ring-2 ring-[#c9a87c]/40 scale-110" : "border-transparent"
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={finalPageTextColor}
                  onChange={(e) => setFinalPageTextColor(e.target.value)}
                  className="w-10 h-10 rounded-xl border border-[#e5ddd0] cursor-pointer"
                />
                <input
                  type="text"
                  value={finalPageTextColor}
                  onChange={(e) => setFinalPageTextColor(e.target.value)}
                  placeholder="#RRGGBB"
                  className="flex-1 px-3 py-2 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] uppercase"
                />
              </div>
            </div>

            {/* Custom background upload */}
            <div className="mb-4">
              <label className="block text-sm text-[#8a8279] mb-2">Или загрузите свой фон</label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                      setCustomBgUrl(ev.target?.result as string);
                      setSelectedBg("custom");
                    };
                    reader.readAsDataURL(file);
                  }
                }}
                className="w-full text-xs text-[#4a4a4a] file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:bg-[#c9a87c] file:text-white"
              />
              {customBgUrl && (
                <div className="mt-2 relative">
                  <img src={customBgUrl} alt="Custom bg" className="w-full h-20 object-cover rounded-xl" />
                  <button
                    type="button"
                    onClick={() => { setCustomBgUrl(null); setSelectedBg("classic"); }}
                    className="absolute top-1 right-1 w-6 h-6 bg-black/50 rounded-full text-white flex items-center justify-center"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => { setShowBgModal(false); setShowMessageModal(true); }}
              className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-3 font-medium mb-2"
            >
              Продолжить
            </button>
            <button
              type="button"
              onClick={() => { setShowBgModal(false); }}
              className="w-full text-sm text-[#8a8279] py-2"
            >
              Отмена
            </button>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}