import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft, Trash2, RotateCcw, Clock, AlertTriangle, BookOpen, Image, Users
} from "lucide-react";
import Footer from "../components/Footer";
import { albumApi, photoApi, getDaysRemaining, cleanupOldDeletedItems } from "../lib/api";

export default function TrashPage() {
  const navigate = useNavigate();
  const [deletedAlbums, setDeletedAlbums] = useState<any[]>([]);
  const [deletedPhotos, setDeletedPhotos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cleanupOldDeletedItems();
    loadTrash();
  }, []);

  async function loadTrash() {
    setLoading(true);
    try {
      const albums = await albumApi.listDeleted();
      setDeletedAlbums(albums);
      const photos = await photoApi.listDeleted();
      setDeletedPhotos(photos);
    } catch (e) {
      console.error("[Trash] load error:", e);
    } finally {
      setLoading(false);
    }
  }

  async function restoreAlbum(id: number | string) {
    try {
      await albumApi.restore(id);
    } catch (e: any) {
      console.error("[restoreAlbum] error:", e?.message || e);
    }
    await loadTrash();
  }

  async function restorePhoto(id: number | string) {
    try {
      await photoApi.restore(id);
    } catch (e: any) {
      console.error("[restorePhoto] error:", e?.message || e);
    }
    await loadTrash();
  }

  const totalItems = deletedAlbums.length + deletedPhotos.length;

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      {/* Header */}
      <header className="bg-white border-b border-[#e5ddd0]/50 sticky top-0 z-10">
        <div className="max-w-5xl xl:max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center gap-3">
          <button
            onClick={() => navigate("/")}
            className="w-9 h-9 rounded-xl bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-serif text-[#4a4a4a]">Корзина</h1>
          {totalItems > 0 && (
            <span className="ml-auto text-xs text-[#8a8279] bg-[#f5f0ea] px-2 py-1 rounded-lg">
              {totalItems} удалённых
            </span>
          )}
        </div>
      </header>

      <main className="max-w-5xl xl:max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 pb-24 space-y-4">
        {/* Info */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-amber-800 font-medium">Элементы хранятся 30 дней</p>
            <p className="text-xs text-amber-600 mt-0.5">
              После истечения срока они удаляются автоматически и безвозвратно.
            </p>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12 text-[#8a8279]">Загрузка...</div>
        ) : totalItems === 0 ? (
          <div className="text-center py-16">
            <Trash2 className="w-12 h-12 text-[#e5ddd0] mx-auto mb-3" />
            <p className="text-[#8a8279]">Корзина пуста</p>
          </div>
        ) : (
          <>
            {/* Deleted Albums */}
            {deletedAlbums.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-[#4a4a4a] mb-3 flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-[#c9a87c]" />
                  Альбомы ({deletedAlbums.length})
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {deletedAlbums.map((album) => (
                    <div
                      key={album.id}
                      className="bg-white rounded-2xl p-4 shadow-sm border border-red-100 opacity-70"
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 rounded-xl bg-[#f5f0ea] flex items-center justify-center">
                          <BookOpen className="w-5 h-5 text-[#8a8279]" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-[#4a4a4a] truncate">{album.title}</p>
                          <div className="flex items-center gap-1 text-xs text-red-400">
                            <Clock className="w-3 h-3" />
                            {getDaysRemaining(album.deletedAt)} дн. до удаления
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => restoreAlbum(album.id)}
                        className="w-full flex items-center justify-center gap-1 py-2 bg-[#c9a87c]/10 text-[#c9a87c] rounded-xl text-sm active:bg-[#c9a87c]/20"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Восстановить
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {/* Deleted Photos */}
            {deletedPhotos.length > 0 && (
              <section>
                <h2 className="text-sm font-medium text-[#4a4a4a] mb-3 flex items-center gap-2">
                  <Image className="w-4 h-4 text-[#c9a87c]" />
                  Фотографии ({deletedPhotos.length})
                </h2>
                <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-2">
                  {deletedPhotos.map((photo) => (
                    <div
                      key={photo.id}
                      className="relative aspect-square rounded-xl overflow-hidden bg-[#f5f0ea] opacity-60 border border-red-100"
                    >
                      <img
                        src={photo.url || photo.thumbnail}
                        alt={photo.caption || ""}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                      <div className="absolute inset-x-0 bottom-0 bg-black/50 p-1">
                        <p className="text-[10px] text-white text-center truncate">
                          {photo.caption || "Фото"}
                        </p>
                        <div className="flex items-center justify-center gap-1 text-[9px] text-red-300">
                          <Clock className="w-2.5 h-2.5" />
                          {getDaysRemaining(photo.deletedAt)} дн.
                        </div>
                      </div>
                      <button
                        onClick={() => restorePhoto(photo.id)}
                        className="absolute top-1 right-1 w-7 h-7 bg-white/90 rounded-full flex items-center justify-center text-[#c9a87c] active:bg-white"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </section>
            )}
          </>
        )}
      </main>

      <Footer />
    </div>
  );
}
