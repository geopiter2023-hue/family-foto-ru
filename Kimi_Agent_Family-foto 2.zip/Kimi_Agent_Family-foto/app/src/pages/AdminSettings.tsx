import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft, Save, Globe, Palette, ToggleRight, ToggleLeft,
  Lock, Mail, MessageCircle, Users, Image, BookOpen, TreePine,
  Star, UserPlus, FolderOpen, AlertTriangle
} from "lucide-react";
import Footer from "../components/Footer";
import { getSettings, saveSettings, changeAdminPassword, getStorageUsage } from "../lib/api";

export default function AdminSettings() {
  const navigate = useNavigate();
  const [settings, setSettings] = useState(getSettings());
  const [saved, setSaved] = useState(false);
  const [currentPass, setCurrentPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [passError, setPassError] = useState("");
  const [passSuccess, setPassSuccess] = useState(false);
  const [storage, setStorage] = useState(getStorageUsage());

  useEffect(() => {
    const t = setInterval(() => setStorage(getStorageUsage()), 5000);
    return () => clearInterval(t);
  }, []);

  function handleSave() {
    saveSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  function handleToggleFeature(key: keyof typeof settings.features) {
    setSettings((prev) => ({
      ...prev,
      features: { ...prev.features, [key]: !prev.features[key] },
    }));
  }

  function handleChangePassword() {
    setPassError("");
    setPassSuccess(false);
    if (!currentPass || !newPass) {
      setPassError("Заполните оба поля");
      return;
    }
    if (newPass.length < 4) {
      setPassError("Пароль минимум 4 символа");
      return;
    }
    const ok = changeAdminPassword(currentPass, newPass);
    if (ok) {
      setPassSuccess(true);
      setCurrentPass("");
      setNewPass("");
    } else {
      setPassError("Текущий пароль неверный");
    }
  }

  const featureList = [
    { key: "registration" as const, label: "Регистрация новых пользователей", icon: UserPlus },
    { key: "albums" as const, label: "Создание альбомов", icon: FolderOpen },
    { key: "photos" as const, label: "Загрузка фото", icon: Image },
    { key: "familyTree" as const, label: "Семейное древо", icon: TreePine },
    { key: "invites" as const, label: "Приглашения", icon: Users },
    { key: "reviews" as const, label: "Отзывы", icon: Star },
    { key: "demoData" as const, label: "Демо-данные", icon: BookOpen },
  ];

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      {/* Header */}
      <header className="bg-white border-b border-[#e5ddd0]/50 sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 h-14 flex items-center gap-3">
          <button
            onClick={() => navigate("/admin")}
            className="w-9 h-9 rounded-xl bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-serif text-[#4a4a4a]">Настройки системы</h1>
          {saved && (
            <span className="ml-auto text-xs text-green-600 bg-green-50 px-2 py-1 rounded-lg">
              Сохранено!
            </span>
          )}
        </div>
      </header>

      <main className="max-w-lg mx-auto p-4 space-y-4 pb-24">
        {/* Site Info */}
        <section className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-medium text-[#4a4a4a] mb-3 flex items-center gap-2">
            <Globe className="w-4 h-4 text-[#c9a87c]" />
            Информация о сайте
          </h2>
          <div className="space-y-3">
            <div>
              <label className="block text-xs text-[#8a8279] mb-1">Название сайта</label>
              <input
                type="text"
                value={settings.siteName}
                onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                className="w-full px-3 py-2 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5]"
              />
            </div>
            <div>
              <label className="block text-xs text-[#8a8279] mb-1">Email поддержки</label>
              <input
                type="email"
                value={settings.supportEmail}
                onChange={(e) => setSettings({ ...settings, supportEmail: e.target.value })}
                className="w-full px-3 py-2 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5]"
              />
            </div>
          </div>
        </section>

        {/* Social Links */}
        <section className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-medium text-[#4a4a4a] mb-3 flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-[#c9a87c]" />
            Социальные сети
          </h2>
          <div className="space-y-3">
            {(["telegram", "vk", "instagram", "youtube"] as const).map((key) => (
              <div key={key}>
                <label className="block text-xs text-[#8a8279] mb-1 capitalize">{key}</label>
                <input
                  type="url"
                  value={settings.social[key]}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      social: { ...settings.social, [key]: e.target.value },
                    })
                  }
                  className="w-full px-3 py-2 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5]"
                />
              </div>
            ))}
          </div>
        </section>

        {/* Features Toggle */}
        <section className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-medium text-[#4a4a4a] mb-3 flex items-center gap-2">
            <Palette className="w-4 h-4 text-[#c9a87c]" />
            Управление функциями
          </h2>
          <div className="space-y-2">
            {featureList.map((f) => (
              <button
                key={f.key}
                onClick={() => handleToggleFeature(f.key)}
                className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-[#f5f0ea] transition-colors"
              >
                <div className="flex items-center gap-2">
                  <f.icon className="w-4 h-4 text-[#8a8279]" />
                  <span className="text-sm text-[#4a4a4a]">{f.label}</span>
                </div>
                {settings.features[f.key] ? (
                  <ToggleRight className="w-5 h-5 text-[#c9a87c]" />
                ) : (
                  <ToggleLeft className="w-5 h-5 text-[#b0a898]" />
                )}
              </button>
            ))}
          </div>
        </section>

        {/* Storage Monitor */}
        <section className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-medium text-[#4a4a4a] mb-3 flex items-center gap-2">
            <FolderOpen className="w-4 h-4 text-[#c9a87c]" />
            Мониторинг хранилища
          </h2>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-[#8a8279]">Использовано:</span>
              <span className={storage.warning ? "text-red-500 font-medium" : "text-[#4a4a4a]"}>
                {storage.percent}% ({Math.round(storage.used / 1024)} KB / {Math.round(storage.limit / 1024)} KB)
              </span>
            </div>
            {/* Progress bar */}
            <div className="w-full h-2 bg-[#f5f0ea] rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${storage.warning ? "bg-red-400" : "bg-[#c9a87c]"}`}
                style={{ width: `${Math.min(storage.percent, 100)}%` }}
              />
            </div>
            {storage.warning && (
              <div className="flex items-center gap-1 text-xs text-red-500">
                <AlertTriangle className="w-3 h-3" />
                Хранилище заполнено более чем на 80%!
              </div>
            )}
          </div>
        </section>

        {/* Change Password */}
        <section className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-medium text-[#4a4a4a] mb-3 flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#c9a87c]" />
            Смена пароля админа
          </h2>
          <div className="space-y-3">
            <input
              type="password"
              placeholder="Текущий пароль"
              value={currentPass}
              onChange={(e) => setCurrentPass(e.target.value)}
              className="w-full px-3 py-2 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5]"
            />
            <input
              type="password"
              placeholder="Новый пароль"
              value={newPass}
              onChange={(e) => setNewPass(e.target.value)}
              className="w-full px-3 py-2 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5]"
            />
            <button
              onClick={handleChangePassword}
              className="w-full bg-[#c9a87c] text-white py-2.5 rounded-xl text-sm font-medium active:bg-[#a6875a]"
            >
              Сменить пароль
            </button>
            {passError && <p className="text-xs text-red-500">{passError}</p>}
            {passSuccess && <p className="text-xs text-green-500">Пароль изменён!</p>}
          </div>
        </section>

        {/* Save Button */}
        <button
          onClick={handleSave}
          className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] shadow-sm"
        >
          <Save className="w-4 h-4" />
          Сохранить все настройки
        </button>
      </main>

      <Footer />
    </div>
  );
}
