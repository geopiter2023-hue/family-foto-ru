import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAdminStats, listStorageFiles, getInvitedUsers, getSettings } from "../lib/api";
import { ArrowLeft, Lock, Users, Image, BookOpen, Star, MessageSquare, Loader2, FolderOpen, Settings } from "lucide-react";
import Footer from "../components/Footer";

export default function AdminPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [authorized, setAuthorized] = useState(false);
  const [checking, setChecking] = useState(false);
  const [stats, setStats] = useState<ReturnType<typeof getAdminStats> | null>(null);
  const [storagePhotos, setStoragePhotos] = useState<string[]>([]);

  function loadStoragePhotos() {
    listStorageFiles("family-foto", "photos").then((urls) => {
      console.log("[Admin] storage photos:", urls.length);
      setStoragePhotos(urls);
    }).catch((e) => console.error("[Admin] storage error:", e));
  }

  function handleLogin() {
    const settings = getSettings();
    if (password !== settings.adminPassword) {
      alert("Неверный пароль");
      return;
    }
    setChecking(true);
    setTimeout(() => {
      setAuthorized(true);
      setStats(getAdminStats());
      loadStoragePhotos();
      setChecking(false);
    }, 500);
  }

  if (!authorized) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl p-6 shadow-sm max-w-sm w-full text-center">
          <div className="w-14 h-14 bg-[#c9a87c]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock className="w-7 h-7 text-[#c9a87c]" />
          </div>
          <h1 className="text-xl font-serif text-[#4a4a4a] mb-4">Админ-панель</h1>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Пароль"
            className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] mb-3"
            onKeyDown={(e) => e.key === "Enter" && handleLogin()}
          />
          <button
            onClick={handleLogin}
            disabled={checking}
            className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium active:bg-[#a6875a] disabled:opacity-50"
          >
            {checking ? (
              <span className="flex items-center justify-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                Вход...
              </span>
            ) : (
              "Войти"
            )}
          </button>
          <button
            onClick={() => navigate("/")}
            className="mt-3 text-sm text-[#8a8279] hover:text-[#c9a87c]"
          >
            На главную
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      <header className="bg-white shadow-sm border-b border-[#e5ddd0]">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center gap-4">
          <button onClick={() => navigate("/")} className="text-[#8a8279]">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-serif text-[#4a4a4a]">Админ-панель</h1>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <StatCard icon={<BookOpen className="w-5 h-5" />} label="Альбомы" value={stats?.albums || 0} />
          <StatCard icon={<Image className="w-5 h-5" />} label="Фото" value={stats?.photos || 0} />
          <StatCard icon={<Users className="w-5 h-5" />} label="Пользователи" value={(stats?.users || 0) + getInvitedUsers().length} />
          <StatCard icon={<Users className="w-5 h-5" />} label="Приглашены" value={getInvitedUsers().length} />
        </div>

        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-medium text-[#4a4a4a] mb-3">Дополнительно</h2>
          <div className="space-y-2">
            <button
              onClick={() => navigate("/admin/settings")}
              className="w-full flex items-center gap-3 px-4 py-3 bg-[#f5f0ea] rounded-xl text-sm text-[#4a4a4a] active:bg-[#e5ddd0]"
            >
              <Settings className="w-4 h-4 text-[#c9a87c]" />
              Настройки системы
            </button>
            <button
              onClick={() => navigate("/support")}
              className="w-full flex items-center gap-3 px-4 py-3 bg-[#f5f0ea] rounded-xl text-sm text-[#4a4a4a] active:bg-[#e5ddd0]"
            >
              <MessageSquare className="w-4 h-4 text-[#c9a87c]" />
              Перейти в поддержку
            </button>
          </div>
        </div>

        {/* Storage Photos */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-medium text-[#4a4a4a]">
              <FolderOpen className="w-4 h-4 inline mr-1 text-[#c9a87c]" />
              Фото в хранилище ({storagePhotos.length})
            </h2>
            <button
              onClick={loadStoragePhotos}
              className="text-xs text-[#c9a87c] active:text-[#a6875a]"
            >
              Обновить
            </button>
          </div>
          {storagePhotos.length === 0 ? (
            <p className="text-xs text-[#8a8279] text-center py-4">
              Нет фото в Supabase Storage. Возможно, фото хранятся только в localStorage (base64).
            </p>
          ) : (
            <div className="grid grid-cols-3 gap-2 max-h-64 overflow-y-auto">
              {storagePhotos.map((url, i) => (
                <div key={i} className="relative aspect-square rounded-xl overflow-hidden bg-[#f5f0ea]">
                  <img src={url} alt={`photo-${i}`} className="w-full h-full object-cover" loading="lazy" />
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm text-center">
      <div className="flex items-center justify-center gap-2 mb-2 text-[#c9a87c]">
        {icon}
        <span className="text-2xl font-serif text-[#4a4a4a]">{value}</span>
      </div>
      <p className="text-xs text-[#8a8279]">{label}</p>
    </div>
  );
}
