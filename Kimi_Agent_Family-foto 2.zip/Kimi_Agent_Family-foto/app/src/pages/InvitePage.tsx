import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { inviteApi } from "../lib/api";
import type { Album } from "../types";
import {
  Loader2,
  CheckCircle,
  XCircle,
  ArrowRight,
  Globe,
  BookOpen,
} from "lucide-react";

export default function InvitePage() {
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  const [invite, setInvite] = useState<{
    type: "system" | "album";
    album?: Album;
    role: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [accepting, setAccepting] = useState(false);

  useEffect(() => {
    if (token) {
      const data = inviteApi.verify(token);
      setInvite(data);
      setLoading(false);
    }
  }, [token]);

  function getOrCreateUserId(): number {
    const stored = localStorage.getItem("auth_user");
    if (stored) {
      try {
        const user = JSON.parse(stored);
        return user.id || 1;
      } catch {
        // fallback
      }
    }
    const newId = Date.now() + Math.floor(Math.random() * 1000);
    const user = {
      id: newId,
      name: "Гость",
      email: "guest@album.ru",
      role: "viewer",
    };
    localStorage.setItem("auth_user", JSON.stringify(user));
    localStorage.setItem("auth_token", "token_" + newId);
    return newId;
  }

  function handleAccept() {
    if (!token) return;
    setAccepting(true);
    const userId = getOrCreateUserId();
    const result = inviteApi.accept(token, userId);

    setTimeout(() => {
      if (result.success && result.type === "album" && result.albumId) {
        navigate(`/album/${result.albumId}`);
      } else {
        navigate("/");
      }
    }, 500);
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#c9a87c] animate-spin" />
      </div>
    );
  }

  if (!invite) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
        <div className="text-center">
          <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h1 className="text-xl font-serif text-[#4a4a4a] mb-2">
            Приглашение не действительно
          </h1>
          <p className="text-[#8a8279] mb-4">
            Срок действия ссылки истек или она уже была использована
          </p>
          <button
            onClick={() => navigate("/")}
            className="bg-[#c9a87c] text-white px-6 py-2 rounded-xl hover:bg-[#b8976a] transition-all"
          >
            На главную
          </button>
        </div>
      </div>
    );
  }

  const isSystem = invite.type === "system";

  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
      <div className="text-center max-w-md">
        <CheckCircle className="w-16 h-16 text-[#7a9b76] mx-auto mb-4" />
        <h1 className="text-xl font-serif text-[#4a4a4a] mb-2">
          {isSystem ? "Вас пригласили в систему" : "Вас пригласили в альбом"}
        </h1>

        {isSystem ? (
          <>
            <div className="flex items-center justify-center gap-2 mb-2">
              <Globe className="w-5 h-5 text-[#c9a87c]" />
              <p className="text-[#8a8279]">
                Вы получите доступ ко <strong className="text-[#4a4a4a]">всем альбомам</strong>
              </p>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center justify-center gap-2 mb-2">
              <BookOpen className="w-5 h-5 text-[#c9a87c]" />
              <p className="text-[#8a8279]">
                Альбом:{" "}
                <strong className="text-[#4a4a4a]">{invite.album?.title}</strong>
              </p>
            </div>
          </>
        )}

        <p className="text-sm text-[#8a8279] mb-6">
          Роль:{" "}
          {invite.role === "admin"
            ? "Администратор"
            : invite.role === "editor"
            ? "Редактор"
            : "Наблюдатель"}
        </p>
        <button
          onClick={handleAccept}
          disabled={accepting}
          className="bg-[#7a9b76] text-white px-6 py-2 rounded-xl hover:bg-[#6a8b66] transition-all flex items-center gap-2 mx-auto disabled:opacity-50"
        >
          {accepting ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <ArrowRight className="w-4 h-4" />
          )}
          {accepting ? "Принятие..." : "Принять приглашение"}
        </button>
      </div>
    </div>
  );
}
