import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { inviteApi } from "../lib/api";
import type { Album } from "../types";
import {
  Loader2,
  CheckCircle,
  XCircle,
  ArrowRight,
  Globe,
  BookOpen,
  Mail,
  User,
} from "lucide-react";

export default function InvitePage() {
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  const [invite, setInvite] = useState<{
    type: "system" | "album";
    album?: Album;
    role: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [accepting, setAccepting] = useState(false);

  // Form state for new user
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    if (token) {
      inviteApi.verify(token).then((data: any) => {
        setInvite(data);
        setLoading(false);
      }).catch(() => {
        setInvite(null);
        setLoading(false);
      });
    }
  }, [token]);

  function handleShowForm() {
    setShowForm(true);
  }

  function handleAccept() {
    if (!token || !email.trim() || !name.trim()) return;
    setAccepting(true);

    const newId = Date.now() + Math.floor(Math.random() * 1000);
    const user = {
      id: newId,
      name: name.trim(),
      email: email.trim(),
      role: "viewer",
    };
    localStorage.setItem("auth_user", JSON.stringify(user));
    localStorage.setItem("auth_token", "token_" + newId);
    localStorage.setItem("ff_currentUser", JSON.stringify(user));

    inviteApi.accept(token).then((result: any) => {
      setTimeout(() => {
        if (result.success && result.type === "album" && result.albumId) {
          navigate(`/album/${result.albumId}`);
        } else {
          navigate("/");
        }
      }, 500);
    }).catch(() => {
      setAccepting(false);
    });
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#c9a87c] animate-spin" />
      </div>
    );
  }

  if (!invite) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
        <div className="text-center">
          <XCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h1 className="text-xl font-serif text-[#4a4a4a] mb-2">
            Приглашение не действительно
          </h1>
          <p className="text-[#8a8279] mb-4">
            Срок действия ссылки истек или она уже была использована
          </p>
          <button
            type="button"
            onClick={() => navigate("/")}
            className="bg-[#c9a87c] text-white px-6 py-2 rounded-xl hover:bg-[#b8976a] transition-all"
          >
            На главную
          </button>
        </div>
      </div>
    );
  }

  const isSystem = invite.type === "system";

  // Show email/name form first
  if (!showForm) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-lg max-w-sm w-full p-6">
          <div className="text-center mb-6">
            <CheckCircle className="w-12 h-12 text-[#7a9b76] mx-auto mb-3" />
            <h1 className="text-lg font-serif text-[#4a4a4a] mb-1">
              {isSystem ? "Вас пригласили в систему" : "Вас пригласили в альбом"}
            </h1>
            {isSystem ? (
              <p className="text-sm text-[#8a8279]">
                Доступ ко <strong className="text-[#4a4a4a]">всем альбомам</strong>
              </p>
            ) : (
              <p className="text-sm text-[#8a8279]">
                Альбом: <strong className="text-[#4a4a4a]">{invite.album?.title || "Без названия"}</strong>
              </p>
            )}
          </div>

          {/* Email input */}
          <div className="mb-3">
            <label className="flex items-center gap-1.5 text-sm text-[#8a8279] mb-1.5">
              <Mail className="w-4 h-4" />
              Ваш email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ivan@mail.ru"
              className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
            />
          </div>

          {/* Name input */}
          <div className="mb-4">
            <label className="flex items-center gap-1.5 text-sm text-[#8a8279] mb-1.5">
              <User className="w-4 h-4" />
              Ваше имя
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Иван Петров"
              className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
            />
          </div>

          <button
            type="button"
            onClick={handleShowForm}
            disabled={!email.trim() || !name.trim() || !email.includes("@")}
            className="w-full bg-[#7a9b76] text-white py-2.5 rounded-xl hover:bg-[#6a8b66] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <ArrowRight className="w-4 h-4" />
            Продолжить
          </button>
        </div>
      </div>
    );
  }

  // Confirmation screen
  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-lg max-w-sm w-full p-6 text-center">
        <CheckCircle className="w-12 h-12 text-[#7a9b76] mx-auto mb-3" />
        <h1 className="text-lg font-serif text-[#4a4a4a] mb-1">
          Подтвердите вход
        </h1>
        <p className="text-sm text-[#8a8279] mb-1">{name}</p>
        <p className="text-sm text-[#8a8279] mb-4">{email}</p>

        {isSystem ? (
          <p className="text-sm text-[#8a8279] mb-4">
            Роль: <strong>Наблюдатель</strong> — доступ ко всем альбомам
          </p>
        ) : (
          <p className="text-sm text-[#8a8279] mb-4">
            Альбом: <strong className="text-[#4a4a4a]">{invite.album?.title}</strong>
          </p>
        )}

        <button
          type="button"
          onClick={handleAccept}
          disabled={accepting}
          className="w-full bg-[#7a9b76] text-white py-2.5 rounded-xl hover:bg-[#6a8b66] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {accepting ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <CheckCircle className="w-4 h-4" />
          )}
          {accepting ? "Вход..." : "Принять приглашение"}
        </button>
      </div>
    </div>
  );
}