import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { ArrowLeft, Loader2, Check, AlertCircle, Mail, KeyRound, LogIn } from "lucide-react";
import { inviteApi, seedDemoData } from "../lib/api";

type InviteState = "loading" | "invalid" | "expired" | "needs_auth" | "ready" | "success";

export default function InvitePage() {
  const { token } = useParams<{ token: string }>();
  const [inviteState, setInviteState] = useState<InviteState>("loading");
  const [inviteInfo, setInviteInfo] = useState<any>(null);
  const [error, setError] = useState("");
  const [email, setEmail] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!token) {
      setInviteState("invalid");
      return;
    }
    checkInvite();
  }, [token]);

  async function checkInvite() {
    try {
      const result = await inviteApi.verify(token!);
      if (!result.valid) {
        setInviteState("expired");
        return;
      }
      setInviteInfo(result);
      // Check if user is already logged in
      const authStr = localStorage.getItem("auth_user");
      if (authStr) {
        // User is logged in — auto-accept
        await handleAccept(authStr);
        return;
      }
      setInviteState("needs_auth");
    } catch (e: any) {
      setError(e?.message || "Ошибка проверки приглашения");
      setInviteState("invalid");
    }
  }

  async function handleSendOTP() {
    setError("");
    if (!email.trim() || !email.includes("@")) {
      setError("Введите корректный email");
      return;
    }

    const sb = (await import("../lib/api")).supabase;
    if (!sb) {
      setError("Supabase не настроен");
      return;
    }

    setLoading(true);
    try {
      const { error: sbError } = await sb.auth.signInWithOtp({
        email: email.trim().toLowerCase(),
        options: { shouldCreateUser: true },
      });

      if (sbError) {
        if (sbError.message?.includes("rate limit") || sbError.status === 429) {
          setError("Слишком много попыток. Подождите 1 минуту.");
        } else {
          setError(sbError.message);
        }
        setLoading(false);
        return;
      }

      setOtpSent(true);
      setLoading(false);
    } catch (e: any) {
      setError(e?.message || "Ошибка отправки");
      setLoading(false);
    }
  }

  async function handleVerifyOTP() {
    setError("");
    if (!otpCode || otpCode.length < 6) {
      setError("Введите 6-значный код");
      return;
    }

    const sb = (await import("../lib/api")).supabase;
    if (!sb) {
      setError("Supabase не настроен");
      return;
    }

    setLoading(true);
    try {
      const { data, error: sbError } = await sb.auth.verifyOtp({
        email: email.trim().toLowerCase(),
        token: otpCode.trim(),
        type: "email",
      });

      if (sbError || !data.session) {
        setError(sbError?.message || "Неверный код");
        setLoading(false);
        return;
      }

      // Save auth
      const user = {
        id: data.user?.id,
        email: data.user?.email,
        name: data.user?.email?.split("@")[0] || "",
        token: data.session.access_token,
        refreshToken: data.session.refresh_token,
      };
      localStorage.setItem("auth_user", JSON.stringify(user));

      // Accept invite
      await handleAccept(JSON.stringify(user));
    } catch (e: any) {
      setError(e?.message || "Ошибка");
      setLoading(false);
    }
  }

  async function handleAccept(authStr: string) {
    try {
      await inviteApi.accept(token!);

      // Seed demo data for new user
      const parsed = JSON.parse(authStr);
      seedDemoData(parsed.email || "user");

      setInviteState("success");
    } catch (e: any) {
      setError("Ошибка приёма приглашения: " + (e?.message || ""));
      setInviteState("invalid");
    }
  }

  // ===== RENDER =====

  if (inviteState === "loading") {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#c9a87c] animate-spin" />
      </div>
    );
  }

  if (inviteState === "invalid" || inviteState === "expired") {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-sm">
          <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
          <h2 className="text-lg font-serif text-[#4a4a4a] mb-2">
            {inviteState === "expired" ? "Приглашение использовано" : "Приглашение не найдено"}
          </h2>
          <p className="text-sm text-[#8a8279] mb-4">
            {inviteState === "expired"
              ? "Эта ссылка уже была использована или истекла"
              : "Проверьте ссылку или попросите отправить новое приглашение"}
          </p>
          <button
            onClick={() => { window.location.hash = "#/"; }}
            className="bg-[#c9a87c] text-white rounded-xl px-6 py-2.5 text-sm font-medium"
          >
            На главную
          </button>
        </div>
      </div>
    );
  }

  if (inviteState === "success") {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center shadow-sm">
          <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="w-7 h-7 text-green-600" />
          </div>
          <h2 className="text-lg font-serif text-[#4a4a4a] mb-2">Добро пожаловать!</h2>
          <p className="text-sm text-[#8a8279] mb-4">
            {inviteInfo?.type === "system"
              ? "Теперь вы можете просматривать все альбомы системы"
              : "Теперь вы можете просматривать этот альбом"}
          </p>
          <button
            onClick={() => { window.location.hash = "#/"; }}
            className="w-full bg-[#c9a87c] text-white rounded-xl py-3 text-sm font-medium"
          >
            Перейти к альбомам
          </button>
        </div>
      </div>
    );
  }

  // inviteState === "needs_auth" — show OTP flow
  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-[#c9a87c]/10 rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Mail className="w-7 h-7 text-[#c9a87c]" />
          </div>
          <h1 className="text-xl font-serif text-[#4a4a4a]">
            Приглашение
          </h1>
          <p className="text-sm text-[#8a8279] mt-1">
            {inviteInfo?.type === "system"
              ? "Доступ ко всем альбомам"
              : "Доступ к альбому"}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#e5ddd0]/50 p-6">
          {!otpSent ? (
            <div className="space-y-4">
              <p className="text-sm text-[#8a8279]">
                Введите email для получения кода подтверждения.
              </p>

              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                    autoFocus
                    disabled={loading}
                  />
                </div>
              </div>

              <button
                onClick={handleSendOTP}
                disabled={loading || !email}
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <KeyRound className="w-4 h-4" />
                )}
                {loading ? "Отправка..." : "Получить код"}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-green-600 text-sm bg-green-50 rounded-xl py-2 px-3">
                <Check className="w-4 h-4 flex-shrink-0" />
                <span>Код отправлен на {email}</span>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Код из письма
                </label>
                <input
                  type="text"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="000000"
                  maxLength={6}
                  className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-center text-2xl tracking-[0.5em] font-mono"
                  autoFocus
                  disabled={loading}
                />
              </div>

              <button
                onClick={handleVerifyOTP}
                disabled={loading || otpCode.length < 6}
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <LogIn className="w-4 h-4" />
                )}
                {loading ? "Вход..." : "Войти"}
              </button>

              <button
                onClick={() => { setOtpSent(false); setOtpCode(""); setError(""); }}
                className="w-full text-sm text-[#8a8279] py-1 hover:text-[#c9a87c] transition-colors"
              >
                Отправить код повторно
              </button>
            </div>
          )}

          {error && (
            <p className="text-red-500 text-sm mt-4 text-center bg-red-50 rounded-xl py-2 px-3">
              {error}
            </p>
          )}
        </div>

        <button
          onClick={() => { window.location.hash = "#/"; }}
          className="w-full mt-4 flex items-center justify-center gap-1 text-sm text-[#8a8279] hover:text-[#c9a87c] transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          На главную
        </button>
      </div>
    </div>
  );
}
