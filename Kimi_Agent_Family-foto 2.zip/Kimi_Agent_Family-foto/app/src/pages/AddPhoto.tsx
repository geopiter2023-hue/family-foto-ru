import { useState, useRef } from "react";
import { useParams } from "react-router-dom";
import { photoApi, uploadFile } from "../lib/api";
import { ArrowLeft, Upload, X, Check, Loader2, AlertCircle } from "lucide-react";

interface UploadFile {
  id: string;
  preview: string; // server URL or object URL during upload
  caption: string;
  location: string;
  emotion: string | null;
  uploading?: boolean;
}

const MAX_PHOTOS_PER_BATCH = 50;

export default function AddPhoto() {
  const { id } = useParams<{ id: string }>();
  const albumId = Number(id);
  const inputRef = useRef<HTMLInputElement>(null);

  const [files, setFiles] = useState<UploadFile[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [warning, setWarning] = useState("");

  function pickPhotos() {
    if (saving) return;
    inputRef.current?.click();
  }

  async function handleFiles(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = e.target.files;
    if (!selected) return;
    const arr = Array.from(selected).filter((f) => f.type.startsWith("image/"));
    if (arr.length === 0) return;

    if (arr.length > MAX_PHOTOS_PER_BATCH) {
      setWarning(`Вы выбрали ${arr.length} фото. Максимум за раз — ${MAX_PHOTOS_PER_BATCH}. Лишние пропущены.`);
    }

    const toProcess = arr.slice(0, MAX_PHOTOS_PER_BATCH);

    // Upload files to server SEQUENTIALLY
    for (const file of toProcess) {
      const tempId = Math.random().toString(36).slice(2) + Date.now().toString(36);
      const objUrl = URL.createObjectURL(file);
      
      // Show immediately with object URL
      setFiles((prev) => [
        ...prev,
        { id: tempId, preview: objUrl, caption: "", location: "", emotion: null, uploading: true },
      ]);

      try {
        const serverUrl = await uploadFile(file);
        // Replace object URL with server URL
        setFiles((prev) =>
          prev.map((f) => (f.id === tempId ? { ...f, preview: serverUrl, uploading: false } : f))
        );
        URL.revokeObjectURL(objUrl);
      } catch {
        // Keep object URL if upload failed
        setFiles((prev) =>
          prev.map((f) => (f.id === tempId ? { ...f, uploading: false } : f))
        );
        console.error("Upload failed for:", file.name);
      }
    }
    e.target.value = "";
  }

  function removeFile(id: string) {
    if (saving) return;
    setFiles((prev) => prev.filter((f) => f.id !== id));
  }

  function updateCaption(id: string, val: string) {
    if (saving) return;
    setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, caption: val } : f)));
  }

  function updateLocation(id: string, val: string) {
    if (saving) return;
    setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, location: val } : f)));
  }

  function updateEmotion(id: string, val: string | null) {
    if (saving) return;
    setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, emotion: val } : f)));
  }

  const EMOTIONS = [
    { key: "Счастье", icon: "🌞" },
    { key: "Любовь", icon: "❤️" },
    { key: "Ностальгия", icon: "🏛️" },
    { key: "Уют", icon: "🕯️" },
    { key: "Вдохновение", icon: "✨" },
  ];

  async function doSave(e: React.MouseEvent<HTMLAnchorElement>) {
    if (files.length === 0 || saving) {
      e.preventDefault();
      return;
    }
    setSaving(true);

    // Only save files that have server URLs (not still uploading with object URLs)
    const ready = files.filter((f) => !f.uploading && !f.preview.startsWith("blob:"));
    
    if (ready.length > 0) {
      await photoApi.createBatch(
        albumId,
        ready.map((f) => ({
          url: f.preview,
          thumbnail: null,
          caption: f.caption || undefined,
          location: f.location || undefined,
          takenAt: new Date().toISOString(),
          isCover: false,
          uploadedBy: 1,
        }))
      );
    }

    setSaved(true);
  }

  function goBack(e: React.MouseEvent) {
    e.preventDefault();
    const a = document.createElement("a");
    a.href = "#/album/" + albumId;
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  const count = files.length;
  const photoLabel = count === 1 ? "1 фото" : `${count} фото`;

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      {saved && (
        <div className="bg-green-500 text-white px-4 py-3 flex items-center justify-center gap-2">
          <Check className="w-5 h-5" />
          <span className="font-medium">Сохранено!</span>
        </div>
      )}

      {/* Header */}
      <div className="bg-white shadow-sm border-b border-[#e5ddd0]">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center justify-between">
          <button
            type="button"
            onTouchStart={goBack}
            onClick={goBack}
            className="text-[#8a8279] active:text-[#c9a87c] w-10 h-10 flex items-center justify-center"
            style={{ touchAction: "manipulation" }}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-lg font-serif text-[#4a4a4a] flex-1 text-center mr-10">
            Добавить фото
          </h1>
          <div className="w-10" />
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-4">
        {warning && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-3 mb-4 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-yellow-500 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-yellow-700">{warning}</p>
          </div>
        )}

        {/* Upload zone */}
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          onChange={handleFiles}
          className="hidden"
        />
        <button
          type="button"
          onTouchStart={pickPhotos}
          onClick={pickPhotos}
          disabled={saving}
          className="w-full border-2 border-dashed border-[#c9a87c] rounded-2xl py-8 flex flex-col items-center justify-center gap-2 text-[#8a8279] active:bg-[#f5f0ea] disabled:opacity-50 mb-4"
          style={{ touchAction: "manipulation" }}
        >
          <Upload className="w-8 h-8 text-[#c9a87c]" />
          <span className="font-medium">{count > 0 ? "Добавить ещё" : "Выбрать фото"}</span>
          <span className="text-xs">Максимум {MAX_PHOTOS_PER_BATCH} за раз</span>
        </button>

        {/* Preview list */}
        {count > 0 && (
          <div className="space-y-3 mb-4">
            {files.map((f, i) => (
              <div key={f.id} className="bg-white rounded-xl border border-[#e5ddd0] p-3">
                <div className="flex gap-3">
                  <div className="relative w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden bg-[#f5f0ea]">
                    <img
                      src={f.preview}
                      alt="preview"
                      className="w-full h-full object-cover"
                    />
                    {f.uploading && (
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <Loader2 className="w-5 h-5 text-white animate-spin" />
                      </div>
                    )}
                    <span className="absolute top-1 left-1 bg-black/50 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                      {i + 1}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <input
                      type="text"
                      value={f.caption}
                      onChange={(e) => updateCaption(f.id, e.target.value)}
                      placeholder="Подпись"
                      disabled={saving}
                      className="w-full px-2.5 py-2 border border-[#e5ddd0] rounded-lg text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c] mb-2"
                    />
                    <input
                      type="text"
                      value={f.location}
                      onChange={(e) => updateLocation(f.id, e.target.value)}
                      placeholder="Где снято"
                      disabled={saving}
                      className="w-full px-2.5 py-2 border border-[#e5ddd0] rounded-lg text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                    />
                  </div>
                  <button
                    type="button"
                    onTouchStart={() => removeFile(f.id)}
                    onClick={() => removeFile(f.id)}
                    disabled={saving}
                    className="w-8 h-8 flex-shrink-0 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
                    style={{ touchAction: "manipulation" }}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                {/* Emotions */}
                <div className="flex gap-1.5 mt-2 flex-wrap">
                  {EMOTIONS.map((em) => (
                    <button
                      key={em.key}
                      type="button"
                      onTouchStart={() => updateEmotion(f.id, em.key)}
                      onClick={() => updateEmotion(f.id, em.key)}
                      disabled={saving}
                      className={`px-2 py-1 rounded-full text-[11px] border transition-all ${
                        f.emotion === em.key
                          ? "bg-[#c9a87c] text-white border-[#c9a87c]"
                          : "bg-[#faf8f5] text-[#8a8279] border-[#e5ddd0]"
                      }`}
                      style={{ touchAction: "manipulation" }}
                    >
                      {em.icon} {em.key}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Save button */}
        {count > 0 && !saved && (
          <a
            href={`#/album/${albumId}`}
            onClick={doSave}
            className={`block w-full rounded-xl py-4 text-center font-medium text-base text-white ${
              saving
                ? "bg-[#c9a87c]/60"
                : "bg-[#c9a87c] active:bg-[#a6875a]"
            }`}
          >
            {saving ? (
              <span className="flex items-center justify-center gap-2">
                <Loader2 className="w-5 h-5 animate-spin" />
                Сохранение...
              </span>
            ) : (
              `Сохранить ${photoLabel}`
            )}
          </a>
        )}
      </div>
    </div>
  );
}
