import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { albumApi } from "../lib/api";
import { ArrowLeft, BookOpen, Check, Calendar } from "lucide-react";

const ACCENT_COLORS = [
  "#c9a87c", "#7a9b76", "#8b7b8b", "#9b7d6b",
  "#6b8f9b", "#b5866b", "#6b7a8f", "#8b6b6b",
];

const BG_COLORS = [
  "#faf8f5", "#f0f0f0", "#f5f0f0", "#f0f5f0",
  "#f5f5f0", "##f0f0f5", "#fff8f0", "#f0fff8",
];

const FONTS = [
  { value: "serif", label: "Классический" },
  { value: "sans-serif", label: "Современный" },
  { value: "cursive", label: "Рукописный" },
];

const MONTHS = [
  "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
  "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
];

const YEARS = Array.from({ length: 30 }, (_, i) => new Date().getFullYear() - 25 + i).reverse();

export default function CreateAlbum() {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [albumType, setAlbumType] = useState<"photo" | "family_tree">("photo");
  const [accentColor, setAccentColor] = useState(ACCENT_COLORS[0]);
  const [backgroundColor, setBackgroundColor] = useState(BG_COLORS[0]);
  const [fontFamily, setFontFamily] = useState("serif");
  const [photosPerPage, setPhotosPerPage] = useState(2);
  const [isPublic, setIsPublic] = useState(false);
  const [creating, setCreating] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setCreating(true);
    try {
      const album = await albumApi.create({
        title,
        description,
        year,
        month,
        albumType,
        accentColor,
        backgroundColor,
        fontFamily,
        photosPerPage,
        isPublic,
        coverPhoto: null,
        createdBy: 1,
      });
      navigate(`/album/${album.id}`);
    } catch (err) {
      console.error("Create album failed:", err);
      alert("Ошибка создания альбома. Проверьте настройки Supabase.");
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      <header className="bg-white shadow-sm border-b border-[#e5ddd0]">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
          <button
            onClick={() => navigate("/")}
            className="text-[#8a8279] hover:text-[#c9a87c] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="text-xl font-serif text-[#4a4a4a]">Новый альбом</h1>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
              Название *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Например: Летний отдых 2024"
              className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] focus:border-transparent bg-white"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
              Описание
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="О чем этот альбом..."
              rows={3}
              className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] focus:border-transparent bg-white resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
              Тип альбома
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setAlbumType("photo")}
                className={`px-4 py-3 rounded-xl border text-sm transition-all ${
                  albumType === "photo"
                    ? "border-[#c9a87c] bg-[#c9a87c]/10 text-[#c9a87c]"
                    : "border-[#e5ddd0] text-[#8a8279] hover:border-[#c9a87c]"
                }`}
              >
                📷 Фотоальбом
              </button>
              <button
                type="button"
                onClick={() => setAlbumType("family_tree")}
                className={`px-4 py-3 rounded-xl border text-sm transition-all ${
                  albumType === "family_tree"
                    ? "border-[#c9a87c] bg-[#c9a87c]/10 text-[#c9a87c]"
                    : "border-[#e5ddd0] text-[#8a8279] hover:border-[#c9a87c]"
                }`}
              >
                🌳 Семейное дерево
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Год
              </label>
              <select
                value={year}
                onChange={(e) => setYear(Number(e.target.value))}
                className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-white text-sm"
              >
                {YEARS.map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Месяц
              </label>
              <select
                value={month}
                onChange={(e) => setMonth(Number(e.target.value))}
                className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-white text-sm"
              >
                {MONTHS.map((m, i) => (
                  <option key={i + 1} value={i + 1}>{m}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#4a4a4a] mb-3">
              Акцентный цвет
            </label>
            <div className="flex flex-wrap gap-3">
              {ACCENT_COLORS.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setAccentColor(color)}
                  className={`w-10 h-10 rounded-xl transition-all ${
                    accentColor === color
                      ? "ring-2 ring-offset-2 ring-[#4a4a4a] scale-110"
                      : "hover:scale-105"
                  }`}
                  style={{ backgroundColor: color }}
                >
                  {accentColor === color && (
                    <Check className="w-5 h-5 text-white mx-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#4a4a4a] mb-3">
              Цвет фона
            </label>
            <div className="flex flex-wrap gap-3">
              {BG_COLORS.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setBackgroundColor(color)}
                  className={`w-10 h-10 rounded-xl border border-[#e5ddd0] transition-all ${
                    backgroundColor === color
                      ? "ring-2 ring-offset-2 ring-[#4a4a4a] scale-110"
                      : "hover:scale-105"
                  }`}
                  style={{ backgroundColor: color }}
                >
                  {backgroundColor === color && (
                    <Check className="w-5 h-5 text-[#4a4a4a] mx-auto" />
                  )}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
              Шрифт
            </label>
            <div className="grid grid-cols-3 gap-3">
              {FONTS.map((font) => (
                <button
                  key={font.value}
                  type="button"
                  onClick={() => setFontFamily(font.value)}
                  className={`px-4 py-3 rounded-xl border text-sm transition-all ${
                    fontFamily === font.value
                      ? "border-[#c9a87c] bg-[#c9a87c]/10 text-[#c9a87c]"
                      : "border-[#e5ddd0] text-[#8a8279] hover:border-[#c9a87c]"
                  }`}
                  style={{ fontFamily: font.value }}
                >
                  {font.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
              Фотографий на страницу: {photosPerPage}
            </label>
            <input
              type="range"
              min={1}
              max={6}
              value={photosPerPage}
              onChange={(e) => setPhotosPerPage(Number(e.target.value))}
              className="w-full accent-[#c9a87c]"
            />
          </div>

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="isPublic"
              checked={isPublic}
              onChange={(e) => setIsPublic(e.target.checked)}
              className="w-5 h-5 accent-[#c9a87c] rounded"
            />
            <label
              htmlFor="isPublic"
              className="text-sm text-[#4a4a4a] cursor-pointer"
            >
              Публичный альбом
            </label>
          </div>

          <div
            className="rounded-2xl p-6 border border-[#e5ddd0]"
            style={{
              background: `linear-gradient(135deg, ${accentColor}15 0%, ${backgroundColor} 50%, ${accentColor}10 100%)`,
              fontFamily,
            }}
          >
            <p className="text-center text-[#4a4a4a] text-lg opacity-50">
              {title || "Предпросмотр обложки"}
            </p>
            <p className="text-center text-[#4a4a4a] text-sm opacity-40 mt-1">
              {year} · {MONTHS[month - 1]}
            </p>
          </div>

          <button
            type="submit"
            disabled={creating || !title.trim()}
            className="w-full bg-[#c9a87c] text-white py-3 rounded-xl hover:bg-[#b8976a] transition-all font-medium flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <BookOpen className="w-4 h-4" />
            {creating ? "Создание..." : "Создать альбом"}
          </button>
        </form>
      </main>
    </div>
  );
}
