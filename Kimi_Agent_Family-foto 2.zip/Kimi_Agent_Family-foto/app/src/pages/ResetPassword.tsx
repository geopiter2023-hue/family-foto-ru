import { useState, useEffect } from "react";
import { Lock, ArrowRight, Heart, Loader2, CheckCircle, Mail, KeyRound } from "lucide-react";
import { supabase } from "../lib/api";

export default function ResetPassword() {
  const [mode, setMode] = useState<"otp" | "newpass">("otp");
  const [email, setEmail] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);

  // Check if we have a recovery token in the URL (from email link)
  useEffect(() => {
    const fullHash = window.location.hash;
    if (fullHash.includes("type=recovery") || fullHash.includes("access_token=")) {
      setMode("newpass");
    }
  }, []);

  // ===== OTP: Send code =====
  async function handleSendOTP() {
    setError("");
    setSuccess("");

    if (!email.trim() || !email.includes("@")) {
      setError("Введите корректный email");
      return;
    }
    if (!supabase) {
      setError("Supabase не настроен");
      return;
    }

    setLoading(true);
    try {
      const { error: sbError } = await supabase.auth.signInWithOtp({
        email: email.trim().toLowerCase(),
        options: {
          shouldCreateUser: false, // Only for existing users
        },
      });

      if (sbError) {
        // Rate limit or other error
        if (sbError.message?.includes("rate limit") || sbError.status === 429) {
          setError("Слишком много попыток. Подождите 1 минуту.");
        } else {
          setError(sbError.message || "Ошибка отправки кода");
        }
        setLoading(false);
        return;
      }

      setOtpSent(true);
      setSuccess("Код отправлен на email! Введите 6-значный код из письма.");
    } catch (e: any) {
      setError(e?.message || "Ошибка сети");
    } finally {
      setLoading(false);
    }
  }

  // ===== OTP: Verify code =====
  async function handleVerifyOTP() {
    setError("");
    setSuccess("");

    if (!otpCode || otpCode.length < 6) {
      setError("Введите 6-значный код");
      return;
    }
    if (!supabase) {
      setError("Supabase не настроен");
      return;
    }

    setLoading(true);
    try {
      const { data, error: sbError } = await supabase.auth.verifyOtp({
        email: email.trim().toLowerCase(),
        token: otpCode.trim(),
        type: "email",
      });

      if (sbError || !data.session) {
        setError(sbError?.message || "Неверный код");
        setLoading(false);
        return;
      }

      // OTP successful — save session and show password change form
      const user = {
        id: data.user?.id,
        email: data.user?.email,
        name: data.user?.email?.split("@")[0] || "",
        token: data.session.access_token,
        refreshToken: data.session.refresh_token,
      };
      localStorage.setItem("auth_user", JSON.stringify(user));

      setSuccess("Вход выполнен! Теперь установите новый пароль.");
      setMode("newpass");
      setLoading(false);
    } catch (e: any) {
      setError(e?.message || "Ошибка проверки кода");
      setLoading(false);
    }
  }

  // ===== Set new password (after OTP or recovery link) =====
  async function handleSetNewPassword() {
    setError("");
    setSuccess("");

    if (!password || password.length < 6) {
      setError("Пароль должен быть не менее 6 символов");
      return;
    }
    if (password !== confirmPassword) {
      setError("Пароли не совпадают");
      return;
    }

    if (!supabase) {
      setError("Supabase не настроен");
      return;
    }

    setLoading(true);
    try {
      const { data, error: sbError } = await supabase.auth.updateUser({
        password,
      });

      if (sbError) {
        setError(sbError.message || "Ошибка смены пароля");
        setLoading(false);
        return;
      }

      setSuccess("Пароль успешно изменен! Переходим...");

      // Ensure session is saved
      if (data.user) {
        const { data: sessionData } = await supabase.auth.getSession();
        if (sessionData.session) {
          const user = {
            id: data.user.id,
            email: data.user.email,
            name: data.user.email?.split("@")[0] || "",
            token: sessionData.session.access_token,
            refreshToken: sessionData.session.refresh_token,
          };
          localStorage.setItem("auth_user", JSON.stringify(user));

          setTimeout(() => {
            window.location.hash = "#/";
          }, 1500);
          return;
        }
      }

      setTimeout(() => {
        window.location.hash = "#/login";
      }, 1500);
    } catch (e: any) {
      setError(e?.message || "Ошибка сети");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#c9a87c]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8 text-[#c9a87c]" />
          </div>
          <h1 className="text-2xl font-serif text-[#4a4a4a]">
            Семейный Альбом
          </h1>
          <p className="text-sm text-[#8a8279] mt-1">
            {mode === "otp" ? "Восстановление доступа" : "Новый пароль"}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#e5ddd0]/50 p-6">
          {mode === "otp" ? (
            <div className="space-y-4">
              {!otpSent ? (
                <>
                  <p className="text-sm text-[#8a8279]">
                    Введите email — мы отправим код для входа. После входа вы сможете установить новый пароль.
                  </p>

                  <div>
                    <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                      Email
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="your@email.com"
                        className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                        autoFocus
                        disabled={loading}
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleSendOTP}
                    disabled={loading || !email}
                    className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
                    style={{ touchAction: "manipulation" }}
                  >
                    {loading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <KeyRound className="w-4 h-4" />
                    )}
                    {loading ? "Отправка..." : "Получить код"}
                  </button>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-2 text-green-600 text-sm bg-green-50 rounded-xl py-2 px-3">
                    <CheckCircle className="w-4 h-4 flex-shrink-0" />
                    <span>Код отправлен на {email}</span>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                      Код из письма
                    </label>
                    <input
                      type="text"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                      placeholder="000000"
                      maxLength={6}
                      className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm text-center text-2xl tracking-[0.5em] font-mono"
                      autoFocus
                      disabled={loading}
                    />
                  </div>

                  <button
                    onClick={handleVerifyOTP}
                    disabled={loading || otpCode.length < 6}
                    className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
                    style={{ touchAction: "manipulation" }}
                  >
                    {loading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <ArrowRight className="w-4 h-4" />
                    )}
                    {loading ? "Проверка..." : "Войти"}
                  </button>

                  <button
                    onClick={() => { setOtpSent(false); setOtpCode(""); setError(""); }}
                    className="w-full text-sm text-[#8a8279] py-1 hover:text-[#c9a87c] transition-colors"
                  >
                    Отправить код повторно
                  </button>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-green-600 text-sm bg-green-50 rounded-xl py-2 px-3">
                <CheckCircle className="w-4 h-4 flex-shrink-0" />
                <span>Введите новый пароль</span>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Новый пароль
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Минимум 6 символов"
                    className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                    autoFocus
                    disabled={loading}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Подтвердите пароль
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Повторите пароль"
                    className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                    disabled={loading}
                  />
                </div>
              </div>

              <button
                onClick={handleSetNewPassword}
                disabled={loading || !password || !confirmPassword}
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
                style={{ touchAction: "manipulation" }}
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <CheckCircle className="w-4 h-4" />
                )}
                {loading ? "Сохранение..." : "Сохранить пароль"}
              </button>
            </div>
          )}

          {/* Error */}
          {error && (
            <p className="text-red-500 text-sm mt-4 text-center bg-red-50 rounded-xl py-2 px-3">
              {error}
            </p>
          )}

          {/* Success */}
          {success && (
            <p className="text-green-600 text-sm mt-4 text-center bg-green-50 rounded-xl py-2 px-3">
              {success}
            </p>
          )}
        </div>

        {/* Back to login */}
        <div className="text-center mt-6">
          <button
            onClick={() => { window.location.hash = "#/login"; }}
            className="text-sm text-[#8a8279] hover:text-[#c9a87c] transition-colors"
          >
            Вернуться к входу
          </button>
        </div>
      </div>
    </div>
  );
}
