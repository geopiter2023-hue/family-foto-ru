import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Mail, Lock, ArrowRight, Heart, Loader2 } from "lucide-react";
import { supabase } from "../lib/api";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"email" | "otp">("email");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSendOtp() {
    setError("");
    if (!email.trim() || !email.includes("@")) {
      setError("Введите email (например: test@test.com)");
      return;
    }

    setLoading(true);
    try {
      const { error: sbError } = await supabase!.auth.signInWithOtp({
        email: email.trim().toLowerCase(),
        options: { shouldCreateUser: true },
      });

      if (sbError) {
        console.error("[otp] error:", sbError);
        setError(sbError.message || "Ошибка отправки кода");
        setLoading(false);
        return;
      }

      setStep("otp");
    } catch (e: any) {
      console.error("[otp] exception:", e);
      setError(e?.message || "Ошибка сети");
    } finally {
      setLoading(false);
    }
  }

  async function handleVerifyOtp() {
    setError("");
    if (otp.length < 6) {
      setError("Введите код из письма");
      return;
    }

    if (!supabase) {
      setError("Supabase не настроен");
      return;
    }

    setLoading(true);
    try {
      const cleanOtp = otp.trim().replace(/\s/g, "");

      const { data, error: sbError } = await supabase.auth.verifyOtp({
        email: email.trim().toLowerCase(),
        token: cleanOtp,
        type: "email",
      });

      if (sbError || !data?.session) {
        setError(sbError?.message || "Неверный или устаревший код");
        setLoading(false);
        return;
      }

      const user = {
        id: data.user?.id,
        email: data.user?.email,
        name: data.user?.email?.split("@")[0] || "",
        token: data.session.access_token,
        refreshToken: data.session.refresh_token,
      };
      localStorage.setItem("auth_user", JSON.stringify(user));
      navigate("/");
    } catch (e: any) {
      setError(e?.message || "Ошибка входа");
    } finally {
      setLoading(false);
    }
  }

  function handleBack() {
    setStep("email");
    setOtp("");
    setError("");
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#c9a87c]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8 text-[#c9a87c]" />
          </div>
          <h1 className="text-2xl font-serif text-[#4a4a4a]">
            Семейный Альбом
          </h1>
          <p className="text-sm text-[#8a8279] mt-1">
            {step === "email" ? "Вход по email" : `Код отправлен на ${email}`}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#e5ddd0]/50 p-6">
          {step === "email" ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                    autoFocus
                    disabled={loading}
                  />
                </div>
              </div>

              <button
                onClick={handleSendOtp}
                disabled={loading}
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
                style={{ touchAction: "manipulation" }}
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <ArrowRight className="w-4 h-4" />
                )}
                {loading ? "Отправка..." : "Получить код"}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Код подтверждения
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) =>
                      setOtp(e.target.value.replace(/\D/g, "").slice(0, 8))
                    }
                    placeholder="000000"
                    className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-center tracking-[0.5em] text-lg"
                    maxLength={8}
                    autoFocus
                    inputMode="numeric"
                    disabled={loading}
                  />
                </div>
                <p className="text-xs text-[#8a8279] mt-2 text-center">
                  Введите код из письма
                </p>
              </div>

              <button
                onClick={handleVerifyOtp}
                disabled={loading || otp.length < 6}
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
                style={{ touchAction: "manipulation" }}
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <ArrowRight className="w-4 h-4" />
                )}
                {loading ? "Вход..." : "Войти"}
              </button>

              <button
                onClick={handleBack}
                disabled={loading}
                className="w-full text-sm text-[#8a8279] py-2 hover:text-[#c9a87c] transition-colors"
              >
                Назад
              </button>
            </div>
          )}

          {error && (
            <p className="text-red-500 text-sm mt-4 text-center bg-red-50 rounded-xl py-2 px-3">
              {error}
            </p>
          )}
        </div>

        {/* Hint */}
        <p className="text-center text-xs text-[#8a8279] mt-6">
          Введите email, и мы отправим код подтверждения
        </p>
      </div>
    </div>
  );
}
