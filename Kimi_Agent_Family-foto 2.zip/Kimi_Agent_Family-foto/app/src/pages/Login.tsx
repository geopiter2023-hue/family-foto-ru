import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Mail, Lock, ArrowRight, Heart, Loader2, UserPlus, LogIn } from "lucide-react";
import { supabase } from "../lib/api";

export default function Login() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  function validateInputs(): boolean {
    setError("");
    setSuccess("");

    if (!email.trim() || !email.includes("@")) {
      setError("Введите корректный email");
      return false;
    }
    if (!password || password.length < 6) {
      setError("Пароль должен быть не менее 6 символов");
      return false;
    }
    if (mode === "register" && password !== confirmPassword) {
      setError("Пароли не совпадают");
      return false;
    }
    return true;
  }

  async function handleLogin() {
    if (!validateInputs()) return;
    if (!supabase) {
      setError("Supabase не настроен — проверьте окружение");
      return;
    }

    setLoading(true);
    try {
      const { data, error: sbError } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      });

      if (sbError || !data.session) {
        setError(sbError?.message === "Invalid login credentials"
          ? "Неверный email или пароль"
          : (sbError?.message || "Ошибка входа"));
        setLoading(false);
        return;
      }

      const user = {
        id: data.user?.id,
        email: data.user?.email,
        name: data.user?.email?.split("@")[0] || "",
        token: data.session.access_token,
        refreshToken: data.session.refresh_token,
      };
      localStorage.setItem("auth_user", JSON.stringify(user));

      // Track user for admin stats
      try {
        const users = JSON.parse(localStorage.getItem("ff_users") || "[]");
        if (Array.isArray(users) && !users.includes(email)) {
          users.push(email);
          localStorage.setItem("ff_users", JSON.stringify(users));
        }
      } catch { /* ignore */ }

      navigate("/");
    } catch (e: any) {
      setError(e?.message || "Ошибка сети");
    } finally {
      setLoading(false);
    }
  }

  async function handleRegister() {
    if (!validateInputs()) return;
    if (!supabase) {
      setError("Supabase не настроен — проверьте окружение");
      return;
    }

    setLoading(true);
    try {
      const { data, error: sbError } = await supabase.auth.signUp({
        email: email.trim().toLowerCase(),
        password,
        options: {
          data: { name: email.split("@")[0] || "" },
        },
      });

      if (sbError) {
        setError(sbError?.message || "Ошибка регистрации");
        setLoading(false);
        return;
      }

      // Check if email confirmation is required
      if (data.user && !data.session) {
        setSuccess("Регистрация успешна! Подтвердите email по ссылке в письме, затем войдите.");
        setMode("login");
        setLoading(false);
        return;
      }

      // Auto-login if session is available
      if (data.session) {
        const user = {
          id: data.user?.id,
          email: data.user?.email,
          name: data.user?.email?.split("@")[0] || "",
          token: data.session.access_token,
          refreshToken: data.session.refresh_token,
        };
        localStorage.setItem("auth_user", JSON.stringify(user));

        try {
          const users = JSON.parse(localStorage.getItem("ff_users") || "[]");
          if (Array.isArray(users) && !users.includes(email)) {
            users.push(email);
            localStorage.setItem("ff_users", JSON.stringify(users));
          }
        } catch { /* ignore */ }

        navigate("/");
      }
    } catch (e: any) {
      setError(e?.message || "Ошибка сети");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#c9a87c]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8 text-[#c9a87c]" />
          </div>
          <h1 className="text-2xl font-serif text-[#4a4a4a]">
            Семейный Альбом
          </h1>
          <p className="text-sm text-[#8a8279] mt-1">
            {mode === "login" ? "Вход в аккаунт" : "Создание аккаунта"}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#e5ddd0]/50 p-6">
          {/* Mode toggle */}
          <div className="flex rounded-xl bg-[#f0ebe3] p-1 mb-5">
            <button
              onClick={() => { setMode("login"); setError(""); setSuccess(""); }}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                mode === "login"
                  ? "bg-white text-[#4a4a4a] shadow-sm"
                  : "text-[#8a8279]"
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              Вход
            </button>
            <button
              onClick={() => { setMode("register"); setError(""); setSuccess(""); }}
              className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                mode === "register"
                  ? "bg-white text-[#4a4a4a] shadow-sm"
                  : "text-[#8a8279]"
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              Регистрация
            </button>
          </div>

          <div className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                  autoFocus
                  disabled={loading}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                Пароль
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Минимум 6 символов"
                  className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                  disabled={loading}
                />
              </div>
            </div>

            {/* Confirm password (register only) */}
            {mode === "register" && (
              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Подтвердите пароль
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Повторите пароль"
                    className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                    disabled={loading}
                  />
                </div>
              </div>
            )}

            {/* Submit button */}
            {mode === "login" ? (
              <>
                <button
                  onClick={handleLogin}
                  disabled={loading || !email || !password}
                  className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
                  style={{ touchAction: "manipulation" }}
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <ArrowRight className="w-4 h-4" />
                  )}
                  {loading ? "Вход..." : "Войти"}
                </button>
                <button
                  onClick={() => { window.location.hash = "#/reset-password"; }}
                  className="w-full text-sm text-[#8a8279] py-1 hover:text-[#c9a87c] transition-colors"
                  type="button"
                >
                  Забыли пароль?
                </button>
              </>
            ) : (
              <button
                onClick={handleRegister}
                disabled={loading || !email || !password || !confirmPassword}
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors disabled:opacity-60"
                style={{ touchAction: "manipulation" }}
              >
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <UserPlus className="w-4 h-4" />
                )}
                {loading ? "Создание..." : "Создать аккаунт"}
              </button>
            )}
          </div>

          {/* Error */}
          {error && (
            <p className="text-red-500 text-sm mt-4 text-center bg-red-50 rounded-xl py-2 px-3">
              {error}
            </p>
          )}

          {/* Success */}
          {success && (
            <p className="text-green-600 text-sm mt-4 text-center bg-green-50 rounded-xl py-2 px-3">
              {success}
            </p>
          )}
        </div>

        {/* Hint */}
        <p className="text-center text-xs text-[#8a8279] mt-6">
          {mode === "login"
            ? "Введите email и пароль. Если забыли — нажмите 'Забыли пароль?'"
            : "Создайте аккаунт, чтобы начать"}
        </p>
      </div>
    </div>
  );
}
