import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Mail, Lock, ArrowRight, Heart } from "lucide-react";

// Demo code is always 000000
const DEMO_CODE = "000000";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"email" | "otp">("email");
  const [error, setError] = useState("");

  function handleSendOtp() {
    setError("");
    if (!email.includes("@")) {
      setError("Введите корректный email");
      return;
    }
    // Track unique user email
    try {
      const users = JSON.parse(localStorage.getItem("ff_users") || "[]");
      if (!users.includes(email.toLowerCase().trim())) {
        users.push(email.toLowerCase().trim());
        localStorage.setItem("ff_users", JSON.stringify(users));
      }
    } catch { /* ignore */ }
    setStep("otp");
  }

  function handleVerifyOtp() {
    setError("");
    if (otp.length !== 6) {
      setError("Введите 6-значный код");
      return;
    }

    if (otp !== DEMO_CODE) {
      setError("Неверный код. Демо-код: 000000");
      return;
    }

    // Create user and login
    const user = {
      id: 1,
      name: email.split("@")[0],
      email,
      role: "user",
    };
    localStorage.setItem("auth_token", "token_" + Date.now());
    localStorage.setItem("auth_user", JSON.stringify(user));

    navigate("/");
  }

  function handleBack() {
    setStep("email");
    setOtp("");
    setError("");
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#c9a87c]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8 text-[#c9a87c]" />
          </div>
          <h1 className="text-2xl font-serif text-[#4a4a4a]">
            Семейный Альбом
          </h1>
          <p className="text-sm text-[#8a8279] mt-1">
            {step === "email" ? "Вход по email" : `Код отправлен на ${email}`}
          </p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-[#e5ddd0]/50 p-6">
          {step === "email" ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm"
                    autoFocus
                  />
                </div>
              </div>

              <button
                onClick={handleSendOtp}
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors"
                style={{ touchAction: "manipulation" }}
              >
                Получить код
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Show demo code */}
              <div className="bg-[#c9a87c]/10 rounded-xl p-3 text-center">
                <p className="text-xs text-[#8a8279]">Демо-код</p>
                <p className="text-lg font-medium text-[#c9a87c] tracking-[0.3em]">{DEMO_CODE}</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#4a4a4a] mb-2">
                  Код подтверждения
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#8a8279]" />
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) =>
                      setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))
                    }
                    placeholder="000000"
                    className="w-full pl-10 pr-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-center tracking-[0.5em] text-lg"
                    maxLength={6}
                    autoFocus
                    inputMode="numeric"
                  />
                </div>
                <p className="text-xs text-[#8a8279] mt-2 text-center">
                  Введите 6-значный код
                </p>
              </div>

              <button
                onClick={handleVerifyOtp}
                className="w-full bg-[#c9a87c] text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors"
                style={{ touchAction: "manipulation" }}
              >
                Войти
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleBack}
                className="w-full text-sm text-[#8a8279] py-2 hover:text-[#c9a87c] transition-colors"
              >
                Назад
              </button>
            </div>
          )}

          {error && (
            <p className="text-red-500 text-sm mt-4 text-center bg-red-50 rounded-xl py-2">
              {error}
            </p>
          )}
        </div>

        {/* Hint */}
        <p className="text-center text-xs text-[#8a8279] mt-6">
          Демо: любой email + код 000000
        </p>
      </div>
    </div>
  );
}
