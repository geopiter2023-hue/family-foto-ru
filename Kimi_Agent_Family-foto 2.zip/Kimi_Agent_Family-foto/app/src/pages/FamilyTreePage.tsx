import { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import { uploadFile, albumApi, memberApi, inviteApi } from "../lib/api";
import type { Album, FamilyMember } from "../types";
import {
  ArrowLeft,
  Plus,
  X,
  Trash2,
  Users,
  Loader2,
  AlertTriangle,
  Users2,
  FileText,
  Share2,
  Copy,
  Check,
} from "lucide-react";
import { jsPDF } from "jspdf";

const ROLES = [
  { key: "pra_ded", label: "Прадед", emoji: "👴" },
  { key: "pra_bab", label: "Прабабка", emoji: "👵" },
  { key: "ded", label: "Дедушка", emoji: "👴" },
  { key: "bab", label: "Бабушка", emoji: "👵" },
  { key: "papa", label: "Папа", emoji: "👨" },
  { key: "mama", label: "Мама", emoji: "👩" },
  { key: "syn", label: "Сын", emoji: "👦" },
  { key: "doch", label: "Дочь", emoji: "👧" },
  { key: "vnuk", label: "Внук", emoji: "👶" },
  { key: "vnuch", label: "Внучка", emoji: "👶" },
  { key: "brat", label: "Брат", emoji: "👦" },
  { key: "sestra", label: "Сестра", emoji: "👧" },
  { key: "dyad", label: "Дядя", emoji: "👨" },
  { key: "tyot", label: "Тётя", emoji: "👩" },
  { key: "svoy", label: "Свой вариант", emoji: "✏️" },
];

export default function FamilyTreePage() {
  const { id } = useParams<{ id: string }>();
  const albumId = Number(id);

  const [album, setAlbum] = useState<Album | null>(null);
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddMember, setShowAddMember] = useState(false);

  // Edit mode
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);

  // Delete confirmation state (replaces browser confirm())
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  // Invite modal state
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteLink, setInviteLink] = useState("");
  const [copied, setCopied] = useState(false);

  // Toast message (replaces alert)
  const [toast, setToast] = useState<string | null>(null);
  const [pdfLoading, setPdfLoading] = useState(false);

  // PDF share modal
  const [pdfBlobForShare, setPdfBlobForShare] = useState<Blob | null>(null);
  const [pdfFileName, setPdfFileName] = useState<string>("family_tree.pdf");
  const [showPdfModal, setShowPdfModal] = useState(false);

  // Form state
  const [mName, setMName] = useState("");
  const [mRole, setMRole] = useState("papa");
  const [mCustomRole, setMCustomRole] = useState("");
  const [mBirth, setMBirth] = useState("");
  const [mDeath, setMDeath] = useState("");
  const [mParent1, setMParent1] = useState("");
  const [mParent2, setMParent2] = useState("");
  const [mSpouse, setMSpouse] = useState("");
  const [mBio, setMBio] = useState("");
  const [mPhoto, setMPhoto] = useState("");
  const [saving, setSaving] = useState(false);

  const fileRef = useRef<HTMLInputElement>(null);

  async function loadAll() {
    setLoading(true);
    const a = await albumApi.getById(albumId);
    if (a) {
      setAlbum(a);
      setMembers(a.members || []);
    }
    setLoading(false);
  }

  useEffect(() => {
    loadAll();
  }, [albumId]);

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  }

  async function handleInvite() {
    try {
      const invite = await inviteApi.create({ type: "album", albumId, role: "viewer" });
      const link = `${window.location.origin}/#/invite/${(invite as any).token}`;
      setInviteLink(link);
      setShowInviteModal(true);
      setCopied(false);
    } catch (e: any) {
      console.error("Invite error:", e?.message || e);
    }
  }

  async function handleExportPDF() {
    if (!album || members.length === 0) return;
    setPdfLoading(true);
    showToast("Создаём PDF...");

    const pageW = 595;
    const pageH = 842;
    const margin = 30;
    const pdf = new jsPDF({ unit: "pt", format: "a4" });
    pdf.setProperties({ title: album.title });

    let pageCount = 0;
    function addCanvasPage(canvas: HTMLCanvasElement) {
      if (pageCount > 0) pdf.addPage();
      pdf.addImage(canvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, pageW, pageH);
      pageCount++;
    }

    function newPage(bg = "#faf8f5"): { c: HTMLCanvasElement; x: CanvasRenderingContext2D } {
      const c = document.createElement("canvas");
      c.width = pageW;
      c.height = pageH;
      const x = c.getContext("2d")!;
      x.fillStyle = bg;
      x.fillRect(0, 0, pageW, pageH);
      return { c, x };
    }

    // Preload photos + tree background
    const photoMap = new Map<string, HTMLImageElement>();
    const urls = [...new Set(members.map((m) => m.photoUrl).filter(Boolean))] as string[];
    await Promise.all(
      urls.map((url) => new Promise<void>((resolve) => {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => { photoMap.set(url, img); resolve(); };
        img.onerror = () => resolve();
        img.src = url;
        setTimeout(() => resolve(), 2000);
      }))
    );

    // Load tree background (clean tree without empty frames)
    const basePath = import.meta.env.BASE_URL || "/";
    const treeBg = await new Promise<HTMLImageElement | null>((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = `${basePath}demo-photos/tree_bg2.jpg`;
      setTimeout(() => resolve(null), 3000);
    });

    // Helpers
    function drawCircleImg(ctx: CanvasRenderingContext2D, img: HTMLImageElement, cx: number, cy: number, r: number) {
      // Draw photo clipped to circle — NO extra border, photo fills the circle naturally
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.clip();
      // Cover-fit: scale to fill the circle
      const scale = Math.max((r * 2) / img.width, (r * 2) / img.height);
      const dw = img.width * scale;
      const dh = img.height * scale;
      ctx.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
      ctx.restore();
      // Thin subtle border matching tree branch color
      ctx.strokeStyle = "rgba(180, 160, 120, 0.5)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.stroke();
    }

    function drawArrowDown(ctx: CanvasRenderingContext2D, x: number, y: number, size: number) {
      ctx.fillStyle = "#c9a87c";
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x - size, y - size);
      ctx.lineTo(x + size, y - size);
      ctx.closePath();
      ctx.fill();
    }

    // ===== COVER: Tree with photos on branches =====
    const { c: coverCanvas, x: c } = newPage();
    // Draw tree background
    if (treeBg) {
      c.drawImage(treeBg, 0, 0, pageW, pageH);
    } else {
      c.fillStyle = "#faf8f5";
      c.fillRect(0, 0, pageW, pageH);
    }
    // Semi-transparent overlay for text readability
    c.fillStyle = "rgba(250, 248, 245, 0.25)";
    c.fillRect(0, 0, pageW, pageH);

    // Title at top
    c.fillStyle = "#4a4a4a";
    c.textAlign = "center";
    c.textBaseline = "top";
    c.font = "bold 30px serif";
    c.fillText(album.title, pageW / 2, 40);
    c.fillStyle = "#8a8279";
    c.font = "15px serif";
    c.fillText("\u0421\u0435\u043C\u0435\u0439\u043D\u043E\u0435 \u0434\u0440\u0435\u0432\u043E", pageW / 2, 78);

    // Place member photos as circles on the tree
    // Positions spread across tree branches (relative 0-1 coords)
    // Clean tree_bg2.jpg has NO empty circles — we place photos directly on branch tips
    const branchPositions: [number, number][] = [
      [0.22, 0.38], [0.40, 0.32], [0.58, 0.28], [0.76, 0.35],
      [0.15, 0.52], [0.35, 0.48], [0.52, 0.46], [0.70, 0.50], [0.85, 0.48],
      [0.25, 0.65], [0.45, 0.62], [0.65, 0.66], [0.80, 0.64],
      [0.30, 0.78], [0.55, 0.75], [0.75, 0.78],
    ];

    // Place ONLY members WITH photos — skip empty ones, no labels, no text
    const membersWithPhotos = members.filter((m) => m.photoUrl && photoMap.has(m.photoUrl));
    membersWithPhotos.forEach((m, i) => {
      const pos = branchPositions[i % branchPositions.length];
      const cpx = pos[0] * pageW;
      const cpy = pos[1] * pageH;
      const r = 34; // fits naturally on branch tips
      drawCircleImg(c, photoMap.get(m.photoUrl as string)!, cpx, cpy, r);
    });

    // Bottom info
    c.fillStyle = "#a09890";
    c.font = "10px sans-serif";
    c.textAlign = "center";
    c.textBaseline = "bottom";
    c.fillText(`${members.length} \u0440\u043E\u0434\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A\u043E\u0432 \u00B7 ${new Date().toLocaleDateString("ru-RU")}`, pageW / 2, pageH - 30);

    addCanvasPage(coverCanvas);

    // ===== GENERATION PAGES with connection arrows =====
    for (let gIdx = 0; gIdx < generations.length; gIdx++) {
      const gen = generations[gIdx];
      if (gen.length === 0) continue;

      const { c: gc, x: g } = newPage();
      const genLabel =
        gIdx === 0 ? "\u041F\u0420\u0410\u0420\u041E\u0414\u0418\u0422\u0415\u041B\u0418"
        : gIdx === 1 ? "\u0414\u0415\u0414\u0423\u0428\u041A\u0418 / \u0411\u0410\u0411\u0423\u0428\u041A\u0418"
        : gIdx === 2 ? "\u0420\u041E\u0414\u0418\u0422\u0415\u041B\u0418"
        : gIdx === 3 ? "\u0414\u0415\u0422\u0418"
        : gIdx === 4 ? "\u0412\u041D\u0423\u041A\u0418"
        : `\u041F\u041E\u041A\u041E\u041B\u0415\u041D\u0418\u0415 ${gIdx + 1}`;

      // Generation header with decorative line
      g.fillStyle = "#c9a87c";
      g.textAlign = "center";
      g.textBaseline = "alphabetic";
      g.font = "bold 20px serif";
      g.fillText(genLabel, pageW / 2, margin + 25);
      // Decorative underline with arrows on ends
      g.strokeStyle = "#c9a87c";
      g.lineWidth = 2.5;
      g.beginPath();
      g.moveTo(pageW / 2 - 100, margin + 32);
      g.lineTo(pageW / 2 + 100, margin + 32);
      g.stroke();
      drawArrowDown(g, pageW / 2, margin + 38, 5);

      // Cards: larger, full-width when 1 member, 2-col when more
      const useFullWidth = gen.length === 1;
      const cardW = useFullWidth ? pageW - margin * 2 : (pageW - margin * 2 - 14) / 2;
      const cardPad = 12;
      const photoH = useFullWidth ? 220 : 150;
      const cardH = photoH + 110; // more space for text
      let col = 0;
      let rowY = margin + 50;

      const R = 10; // corner radius for cards
      const drawGenCard = (member: FamilyMember, cardX: number, cardY: number, ctx: CanvasRenderingContext2D) => {
        // Shadow
        ctx.fillStyle = "rgba(0,0,0,0.06)";
        ctx.beginPath();
        ctx.roundRect(cardX + 2, cardY + 2, cardW, cardH, R);
        ctx.fill();

        // Card bg — warm white with rounded corners
        ctx.fillStyle = "#fdfcfa";
        ctx.beginPath();
        ctx.roundRect(cardX, cardY, cardW, cardH, R);
        ctx.fill();

        // Photo area (top portion, rounded top corners only)
        const photoY = cardY + cardPad;
        const photoW = cardW - cardPad * 2;
        const photoH2 = photoH - cardPad;
        const photoX = cardX + cardPad;

        // Photo bg
        ctx.save();
        ctx.beginPath();
        ctx.roundRect(photoX, photoY, photoW, photoH2, [8, 8, 0, 0]);
        ctx.clip();
        if (member.photoUrl && photoMap.has(member.photoUrl)) {
          try { ctx.drawImage(photoMap.get(member.photoUrl)!, photoX, photoY, photoW, photoH2); } catch { /* */ }
        } else {
          ctx.fillStyle = "#e8e0d4";
          ctx.fillRect(photoX, photoY, photoW, photoH2);
          ctx.fillStyle = "#b0a898";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.font = "bold 32px sans-serif";
          const initials = member.name.split(" ").map((n) => n[0]).join("").slice(0, 2);
          ctx.fillText(initials, photoX + photoW / 2, photoY + photoH2 / 2);
        }
        ctx.restore();

        // Role badge — pill shape
        const badgeH = 20;
        const badgePad = 12;
        ctx.font = "bold 9px sans-serif";
        const bw = ctx.measureText(member.role).width + badgePad * 2;
        const badgeX = photoX + 6;
        const badgeY = photoY + photoH2 - badgeH - 6;
        ctx.fillStyle = "rgba(201, 168, 124, 0.92)";
        ctx.beginPath();
        ctx.roundRect(badgeX, badgeY, bw, badgeH, 10);
        ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.textAlign = "left";
        ctx.textBaseline = "middle";
        ctx.fillText(member.role, badgeX + badgePad, badgeY + badgeH / 2 + 1);

        // Text info
        const tx = cardX + cardPad;
        const ty = cardY + photoH + 8;
        const maxTW = cardW - cardPad * 2;

        // Name
        ctx.textAlign = "left";
        ctx.textBaseline = "alphabetic";
        ctx.fillStyle = "#3a3a3a";
        ctx.font = "bold 13px sans-serif";
        let name = member.name;
        if (ctx.measureText(name).width > maxTW) {
          while (ctx.measureText(name + "...").width > maxTW && name.length > 3) name = name.slice(0, -1);
          name += "...";
        }
        ctx.fillText(name, tx, ty);

        // Dates
        ctx.fillStyle = "#7a7268";
        ctx.font = "10px sans-serif";
        ctx.fillText(`${member.birthDate || "?"} \u2014 ${member.deathDate || "\u043D.\u0432."}`, tx, ty + 16);

        // Bio (1-2 lines)
        if (member.bio) {
          ctx.fillStyle = "#8a8279";
          ctx.font = "9px sans-serif";
          const words = member.bio.split(" ");
          let line = "";
          let ly = ty + 32;
          let lines = 0;
          for (const word of words) {
            const test = line ? line + " " + word : word;
            if (ctx.measureText(test).width > maxTW && line) {
              ctx.fillText(line, tx, ly);
              line = word;
              ly += 13;
              lines++;
              if (lines >= 2) { line = line ? line + "..." : ""; break; }
            } else {
              line = test;
            }
          }
          if (line && lines < 2) ctx.fillText(line, tx, ly);
        }

        // Parents tags — pill shapes
        if (member.parent1Id || member.parent2Id) {
          const p1n = member.parent1Id ? getParentName(member.parent1Id) : "";
          const p2n = member.parent2Id ? getParentName(member.parent2Id) : "";
          const parents = [p1n, p2n].filter(Boolean);
          if (parents.length > 0) {
            ctx.font = "bold 8px sans-serif";
            let tagX = tx;
            const tagY = cardY + cardH - 14;
            parents.forEach((p) => {
              const tw = ctx.measureText(p).width + 10;
              if (tagX + tw > cardX + cardW - cardPad) return;
              ctx.fillStyle = "#f0ebe3";
              ctx.beginPath();
              ctx.roundRect(tagX, tagY, tw, 14, 7);
              ctx.fill();
              ctx.fillStyle = "#8a8279";
              ctx.textAlign = "left";
              ctx.textBaseline = "middle";
              ctx.fillText(p, tagX + 5, tagY + 7.5);
              tagX += tw + 4;
            });
          }
        }
      };

      for (const member of gen) {
        const cx2 = margin + col * (cardW + 14);

        if (rowY + cardH > pageH - margin - 30) {
          // Arrow to next page
          drawArrowDown(g, pageW / 2, pageH - 25, 8);
          g.fillStyle = "#c9a87c";
          g.font = "9px sans-serif";
          g.textAlign = "center";
          g.fillText("\u0441\u043B\u0435\u0434. \u0441\u0442\u0440.", pageW / 2, pageH - 12);
          addCanvasPage(gc);
          const { c: nc, x: nx } = newPage();
          // Continue on new canvas
          nx.fillStyle = "#c9a87c";
          nx.textAlign = "center";
          nx.font = "bold 14px serif";
          nx.fillText(genLabel + " (\u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0435\u043D\u0438\u0435)", pageW / 2, margin + 15);
          rowY = margin + 35;
          col = 0;
          void nc;
          void nx;
        }

        drawGenCard(member, cx2, rowY, g);

        col++;
        if (col > 1) { col = 0; rowY += cardH + 16; }
      }

      // Connection arrow to next generation
      if (gIdx < generations.length - 1) {
        drawArrowDown(g, pageW / 2, pageH - 25, 8);
        g.fillStyle = "#c9a87c";
        g.font = "9px sans-serif";
        g.textAlign = "center";
        g.fillText("\u0441\u043B\u0435\u0434. \u043F\u043E\u043A\u043E\u043B\u0435\u043D\u0438\u0435", pageW / 2, pageH - 12);
      }

      addCanvasPage(gc);
    }

    // ===== FINAL PAGE =====
    const { c: fCanvas, x: f } = newPage();
    if (treeBg) {
      f.drawImage(treeBg, 0, 0, pageW, pageH);
      f.fillStyle = "rgba(250, 248, 245, 0.65)";
      f.fillRect(0, 0, pageW, pageH);
    }
    f.fillStyle = "#4a4a4a";
    f.textAlign = "center";
    f.textBaseline = "middle";
    f.font = "bold 26px serif";
    f.fillText("\u0421\u043F\u0430\u0441\u0438\u0431\u043E \u0437\u0430 \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440!", pageW / 2, pageH / 2 - 25);
    f.fillStyle = "#8a8279";
    f.font = "13px serif";
    f.fillText(`family-foto.ru \u00B7 ${album.title}`, pageW / 2, pageH / 2 + 15);
    addCanvasPage(fCanvas);

    const blob = pdf.output("blob");
    setPdfBlobForShare(blob);
    setPdfFileName(`${album.title.replace(/\s+/g, "_")}_family_tree.pdf`);
    setShowPdfModal(true);
    setPdfLoading(false);
  }

  function handleOpenPDF() {
    if (!pdfBlobForShare) return;
    const url = URL.createObjectURL(pdfBlobForShare);
    const newWindow = window.open(url, "_blank");
    if (!newWindow) {
      window.location.href = url;
    }
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  async function handleSharePDF() {
    if (!pdfBlobForShare) return;
    try {
      const file = new File([pdfBlobForShare], pdfFileName || "family_tree.pdf", { type: "application/pdf" });
      if ((navigator as any).share && (navigator as any).canShare && (navigator as any).canShare({ files: [file] })) {
        await (navigator as any).share({
          title: album?.title || "Семейное древо",
          text: `Альбом "${album?.title}" на family-foto.ru`,
          files: [file],
        });
      } else if ((navigator as any).share) {
        await (navigator as any).share({
          title: album?.title || "Семейное древо",
          text: `Альбом "${album?.title}" на family-foto.ru`,
        });
      } else {
        showToast("Для отправки: откройте PDF и нажмите 'Поделиться' в Safari");
      }
      setShowPdfModal(false);
    } catch (e: any) {
      if (e.name !== "AbortError") {
        console.error("Share PDF error:", e);
      }
    }
  }

  function copyLink() {
    if (!inviteLink) return;
    navigator.clipboard.writeText(inviteLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      const textArea = document.createElement("textarea");
      textArea.value = inviteLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  async function handleShareInvite() {
    if (!inviteLink) return;
    try {
      if ((navigator as any).share) {
        await (navigator as any).share({
          title: album?.title || "Семейное древо",
          text: `Приглашение в альбом "${album?.title || ""}" на family-foto.ru`,
          url: inviteLink,
        });
      }
    } catch (e: any) {
      if (e.name !== "AbortError") console.error("Share error:", e);
    }
  }

  function openEditMember(member: FamilyMember) {
    setEditingMember(member);
    setMName(member.name);
    const roleMatch = ROLES.find((r) => r.label === member.role);
    if (roleMatch) {
      setMRole(roleMatch.key);
      setMCustomRole("");
    } else {
      setMRole("svoy");
      setMCustomRole(member.role);
    }
    setMBirth(member.birthDate || "");
    setMDeath(member.deathDate || "");
    setMParent1(member.parent1Id ? String(member.parent1Id) : "");
    setMParent2(member.parent2Id ? String(member.parent2Id) : "");
    setMSpouse(member.spouseId ? String(member.spouseId) : "");
    setMBio(member.bio || "");
    setMPhoto(member.photoUrl || "");
    setShowAddMember(true);
  }

  function resetForm() {
    setMName("");
    setMRole("papa");
    setMCustomRole("");
    setMBirth("");
    setMDeath("");
    setMParent1("");
    setMParent2("");
    setMSpouse("");
    setMBio("");
    setMPhoto("");
    setEditingMember(null);
    setShowAddMember(false);
    setSaving(false);
  }

  async function handleSaveMember() {
    if (!mName.trim()) return;
    setSaving(true);

    const roleLabel =
      mRole === "svoy" ? mCustomRole.trim() || "Родственник" : ROLES.find((r) => r.key === mRole)?.label || mRole;

    if (editingMember) {
      // Update existing
      await memberApi.update(editingMember.id, {
        name: mName.trim(),
        role: roleLabel,
        photoUrl: mPhoto || null,
        birthDate: mBirth || null,
        deathDate: mDeath || null,
        parent1Id: mParent1 ? Number(mParent1) : null,
        parent2Id: mParent2 ? Number(mParent2) : null,
        spouseId: mSpouse ? Number(mSpouse) : null,
        bio: mBio.trim() || null,
      });
    } else {
      // Create new
      await memberApi.create(albumId, {
        name: mName.trim(),
        role: roleLabel,
        photoUrl: mPhoto || undefined,
        birthDate: mBirth || undefined,
        deathDate: mDeath || undefined,
        parent1Id: mParent1 ? Number(mParent1) : undefined,
        parent2Id: mParent2 ? Number(mParent2) : undefined,
        spouseId: mSpouse ? Number(mSpouse) : undefined,
        bio: mBio.trim() || undefined,
        order: members.length + 1,
      });
    }

    await loadAll();
    resetForm();
  }

  async function handleDeleteFromEdit() {
    if (editingMember) {
      await memberApi.delete(editingMember.id);
      await loadAll();
      resetForm();
    }
  }

  async function handleDeleteMember(memberId: number) {
    setDeleteConfirm(null);
    await memberApi.delete(memberId);
    await loadAll();
  }

  async function handlePhotoFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      showToast("Загрузка фото...");
      const url = await uploadFile(file);
      setMPhoto(url);
      showToast("Фото загружено!");
    } catch {
      showToast("Ошибка загрузки");
    }
    e.target.value = "";
  }

  function handleAddNew() {
    resetForm();
    setShowAddMember(true);
  }

  function getParentName(id: number | null) {
    if (!id) return "";
    const m = members.find((x) => x.id === id);
    return m ? m.name : "";
  }

  // Group members by generation level (simple heuristic based on parent links)
  function getGenerations(): FamilyMember[][] {
    const levels = new Map<number, number>();

    function calcLevel(m: FamilyMember): number {
      if (levels.has(m.id)) return levels.get(m.id)!;
      let maxParentLevel = -1;
      if (m.parent1Id) {
        const p1 = members.find((x) => x.id === m.parent1Id);
        if (p1) maxParentLevel = Math.max(maxParentLevel, calcLevel(p1));
      }
      if (m.parent2Id) {
        const p2 = members.find((x) => x.id === m.parent2Id);
        if (p2) maxParentLevel = Math.max(maxParentLevel, calcLevel(p2));
      }
      const level = maxParentLevel + 1;
      levels.set(m.id, level);
      return level;
    }

    members.forEach((m) => calcLevel(m));

    const maxLevel = Math.max(...Array.from(levels.values()), 0);
    const gens: FamilyMember[][] = [];
    for (let i = 0; i <= maxLevel; i++) {
      gens.push(members.filter((m) => levels.get(m.id) === i));
    }
    return gens;
  }

  const generations = getGenerations();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#c9a87c] animate-spin" />
      </div>
    );
  }

  if (!album) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center">
        <p className="text-[#8a8279]">Альбом не найден</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] overflow-x-hidden">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-[#e5ddd0]">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center justify-between">
          <button
            type="button"
            onTouchStart={() => {
              const a = document.createElement("a");
              a.href = "#/";
              a.click();
            }}
            onClick={() => {
              const a = document.createElement("a");
              a.href = "#/";
              a.click();
            }}
            className="text-[#8a8279] active:text-[#c9a87c] w-10 h-10 flex items-center justify-center"
            style={{ touchAction: "manipulation" }}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1 mx-3">
            <h1 className="text-lg font-serif text-[#4a4a4a] truncate">{album.title}</h1>
            <p className="text-xs text-[#8a8279]">🌳 Семейное дерево · {members.length} родственников</p>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onTouchStart={() => handleAddNew()}
              onClick={() => handleAddNew()}
              className="w-9 h-9 bg-[#c9a87c] rounded-full flex items-center justify-center text-white active:bg-[#a6875a]"
              style={{ touchAction: "manipulation" }}
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Action buttons — под заголовком */}
      <div className={`max-w-lg mx-auto px-4 pt-3 ${showAddMember ? "pointer-events-none" : ""}`}>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={handleInvite}
            className="bg-white rounded-xl py-2.5 flex items-center justify-center gap-1 text-sm text-[#4a4a4a] shadow-sm border border-[#e5ddd0] active:bg-[#f0ebe3]"
            style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
          >
            <Users2 className="w-4 h-4" />
            <span>Пригласить</span>
          </button>
          <button
            type="button"
            onClick={handleExportPDF}
            disabled={pdfLoading}
            className="bg-white rounded-xl py-2.5 flex items-center justify-center gap-1 text-sm text-[#4a4a4a] shadow-sm border border-[#e5ddd0] active:bg-[#f0ebe3] disabled:opacity-50"
            style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
          >
            {pdfLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <FileText className="w-4 h-4" />
            )}
            <span>{pdfLoading ? "Создание..." : "Скачать PDF"}</span>
          </button>
        </div>
      </div>

      {/* Tree Visualization */}
      <div className="max-w-lg mx-auto px-4 py-4">
        {generations.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-12 h-12 text-[#e5ddd0] mx-auto mb-3" />
            <p className="text-[#8a8279] text-sm">Добавьте первого родственника</p>
            <p className="text-[#8a8279] text-xs mt-1">Начните с прадедов или дедушек</p>
          </div>
        ) : (
          <div className="space-y-6">
            {generations.map((gen, genIdx) => (
              <div key={genIdx} className="relative">
                {/* Generation label */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="h-px flex-1 bg-[#e5ddd0]" />
                  <span className="text-xs text-[#8a8279] uppercase tracking-wider">
                    {genIdx === 0
                      ? "Прародители"
                      : genIdx === 1
                      ? "Дедушки / Бабушки"
                      : genIdx === 2
                      ? "Родители"
                      : genIdx === 3
                      ? "Дети"
                      : genIdx === 4
                      ? "Внуки"
                      : `Поколение ${genIdx + 1}`}
                  </span>
                  <div className="h-px flex-1 bg-[#e5ddd0]" />
                </div>

                {/* Members grid */}
                <div className="grid grid-cols-2 gap-3">
                  {gen.map((member) => (
                    <button
                      type="button"
                      key={member.id}
                      onClick={() => openEditMember(member)}
                      className="bg-white rounded-2xl border border-[#e5ddd0]/50 overflow-hidden shadow-sm text-left active:scale-[0.98] transition-transform"
                      style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
                    >
                      {/* Photo */}
                      <div className="relative aspect-square bg-[#f5f0ea]">
                        {member.photoUrl ? (
                          <img
                            src={member.photoUrl}
                            alt={member.name}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Users className="w-10 h-10 text-[#e5ddd0]" />
                          </div>
                        )}
                        {/* Role badge */}
                        <span className="absolute bottom-2 left-2 bg-[#c9a87c] text-white text-[9px] px-2 py-0.5 rounded-full">
                          {member.role}
                        </span>
                        {/* Delete — separate button, stops propagation */}
                        <button
                          type="button"
                          onTouchStart={(e) => { e.stopPropagation(); setDeleteConfirm(member.id); }}
                          onClick={(e) => { e.stopPropagation(); setDeleteConfirm(member.id); }}
                          className="absolute top-2 right-2 w-7 h-7 bg-black/40 rounded-full flex items-center justify-center text-white active:bg-black/60"
                          style={{ touchAction: "manipulation" }}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Info */}
                      <div className="p-3">
                        <p className="font-medium text-sm text-[#4a4a4a]">{member.name}</p>
                        {(member.birthDate || member.deathDate) && (
                          <p className="text-[10px] text-[#8a8279] mt-0.5">
                            {member.birthDate || "?"} — {member.deathDate || "н.в."}
                          </p>
                        )}
                        {member.bio && (
                          <p className="text-[10px] text-[#8a8279] mt-1 line-clamp-2">{member.bio}</p>
                        )}
                        {/* Parent links */}
                        {(member.parent1Id || member.parent2Id) && (
                          <div className="mt-1.5 flex flex-wrap gap-1">
                            {member.parent1Id && (
                              <span className="text-[9px] bg-[#f0ebe3] text-[#8a8279] px-1.5 py-0.5 rounded-full">
                                {getParentName(member.parent1Id)}
                              </span>
                            )}
                            {member.parent2Id && (
                              <span className="text-[9px] bg-[#f0ebe3] text-[#8a8279] px-1.5 py-0.5 rounded-full">
                                {getParentName(member.parent2Id)}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </button>
                  ))}
                </div>

                {/* Connector line to next generation */}
                {genIdx < generations.length - 1 && (
                  <div className="flex justify-center mt-3 mb-1">
                    <div className="w-px h-4 bg-[#c9a87c]/40" />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add Member Modal */}
      {showAddMember && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
          onClick={() => setShowAddMember(false)}
        >
          <div
            className="bg-white rounded-t-2xl sm:rounded-2xl max-w-sm w-full max-h-[90vh] overflow-y-auto p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">
                {editingMember ? "Изменить родственника" : "Добавить родственника"}
              </h3>
              <button
                type="button"
                onTouchStart={(e) => { e.preventDefault(); e.stopPropagation(); resetForm(); }}
                onClick={() => resetForm()}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
                style={{ touchAction: "manipulation" }}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {/* Name */}
              <div>
                <label className="block text-sm text-[#8a8279] mb-1">Имя и фамилия *</label>
                <input
                  type="text"
                  value={mName}
                  onChange={(e) => setMName(e.target.value)}
                  placeholder="Иван Петров"
                  className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                />
              </div>

              {/* Role */}
              <div>
                <label className="block text-sm text-[#8a8279] mb-1">Родство *</label>
                <div className="grid grid-cols-3 gap-2">
                  {ROLES.slice(0, 12).map((r) => (
                    <button
                      key={r.key}
                      type="button"
                      onTouchStart={() => setMRole(r.key)}
                      onClick={() => setMRole(r.key)}
                      className={`px-2 py-2 rounded-xl text-xs border transition-all ${
                        mRole === r.key
                          ? "bg-[#c9a87c]/20 border-[#c9a87c] text-[#6b4226]"
                          : "bg-[#faf8f5] border-[#e5ddd0] text-[#4a4a4a]"
                      }`}
                      style={{ touchAction: "manipulation" }}
                    >
                      <span className="text-sm">{r.emoji}</span>
                      <div className="mt-0.5">{r.label}</div>
                    </button>
                  ))}
                </div>
                {mRole === "svoy" && (
                  <input
                    type="text"
                    value={mCustomRole}
                    onChange={(e) => setMCustomRole(e.target.value)}
                    placeholder="Введите родство..."
                    className="w-full mt-2 px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                  />
                )}
              </div>

              {/* Dates */}
              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="block text-sm text-[#8a8279] mb-1">Дата рождения</label>
                  <input
                    type="date"
                    value={mBirth}
                    onChange={(e) => setMBirth(e.target.value)}
                    className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm text-[#8a8279] mb-1">Дата смерти</label>
                  <input
                    type="date"
                    value={mDeath}
                    onChange={(e) => setMDeath(e.target.value)}
                    className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                  />
                </div>
              </div>

              {/* Parents */}
              <div>
                <label className="block text-sm text-[#8a8279] mb-1">Родители (если есть в дереве)</label>
                <div className="flex gap-2 min-w-0">
                  <select
                    value={mParent1}
                    onChange={(e) => setMParent1(e.target.value)}
                    className="flex-1 min-w-0 max-w-[50%] px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                  >
                    <option value="">Отец/Мать 1</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.role})
                      </option>
                    ))}
                  </select>
                  <select
                    value={mParent2}
                    onChange={(e) => setMParent2(e.target.value)}
                    className="flex-1 min-w-0 max-w-[50%] px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                  >
                    <option value="">Отец/Мать 2</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.role})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Spouse */}
              <div>
                <label className="block text-sm text-[#8a8279] mb-1">Супруг/супруга</label>
                <select
                  value={mSpouse}
                  onChange={(e) => setMSpouse(e.target.value)}
                  className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                >
                  <option value="">Не выбрано</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.role})
                    </option>
                  ))}
                </select>
              </div>

              {/* Photo */}
              <div>
                <label className="block text-sm text-[#8a8279] mb-1">Фото</label>
                <input ref={fileRef} type="file" accept="image/*" onChange={handlePhotoFile} className="hidden" />
                <button
                  type="button"
                  onTouchStart={() => fileRef.current?.click()}
                  onClick={() => fileRef.current?.click()}
                  className="w-full border-2 border-dashed border-[#e5ddd0] rounded-xl py-3 text-center text-sm text-[#8a8279] active:border-[#c9a87c]"
                  style={{ touchAction: "manipulation" }}
                >
                  {mPhoto ? "Заменить фото" : "Выбрать фото"}
                </button>
                {mPhoto && (
                  <div className="mt-2 flex items-center gap-2">
                    <img src={mPhoto} alt="preview" className="w-16 h-16 rounded-xl object-cover" />
                    <button
                      type="button"
                      onClick={() => setMPhoto("")}
                      className="text-xs text-red-400 active:text-red-600"
                      style={{ touchAction: "manipulation" }}
                    >
                      Удалить фото
                    </button>
                  </div>
                )}
              </div>

              {/* Bio */}
              <div>
                <label className="block text-sm text-[#8a8279] mb-1">Описание / Факты</label>
                <textarea
                  value={mBio}
                  onChange={(e) => setMBio(e.target.value)}
                  placeholder="Где родился, чем занимался, любимые воспоминания..."
                  rows={3}
                  className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                />
              </div>

              <button
                type="button"
                onTouchStart={(e) => { e.preventDefault(); e.stopPropagation(); handleSaveMember(); }}
                onClick={handleSaveMember}
                disabled={saving || !mName.trim()}
                className={`w-full rounded-xl py-3.5 font-medium text-base ${
                  saving || !mName.trim()
                    ? "bg-[#c9a87c]/60 text-white"
                    : "bg-[#c9a87c] text-white active:bg-[#a6875a]"
                }`}
                style={{ touchAction: "manipulation" }}
              >
                {saving
                  ? "Сохранение..."
                  : editingMember
                  ? "Сохранить изменения"
                  : "Добавить в дерево"}
              </button>

              {editingMember && (
                <button
                  type="button"
                  onTouchStart={(e) => { e.preventDefault(); e.stopPropagation(); handleDeleteFromEdit(); }}
                  onClick={handleDeleteFromEdit}
                  className="w-full rounded-xl py-3.5 font-medium text-base bg-red-50 text-red-500 active:bg-red-100 border border-red-200"
                  style={{ touchAction: "manipulation" }}
                >
                  <span className="flex items-center justify-center gap-2">
                    <Trash2 className="w-4 h-4" />
                    Удалить родственника
                  </span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal (replaces browser confirm) */}
      {deleteConfirm !== null && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setDeleteConfirm(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <h3 className="text-lg font-serif text-[#4a4a4a]">Удалить родственника?</h3>
                <p className="text-sm text-[#8a8279]">Действие нельзя отменить</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onTouchStart={() => setDeleteConfirm(null)}
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 bg-[#f5f0ea] text-[#4a4a4a] rounded-xl py-3 font-medium"
                style={{ touchAction: "manipulation" }}
              >
                Отмена
              </button>
              <button
                type="button"
                onTouchStart={() => handleDeleteMember(deleteConfirm)}
                onClick={() => handleDeleteMember(deleteConfirm)}
                className="flex-1 bg-red-500 active:bg-red-600 text-white rounded-xl py-3 font-medium"
                style={{ touchAction: "manipulation" }}
              >
                Удалить
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Toast — replaces alert() */}
      {toast && (
        <div className="fixed top-16 left-0 right-0 z-[60] flex justify-center px-4 pointer-events-none">
          <div className="bg-[#4a4a4a] text-white text-sm px-5 py-3 rounded-2xl shadow-lg max-w-xs text-center animate-fade-in pointer-events-auto">
            {toast}
          </div>
        </div>
      )}

      {/* Invite Modal */}
      {showInviteModal && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowInviteModal(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">Пригласить</h3>
              <button
                type="button"
                onTouchStart={() => setShowInviteModal(false)}
                onClick={() => setShowInviteModal(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
                style={{ touchAction: "manipulation" }}
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8a8279] mb-3">
              Отправьте ссылку друзьям и семье
            </p>
            <div className="bg-[#f5f0ea] rounded-xl p-3 mb-3 break-all text-xs text-[#4a4a4a]">
              {inviteLink}
            </div>
            <button
              type="button"
              onClick={handleShareInvite}
              className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-2.5 flex items-center justify-center gap-2 font-medium mb-2"
              style={{ touchAction: "manipulation" }}
            >
              <Share2 className="w-4 h-4" />
              Поделиться ссылкой
            </button>
            <button
              type="button"
              onClick={copyLink}
              className="w-full bg-[#f5f0ea] active:bg-[#e5ddd0] text-[#4a4a4a] rounded-xl py-2.5 flex items-center justify-center gap-2 font-medium text-sm"
              style={{ touchAction: "manipulation" }}
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-green-600" />
                  <span className="text-green-600">Скопировано!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Копировать ссылку
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* PDF Share Modal */}
      {showPdfModal && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowPdfModal(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">PDF готов!</h3>
              <button
                type="button"
                onClick={() => setShowPdfModal(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
                style={{ touchAction: "manipulation" }}
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8a8279] mb-4">
              PDF создан. Откройте его или отправьте в мессенджер.
            </p>
            <button
              type="button"
              onClick={handleOpenPDF}
              className="w-full bg-[#4a4a4a] active:bg-[#333333] text-white rounded-xl py-3 flex items-center justify-center gap-2 font-medium mb-2"
              style={{ touchAction: "manipulation" }}
            >
              <FileText className="w-4 h-4" />
              Открыть PDF
            </button>
            <button
              type="button"
              onClick={handleSharePDF}
              className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-3 flex items-center justify-center gap-2 font-medium mb-3"
              style={{ touchAction: "manipulation" }}
            >
              <Share2 className="w-4 h-4" />
              Поделиться альбомом
            </button>
            <p className="text-xs text-center text-[#8a8279]">
              Или нажмите "Поделиться" ↗️ в Safari после открытия PDF
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
