import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { downloadPDF, getMobilePDFHint } from "../lib/pdfDownload";
import { albumApi, photoApi, photoBookApi } from "../lib/api";
import type { Album, Photo } from "../types";
import {
  ArrowLeft,
  Loader2,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Maximize2,
  Minimize2,
  Download,
  BookOpen,
  X,
  Check,
} from "lucide-react";
import { jsPDF } from "jspdf";

interface BookFormat {
  id: string;
  name: string;
  width: number;
  height: number;
  label: string;
}

const BOOK_FORMATS: BookFormat[] = [
  // Album (landscape) — широкие
  { id: "45x30", name: "45×30", width: 45, height: 30, label: "45×30" },
  { id: "30x20", name: "30×20", width: 30, height: 20, label: "30×20" },
  { id: "29x19", name: "29×19", width: 29, height: 19, label: "29×19" },
  { id: "20x15", name: "20×15", width: 20, height: 15, label: "20×15" },
  // Portrait — высокие
  { id: "22x30", name: "22×30", width: 22, height: 30, label: "22×30" },
  { id: "20x30", name: "20×30", width: 20, height: 30, label: "20×30" },
  { id: "15x20", name: "15×20", width: 15, height: 20, label: "15×20" },
  { id: "18x24", name: "18×24", width: 18, height: 24, label: "18×24" },
  // Square — квадратные
  { id: "30x30", name: "30×30", width: 30, height: 30, label: "30×30" },
  { id: "28x28", name: "28×28", width: 28, height: 28, label: "28×28" },
  { id: "25x25", name: "25×25", width: 25, height: 25, label: "25×25" },
  { id: "23x23", name: "23×23", width: 23, height: 23, label: "23×23" },
  { id: "20x20", name: "20×20", width: 20, height: 20, label: "20×20" },
  { id: "19x19", name: "19×19", width: 19, height: 19, label: "19×19" },
  { id: "15x15", name: "15×15", width: 15, height: 15, label: "15×15" },
  { id: "8x8", name: "8×8", width: 8, height: 8, label: "8×8" },
];

function getFormatKey(albumId: number): string {
  return `photobook_format_${albumId}`;
}

function getSavedFormat(albumId: number): string {
  return localStorage.getItem(getFormatKey(albumId)) || "30x20";
}

function saveFormat(albumId: number, formatId: string) {
  localStorage.setItem(getFormatKey(albumId), formatId);
}

export default function PhotoBook() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const albumId = Number(id);

  const [album, setAlbum] = useState<Album | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showFormatPicker, setShowFormatPicker] = useState(false);
  const [pdfLoading, setPdfLoading] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState<BookFormat>(() => {
    const saved = getSavedFormat(albumId);
    return BOOK_FORMATS.find((f) => f.id === saved) || BOOK_FORMATS[3]; // default 30x20
  });

  useEffect(() => {
    loadData();
  }, [albumId]);

  async function loadData() {
    try {
      const a = await albumApi.getById(albumId);
      setAlbum(a || null);
      const p = await photoApi.list(albumId);
      setPhotos(p);

      const existing = photoBookApi.list(albumId);
      if (existing.length === 0 && a && p.length > 0) {
        photoBookApi.generate(albumId);
      }
      setLoading(false);
    } catch (e) {
      console.error("PhotoBook load error:", e);
      setLoading(false);
    }
  }

  function handleSelectFormat(format: BookFormat) {
    setSelectedFormat(format);
    saveFormat(albumId, format.id);
    setShowFormatPicker(false);
  }

  function handleRegenerate() {
    try {
      photoBookApi.reset(albumId);
      photoBookApi.generate(albumId);
      setCurrentPage(0);
      loadData();
    } catch (e) {
      console.error("Regenerate error:", e);
    }
  }

  async function handleExportPDF() {
    if (!album || photos.length === 0) {
      alert("Нет фото для PDF");
      return;
    }

    setPdfLoading(true);
    alert("Создаю книгу...");

    try {
      const pdf = new jsPDF("l", "mm", "a4");
      const PW_MM = 297;
      const PH_MM = 210;
      const DPI = 150;
      const PW_PX = Math.round((PW_MM * DPI) / 25.4);
      const PH_PX = Math.round((PH_MM * DPI) / 25.4);

      const safeName = (album.title || "photobook").replace(/[^a-zA-Z0-9\u0400-\u04FF]/g, "_");
      const fileName = `${safeName}.pdf`;
      const albumHeader = `${album.title}`;

      // ============ COVER PAGE (full-bleed cover photo + title) ============
      const coverCanvas = document.createElement("canvas");
      coverCanvas.width = PW_PX;
      coverCanvas.height = PH_PX;
      const cctx = coverCanvas.getContext("2d")!;

      cctx.fillStyle = "#2a2520";
      cctx.fillRect(0, 0, PW_PX, PH_PX);

      const coverUrl = album.coverPhoto || photos[0]?.url;
      if (coverUrl) {
        try {
          const img = await loadImage(coverUrl);
          const aspect = img.width / img.height;
          const pageAspect = PW_PX / PH_PX;
          let sw = img.width, sh = img.height, sx = 0, sy = 0;
          if (aspect > pageAspect) {
            sw = img.height * pageAspect;
            sx = (img.width - sw) / 2;
          } else {
            sh = img.width / pageAspect;
            sy = (img.height - sh) / 2;
          }
          cctx.drawImage(img, sx, sy, sw, sh, 0, 0, PW_PX, PH_PX);
        } catch { /* leave dark bg */ }
      }

      const overlay = cctx.createLinearGradient(0, 0, 0, PH_PX);
      overlay.addColorStop(0, "rgba(0,0,0,0.55)");
      overlay.addColorStop(0.3, "rgba(0,0,0,0.20)");
      overlay.addColorStop(0.7, "rgba(0,0,0,0.30)");
      overlay.addColorStop(1, "rgba(0,0,0,0.60)");
      cctx.fillStyle = overlay;
      cctx.fillRect(0, 0, PW_PX, PH_PX);

      // Title at top, large
      cctx.fillStyle = "#ffffff";
      cctx.textAlign = "center";
      cctx.textBaseline = "top";
      const maxTitleW = PW_PX * 0.80;
      let titleSize = Math.max(48, PW_PX * 0.065);
      cctx.font = `bold ${titleSize}px serif`;
      let tw = cctx.measureText(album.title).width;
      if (tw > maxTitleW) {
        titleSize = Math.floor(titleSize * (maxTitleW / tw));
        cctx.font = `bold ${titleSize}px serif`;
      }
      const titleY = PH_PX * 0.12;
      cctx.fillText(album.title, PW_PX / 2, titleY);

      // Line under title
      cctx.strokeStyle = "rgba(255,255,255,0.5)";
      cctx.lineWidth = 1.5;
      cctx.beginPath();
      const lineY = titleY + titleSize + PH_PX * 0.02;
      cctx.moveTo(PW_PX * 0.30, lineY);
      cctx.lineTo(PW_PX * 0.70, lineY);
      cctx.stroke();

      // Description
      if (album.description) {
        cctx.font = `300 ${Math.max(14, titleSize * 0.22)}px sans-serif`;
        cctx.fillStyle = "rgba(255,255,255,0.65)";
        cctx.fillText(album.description.toUpperCase(), PW_PX / 2, lineY + PH_PX * 0.035);
      }

      // Bottom line + family-foto.ru
      cctx.strokeStyle = "rgba(255,255,255,0.35)";
      cctx.lineWidth = 1;
      cctx.beginPath();
      cctx.moveTo(PW_PX * 0.35, PH_PX * 0.82);
      cctx.lineTo(PW_PX * 0.65, PH_PX * 0.82);
      cctx.stroke();

      cctx.font = `400 ${Math.max(11, PW_PX * 0.018)}px sans-serif`;
      cctx.fillStyle = "rgba(255,255,255,0.45)";
      cctx.fillText("family-foto.ru", PW_PX / 2, PH_PX * 0.92);

      pdf.addImage(coverCanvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, PW_MM, PH_MM);

      // ============ SPREAD PAGES (2 photos per spread, landscape) ============
      const cornerR = Math.max(6, PW_PX * 0.008);

      for (let i = 0; i < spreads.length; i++) {
        pdf.addPage();
        const spread = spreads[i];
        const sCanvas = document.createElement("canvas");
        sCanvas.width = PW_PX;
        sCanvas.height = PH_PX;
        const sctx = sCanvas.getContext("2d")!;

        sctx.fillStyle = "#ffffff";
        sctx.fillRect(0, 0, PW_PX, PH_PX);

        // Header
        sctx.fillStyle = "#8a8279";
        sctx.textAlign = "center";
        sctx.textBaseline = "top";
        sctx.font = `400 ${Math.max(12, PW_PX * 0.018)}px sans-serif`;
        sctx.fillText(albumHeader, PW_PX / 2, PH_PX * 0.02);

        // Divider between left and right
        sctx.strokeStyle = "rgba(0,0,0,0.06)";
        sctx.lineWidth = 1.5;
        sctx.beginPath();
        sctx.moveTo(PW_PX / 2, PH_PX * 0.05);
        sctx.lineTo(PW_PX / 2, PH_PX * 0.92);
        sctx.stroke();

        // Page labels
        sctx.fillStyle = "#c9a87c";
        sctx.font = `400 ${Math.max(10, PW_PX * 0.014)}px sans-serif`;
        sctx.fillText(`${i * 2 + 1}`, PW_PX * 0.25, PH_PX * 0.955);
        sctx.fillText(`${i * 2 + 2}`, PW_PX * 0.75, PH_PX * 0.955);

        const photoTop = PH_PX * 0.06;
        const photoH = PH_PX * 0.78;
        const photoW = PW_PX * 0.42;
        const photoPad = PW_PX * 0.035;

        // Left photo
        if (spread.left) {
          await drawPhotoInFrame(sctx, spread.left, photoPad, photoTop, photoW, photoH, cornerR);
        }

        // Right photo
        if (spread.right) {
          await drawPhotoInFrame(sctx, spread.right, PW_PX / 2 + photoPad, photoTop, photoW, photoH, cornerR);
        }

        // Footer line
        sctx.strokeStyle = "rgba(0,0,0,0.05)";
        sctx.lineWidth = 1;
        sctx.beginPath();
        sctx.moveTo(PW_PX * 0.15, PH_PX * 0.93);
        sctx.lineTo(PW_PX * 0.85, PH_PX * 0.93);
        sctx.stroke();

        pdf.addImage(sCanvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, PW_MM, PH_MM);
      }

      // ============ FINAL PAGE ============
      pdf.addPage();
      const fCanvas = document.createElement("canvas");
      fCanvas.width = PW_PX;
      fCanvas.height = PH_PX;
      const fctx = fCanvas.getContext("2d")!;

      fctx.fillStyle = "#f5efea";
      fctx.fillRect(0, 0, PW_PX, PH_PX);

      fctx.strokeStyle = "#c9a87c";
      fctx.lineWidth = 2;
      fctx.beginPath();
      fctx.moveTo(PW_PX * 0.15, PH_PX * 0.06);
      fctx.lineTo(PW_PX * 0.85, PH_PX * 0.06);
      fctx.stroke();
      fctx.beginPath();
      fctx.moveTo(PW_PX * 0.15, PH_PX * 0.94);
      fctx.lineTo(PW_PX * 0.85, PH_PX * 0.94);
      fctx.stroke();

      fctx.fillStyle = "#6b4226";
      fctx.textAlign = "center";
      fctx.textBaseline = "middle";
      fctx.font = `bold ${Math.max(28, PW_PX * 0.045)}px serif`;
      fctx.fillText("Спасибо за просмотр!", PW_PX / 2, PH_PX * 0.42);

      fctx.font = `300 ${Math.max(16, PW_PX * 0.025)}px sans-serif`;
      fctx.fillStyle = "#8a8279";
      fctx.fillText("Создайте свой альбом на", PW_PX / 2, PH_PX * 0.52);

      fctx.fillStyle = "#c9a87c";
      fctx.font = `600 ${Math.max(18, PW_PX * 0.028)}px sans-serif`;
      fctx.fillText("family-foto.ru", PW_PX / 2, PH_PX * 0.57);

      pdf.addImage(fCanvas.toDataURL("image/jpeg", 0.92), "JPEG", 0, 0, PW_MM, PH_MM);

      const blob = pdf.output("blob");
      await downloadPDF(blob, fileName);
      const hint = getMobilePDFHint();
      if (hint) alert(hint);
    } catch (e: any) {
      console.error("PDF export error:", e);
      alert("Ошибка создания PDF: " + (e?.message || "неизвестная"));
    } finally {
      setPdfLoading(false);
    }
  }

  async function drawPhotoInFrame(
    ctx: CanvasRenderingContext2D,
    photo: Photo,
    x: number,
    y: number,
    maxW: number,
    maxH: number,
    cornerR: number
  ) {
    try {
      const img = await loadImage(photo.url);
      const aspect = img.width / img.height;
      const maxAspect = maxW / maxH;

      let dw, dh, dx, dy;
      if (aspect > maxAspect) {
        dw = maxW;
        dh = dw / aspect;
        dx = x;
        dy = y + (maxH - dh) / 2;
      } else {
        dh = maxH;
        dw = dh * aspect;
        dx = x + (maxW - dw) / 2;
        dy = y;
      }

      // Shadow
      ctx.save();
      ctx.shadowColor = "rgba(0,0,0,0.10)";
      ctx.shadowBlur = 10;
      ctx.shadowOffsetY = 4;
      ctx.beginPath();
      roundedRect(ctx, dx, dy, dw, dh, cornerR);
      ctx.fillStyle = "#ffffff";
      ctx.fill();
      ctx.restore();

      // Photo clip
      ctx.save();
      ctx.beginPath();
      roundedRect(ctx, dx, dy, dw, dh, cornerR);
      ctx.clip();
      ctx.drawImage(img, dx, dy, dw, dh);
      ctx.restore();

      // Border
      ctx.save();
      ctx.beginPath();
      roundedRect(ctx, dx, dy, dw, dh, cornerR);
      ctx.strokeStyle = "rgba(0,0,0,0.08)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();

      // Caption below photo
      if (photo.caption) {
        ctx.fillStyle = "#6b4226";
        ctx.textAlign = "center";
        ctx.font = `400 ${Math.max(12, maxW * 0.035)}px sans-serif`;
        ctx.fillText(photo.caption, x + maxW / 2, dy + dh + Math.max(16, maxW * 0.04));
      }
    } catch {
      ctx.fillStyle = "#e5ddd0";
      ctx.fillRect(x, y, maxW, maxH);
    }
  }

  function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.arcTo(x + w, y, x + w, y + r, r);
    ctx.lineTo(x + w, y + h - r);
    ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h);
    ctx.arcTo(x, y + h, x, y + h - r, r);
    ctx.lineTo(x, y + r);
    ctx.arcTo(x, y, x + r, y, r);
    ctx.closePath();
  }

  function loadImage(url: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const img = document.createElement("img");
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = reject;
      img.src = url;
    });
  }

  // Compute aspect ratio for the book spread (2 pages side by side)
  const spreadAspect = (selectedFormat.width * 2) / selectedFormat.height;

  // Build spreads from photos (2 per spread)
  const photosPerPage = album?.photosPerPage || 2;
  const spreads: { left: Photo | null; right: Photo | null }[] = [];
  for (let i = 0; i < photos.length; i += photosPerPage) {
    const pagePhotos = photos.slice(i, i + photosPerPage);
    spreads.push({
      left: pagePhotos[0] || null,
      right: pagePhotos[1] || null,
    });
  }

  const currentSpread = spreads[currentPage];

  const goNext = () => {
    if (currentPage < spreads.length - 1) setCurrentPage((p) => p + 1);
  };
  const goPrev = () => {
    if (currentPage > 0) setCurrentPage((p) => p - 1);
  };

  // Categorize formats for display
  const albumFormats = BOOK_FORMATS.filter((f) => f.width > f.height);
  const portraitFormats = BOOK_FORMATS.filter((f) => f.height > f.width);
  const squareFormats = BOOK_FORMATS.filter((f) => f.width === f.height);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#c9a87c] animate-spin" />
      </div>
    );
  }

  if (!album || photos.length === 0) {
    return (
      <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-[#8a8279] mb-4">
            {!album ? "Альбом не найден" : "В альбоме нет фотографий"}
          </p>
          <button
            onClick={() => navigate(`/album/${albumId}`)}
            className="bg-[#c9a87c] text-white px-6 py-2 rounded-xl"
          >
            Назад
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#faf8f5]">
      <header className="bg-white shadow-sm border-b border-[#e5ddd0]">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(`/album/${albumId}`)}
              className="text-[#8a8279] active:text-[#c9a87c]"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-lg font-serif text-[#4a4a4a]">
                {album.title}
              </h1>
              <p className="text-xs text-[#8a8279]">
                Стр. {currentPage + 1} из {spreads.length} · {selectedFormat.label}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowFormatPicker(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#f5f0ea] active:bg-[#e5ddd0] text-[#4a4a4a] rounded-xl text-sm"
            >
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">{selectedFormat.label}</span>
            </button>
            <button
              onClick={handleRegenerate}
              className="p-2 text-[#8a8279] active:text-[#c9a87c] rounded-xl active:bg-[#c9a87c]/10"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 text-[#8a8279] active:text-[#c9a87c] rounded-xl active:bg-[#c9a87c]/10"
            >
              {isFullscreen ? (
                <Minimize2 className="w-4 h-4" />
              ) : (
                <Maximize2 className="w-4 h-4" />
              )}
            </button>
            <button
              onClick={handleExportPDF}
              disabled={pdfLoading}
              className="flex items-center gap-2 bg-[#c9a87c] active:bg-[#b08d65] text-white px-4 py-2 rounded-xl text-sm font-medium disabled:opacity-50"
            >
              {pdfLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              {pdfLoading ? "PDF..." : "PDF"}
            </button>
          </div>
        </div>
      </header>

      {/* Book spread viewer with fixed aspect ratio */}
      <div className={`mx-auto transition-all ${isFullscreen ? "fixed inset-0 z-40" : "max-w-5xl mt-6 px-4"}`}>
        <div
          className={`bg-white shadow-2xl overflow-hidden mx-auto ${isFullscreen ? "h-full w-full rounded-none" : "rounded-2xl"}`}
          style={
            isFullscreen
              ? { aspectRatio: spreadAspect }
              : { aspectRatio: spreadAspect, maxHeight: "70vh" }
          }
        >
          <div className="flex h-full relative">
            {/* Left page */}
            <div
              className="flex-1 border-r border-[#e5ddd0] flex items-center justify-center p-4"
              style={{
                background: `linear-gradient(135deg, ${album.accentColor}15 0%, ${album.backgroundColor} 50%, ${album.accentColor}10 100%)`,
              }}
            >
              {currentSpread?.left ? (
                <div className="relative w-full h-full max-h-full">
                  <img
                    src={currentSpread.left.url}
                    alt={currentSpread.left.caption || ""}
                    className="w-full h-full object-contain rounded-lg"
                  />
                  {currentSpread.left.caption && (
                    <div className="absolute bottom-2 left-2 right-2 bg-black/40 backdrop-blur-sm p-1.5 text-center rounded-lg">
                      <span className="text-white text-xs">{currentSpread.left.caption}</span>
                    </div>
                  )}
                </div>
              ) : (
                <span className="text-[#8a8279] text-sm">Пусто</span>
              )}
            </div>

            {/* Right page */}
            <div
              className="flex-1 flex items-center justify-center p-4"
              style={{
                background: `linear-gradient(135deg, ${album.backgroundColor} 0%, ${album.accentColor}10 100%)`,
              }}
            >
              {currentSpread?.right ? (
                <div className="relative w-full h-full max-h-full">
                  <img
                    src={currentSpread.right.url}
                    alt={currentSpread.right.caption || ""}
                    className="w-full h-full object-contain rounded-lg"
                  />
                  {currentSpread.right.caption && (
                    <div className="absolute bottom-2 left-2 right-2 bg-black/40 backdrop-blur-sm p-1.5 text-center rounded-lg">
                      <span className="text-white text-xs">{currentSpread.right.caption}</span>
                    </div>
                  )}
                </div>
              ) : (
                <span className="text-[#8a8279] text-sm">Пусто</span>
              )}
            </div>

            {/* Navigation arrows */}
            {currentPage > 0 && (
              <button
                onClick={goPrev}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 active:bg-white rounded-full flex items-center justify-center shadow-md"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            )}
            {currentPage < spreads.length - 1 && (
              <button
                onClick={goNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 active:bg-white rounded-full flex items-center justify-center shadow-md"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Page thumbnails */}
      {!isFullscreen && (
        <div className="max-w-5xl mx-auto px-4 py-6">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {spreads.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentPage(idx)}
                className={`flex-shrink-0 w-16 h-12 rounded-lg border-2 transition-all ${
                  idx === currentPage
                    ? "border-[#c9a87c]"
                    : "border-transparent opacity-60 active:opacity-100"
                }`}
                style={{
                  background: `linear-gradient(135deg, ${album.accentColor}20 0%, ${album.backgroundColor} 100%)`,
                }}
              >
                <span className="text-xs text-[#8a8279]">{idx + 1}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Format picker modal */}
      {showFormatPicker && (
        <div
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
          onClick={() => setShowFormatPicker(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-md w-full max-h-[80vh] overflow-y-auto p-5 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">Формат книги</h3>
              <button
                onClick={() => setShowFormatPicker(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Album formats */}
            <p className="text-xs font-medium text-[#8a8279] uppercase tracking-wider mb-2">
              Альбомные (широкие)
            </p>
            <div className="grid grid-cols-4 gap-2 mb-4">
              {albumFormats.map((f) => (
                <FormatItem
                  key={f.id}
                  format={f}
                  selected={selectedFormat.id === f.id}
                  onClick={() => handleSelectFormat(f)}
                />
              ))}
            </div>

            {/* Portrait formats */}
            <p className="text-xs font-medium text-[#8a8279] uppercase tracking-wider mb-2">
              Портретные (высокие)
            </p>
            <div className="grid grid-cols-4 gap-2 mb-4">
              {portraitFormats.map((f) => (
                <FormatItem
                  key={f.id}
                  format={f}
                  selected={selectedFormat.id === f.id}
                  onClick={() => handleSelectFormat(f)}
                />
              ))}
            </div>

            {/* Square formats */}
            <p className="text-xs font-medium text-[#8a8279] uppercase tracking-wider mb-2">
              Квадратные
            </p>
            <div className="grid grid-cols-4 gap-2">
              {squareFormats.map((f) => (
                <FormatItem
                  key={f.id}
                  format={f}
                  selected={selectedFormat.id === f.id}
                  onClick={() => handleSelectFormat(f)}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FormatItem({
  format,
  selected,
  onClick,
}: {
  format: BookFormat;
  selected: boolean;
  onClick: () => void;
}) {
  // Visual aspect for the book icon
  const isLandscape = format.width > format.height;
  const isPortrait = format.height > format.width;
  const aspect = isLandscape
    ? 1.4
    : isPortrait
    ? 0.7
    : 1;

  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 p-2 rounded-xl border-2 transition-all ${
        selected
          ? "border-[#c9a87c] bg-[#c9a87c]/10"
          : "border-[#e5ddd0] bg-white active:border-[#c9a87c]"
      }`}
    >
      <div
        className="bg-[#c9a87c]/30 rounded-sm flex items-center justify-center relative"
        style={{
          width: aspect >= 1 ? 36 : 28,
          height: aspect >= 1 ? 28 : 36,
        }}
      >
        {/* Book spine visual */}
        <div
          className="absolute left-0 top-0 bottom-0 w-[2px] bg-[#c9a87c]/60 rounded-l-sm"
          style={{ borderRadius: "2px 0 0 2px" }}
        />
        {selected && (
          <Check className="w-3 h-3 text-[#c9a87c]" />
        )}
      </div>
      <span className="text-[10px] text-[#4a4a4a] font-medium">{format.label}</span>
    </button>
  );
}
