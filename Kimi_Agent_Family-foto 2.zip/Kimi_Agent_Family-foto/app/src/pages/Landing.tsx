import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { albumApi, logout, inviteApi, photoApi, seedDemoData, getUpcomingBirthdays } from "../lib/api";
import type { Album } from "../types";
import {
  HelpCircle,
  Users,
  LogOut,
  BookOpen,
  Search,
  ChevronDown,
  MapPin,
  Calendar,
  Star,
  Sparkles,
  MessageCircle,
  Plus,
  Globe,
  Copy,
  Check,
  X,
  Send,
  Smartphone,
  Share2,
  Settings,
  Trash2,
  Cake,
  PartyPopper,
} from "lucide-react";

export default function Landing() {
  const navigate = useNavigate();
  const [albums, setAlbums] = useState<Album[]>([]);
  const [sharedAlbums, setSharedAlbums] = useState<Album[]>([]);
  const [birthdays, setBirthdays] = useState<ReturnType<typeof getUpcomingBirthdays>>([]);
  const [activeTab, setActiveTab] = useState<"my" | "shared">("my");
  const [search, setSearch] = useState("");
  const [showYearFilter, setShowYearFilter] = useState(false);
  const [yearFilter, setYearFilter] = useState<string>("all");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [albumToDelete, setAlbumToDelete] = useState<Album | null>(null);
  const [showAlbumSettings, setShowAlbumSettings] = useState(false);
  const [albumToEdit, setAlbumToEdit] = useState<Album | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDescription, setEditDescription] = useState("");
  const [editYear, setEditYear] = useState("");
  const [editMonth, setEditMonth] = useState("");
  const [showSystemInvite, setShowSystemInvite] = useState(false);
  const [showSupportChat, setShowSupportChat] = useState(false);
  const [supportName, setSupportName] = useState("");
  const [supportEmail, setSupportEmail] = useState("");
  const [supportMessage, setSupportMessage] = useState("");
  const [supportSent, setSupportSent] = useState(false);
  const [showInstallModal, setShowInstallModal] = useState(false);
  const [systemLink, setSystemLink] = useState("");
  const [copied, setCopied] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  useEffect(() => {
    seedDemoData();
    loadAlbums();

    function handleVisibility() {
      if (!document.hidden) loadAlbums();
    }
    document.addEventListener("visibilitychange", handleVisibility);

    // PWA install prompt capture
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
    };
    window.addEventListener("beforeinstallprompt", handler);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
      window.removeEventListener("beforeinstallprompt", handler);
    };
  }, []);

  function handleSendSupport() {
    if (!supportName.trim()) {
      alert("Введите ваше имя");
      return;
    }
    if (!supportEmail.trim()) {
      alert("Введите email или телефон");
      return;
    }
    if (!supportMessage.trim()) {
      alert("Напишите сообщение");
      return;
    }
    const ticket = {
      id: Date.now().toString(),
      name: supportName || "Аноним",
      email: supportEmail || "",
      message: supportMessage.trim(),
      createdAt: new Date().toISOString(),
      status: "new",
    };
    const tickets = JSON.parse(localStorage.getItem("support_tickets") || "[]");
    tickets.push(ticket);
    localStorage.setItem("support_tickets", JSON.stringify(tickets));
    setSupportSent(true);
    setSupportName("");
    setSupportEmail("");
    setSupportMessage("");
    // Simulate sending to email
    setTimeout(() => setShowSupportChat(false), 2500);
  }

  function openDeleteConfirm(album: Album) {
    setAlbumToDelete(album);
    setShowDeleteConfirm(true);
  }

  function confirmDeleteAlbum() {
    if (!albumToDelete) return;
    albumApi.delete(albumToDelete.id);
    setShowDeleteConfirm(false);
    setAlbumToDelete(null);
    loadAlbums();
  }

  function openAlbumSettings(album: Album) {
    setAlbumToEdit(album);
    setEditTitle(album.title);
    setEditDescription(album.description || "");
    setEditYear(album.year?.toString() || "");
    setEditMonth(album.month?.toString() || "");
    setShowAlbumSettings(true);
  }

  function saveAlbumSettings() {
    if (!albumToEdit) return;
    albumApi.update(albumToEdit.id, {
      title: editTitle.trim() || albumToEdit.title,
      description: editDescription.trim() || undefined,
      year: editYear ? Number(editYear) : undefined,
      month: editMonth ? Number(editMonth) : undefined,
    });
    setShowAlbumSettings(false);
    setAlbumToEdit(null);
    loadAlbums();
  }

  async function loadAlbums() {
    try {
      const my = await albumApi.list();
      setAlbums(my);
      setSharedAlbums([]);
      setBirthdays(getUpcomingBirthdays(30));
    } catch (e) {
      console.error("loadAlbums error:", e);
    }
  }

  async function handleSystemInvite() {
    try {
      const invite = await inviteApi.create({ type: "system", role: "viewer" });
      const link = `${window.location.origin}/#/invite/${invite.token}`;
      setSystemLink(link);
      setShowSystemInvite(true);
      setCopied(false);
    } catch (e) {
      console.error("invite error:", e);
    }
  }

  async function handleShareSystem() {
    if (!systemLink) return;
    try {
      if ((navigator as any).share) {
        await (navigator as any).share({
          title: "Семейный Альбом",
          text: "Приглашение в семейный альбом на family-foto.ru",
          url: systemLink,
        });
      } else {
        alert("Отправка: скопируйте ссылку и отправьте в мессенджер.");
      }
    } catch (e: any) {
      if (e.name !== "AbortError") console.error("Share error:", e);
    }
  }

  function copyLink() {
    navigator.clipboard.writeText(systemLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  // Years from albums for filter
  const availableYears = Array.from(
    new Set(albums.map((a) => new Date(a.createdAt).getFullYear().toString()))
  ).sort((a, b) => parseInt(b) - parseInt(a));

  const currentAlbums = activeTab === "my" ? albums : sharedAlbums;

  // Smart search + year filter
  const filteredAlbums = currentAlbums.filter((a) => {
    const matchTitle = a.title.toLowerCase().includes(search.toLowerCase());
    const matchYear = yearFilter === "all" || new Date(a.createdAt).getFullYear().toString() === yearFilter;
    if (!matchYear) return false;
    if (matchTitle) return true;
    // Search in photo captions
    if (search.length > 1) {
      const albumPhotos = photoApi.list(a.id);
      return albumPhotos.some(
        (p) => p.caption && p.caption.toLowerCase().includes(search.toLowerCase())
      );
    }
    return false;
  });

  // Get user email from localStorage
  const userStr = localStorage.getItem("auth_user");
  const userEmail = userStr ? JSON.parse(userStr).email : "";

  return (
    <div className="min-h-screen bg-[#faf8f5] pb-20">
      {/* Header */}
      <div className="bg-[#c9a87c] text-white px-3 py-3">
        <div className="max-w-lg mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0">
              <BookOpen className="w-5 h-5 flex-shrink-0" />
              <div className="min-w-0">
                <span className="font-serif text-base truncate block">
                  Семейный Альбом
                </span>
                {userEmail && (
                  <span className="text-[10px] text-white/70 truncate block">
                    {userEmail}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0 ml-2">
              <button
                type="button"
                onClick={() => setShowInstallModal(true)}
                className="w-10 h-10 bg-white/30 rounded-full flex items-center justify-center active:bg-white/50 active:scale-90 transition-all"
                title="Установить ярлык на телефон"
                style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
              >
                <Smartphone className="w-4 h-4" />
              </button>
              <button
                type="button"
                onTouchStart={(e) => { e.stopPropagation(); setTimeout(() => navigate("/support"), 50); }}
                onClick={() => navigate("/support")}
                className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center active:bg-white/40 active:scale-90 transition-all"
                title="Инструкция использования"
                style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
              >
                <HelpCircle className="w-4 h-4" />
              </button>
              <button
                type="button"
                onTouchStart={(e) => { e.stopPropagation(); setTimeout(() => handleSystemInvite(), 50); }}
                onClick={handleSystemInvite}
                className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center active:bg-white/40 active:scale-90 transition-all"
                title="Отправить другу"
                style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
              >
                <Globe className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setShowSupportChat(true)}
                className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center active:bg-white/40 active:scale-90 transition-all"
                title="Чат поддержки"
                style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
              >
                <MessageCircle className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => { logout(); window.location.href = "#/login"; }}
                className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center active:bg-white/40 active:scale-90 transition-all"
                title="Выход"
                style={{ touchAction: "manipulation", WebkitTapHighlightColor: "transparent" }}
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-lg mx-auto px-4 py-4 space-y-4">
        {/* Title */}
        <div className="text-center">
          <div className="flex items-center justify-center gap-2 text-[#c9a87c]">
            <Sparkles className="w-4 h-4" />
            <span className="text-xs font-medium tracking-[0.15em] uppercase">
              Ваши воспоминания
            </span>
          </div>
        </div>

        {/* Rating */}
        <div className="bg-white rounded-2xl px-4 py-3 flex items-center justify-between shadow-sm">
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((s) => (
              <Star
                key={s}
                className="w-4 h-4 text-[#c9a87c] fill-[#c9a87c]"
              />
            ))}
            <span className="text-sm font-medium text-[#4a4a4a] ml-1.5">
              5.0
            </span>
            <span className="text-xs text-[#8a8279] ml-1">· 1 оценка</span>
          </div>
          <button
            type="button"
            onTouchStart={(e) => { e.stopPropagation(); navigate("/support"); }}
            onClick={() => navigate("/support")}
            className="text-xs text-[#c9a87c] active:text-[#b8976a] font-medium whitespace-nowrap"
            style={{ touchAction: "manipulation" }}
          >
            Поддержать проект
          </button>
        </div>

        {/* Birthdays */}
        {birthdays.length > 0 && (
          <div className="mb-2">
            <div className="flex items-center gap-2 mb-2">
              <Cake className="w-4 h-4 text-[#c9a87c]" />
              <h3 className="text-sm font-medium text-[#4a4a4a]">
                {birthdays[0].daysUntil === 0
                  ? "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u0434\u0435\u043D\u044C \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F!"
                  : birthdays[0].daysUntil === 1
                  ? "\u0417\u0430\u0432\u0442\u0440\u0430 \u0434\u0435\u043D\u044C \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F!"
                  : "\u0411\u043B\u0438\u0436\u0430\u0439\u0448\u0438\u0435 \u0434\u043D\u0438 \u0440\u043E\u0436\u0434\u0435\u043D\u0438\u044F"}
              </h3>
            </div>
            <div className="flex gap-2 overflow-x-auto pb-1 snap-x snap-mandatory" style={{ scrollbarWidth: "none" }}>
              {birthdays.map((b) => (
                <button
                  key={b.memberId}
                  type="button"
                  onClick={() => navigate(`/album/${b.albumId}`)}
                  className={`flex-shrink-0 snap-start rounded-2xl p-3 min-w-[140px] max-w-[160px] text-left relative overflow-hidden shadow-sm border ${
                    b.daysUntil === 0
                      ? "bg-[#c9a87c] text-white border-[#c9a87c]"
                      : b.daysUntil <= 3
                      ? "bg-[#fef3e2] border-[#f5d9a3]"
                      : "bg-white border-[#e5ddd0]/50"
                  }`}
                  style={{ touchAction: "manipulation" }}
                >
                  {b.daysUntil === 0 && (
                    <PartyPopper className="absolute top-1 right-1 w-5 h-5 text-white/40" />
                  )}
                  <div className="flex items-center gap-2 mb-1.5">
                    {b.photoUrl ? (
                      <img
                        src={b.photoUrl}
                        alt={b.name}
                        className="w-8 h-8 rounded-full object-cover flex-shrink-0"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-[#f0ebe3] flex items-center justify-center flex-shrink-0">
                        <Cake className="w-4 h-4 text-[#c9a87c]" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className={`text-xs font-medium truncate ${b.daysUntil === 0 ? "text-white" : "text-[#4a4a4a]"}`}>
                        {b.name}
                      </p>
                      <p className={`text-[10px] ${b.daysUntil === 0 ? "text-white/70" : "text-[#8a8279]"}`}>
                        {b.role}
                      </p>
                    </div>
                  </div>
                  <p className={`text-[10px] ${b.daysUntil === 0 ? "text-white/80" : "text-[#8a8279]"}`}>
                    {b.daysUntil === 0
                      ? "\u0421\u0435\u0433\u043E\u0434\u043D\u044F!"
                      : b.daysUntil === 1
                      ? "\u0417\u0430\u0432\u0442\u0440\u0430"
                      : `\u0427\u0435\u0440\u0435\u0437 ${b.daysUntil} \u0434\u043D.`}
                    {" "}
                    <span className={b.daysUntil === 0 ? "text-white/60" : "text-[#a09890]"}>
                      {new Date(b.birthDate).toLocaleDateString("ru-RU", { day: "numeric", month: "short" })}
                    </span>
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onTouchStart={(e) => { e.stopPropagation(); setActiveTab("my"); }}
            onClick={() => setActiveTab("my")}
            className={`rounded-2xl p-4 flex items-center gap-3 shadow-sm transition-colors text-left ${
              activeTab === "my"
                ? "bg-[#c9a87c] text-white"
                : "bg-white text-[#8a8279] border border-[#e5ddd0]/50"
            }`}
            style={{ touchAction: "manipulation" }}
          >
            <BookOpen className="w-5 h-5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium">Мои альбомы</p>
              <p className={`text-xs ${activeTab === "my" ? "text-white/70" : "text-[#8a8279]"}`}>
                ({albums.length})
              </p>
            </div>
          </button>
          <button
            type="button"
            onTouchStart={(e) => { e.stopPropagation(); setActiveTab("shared"); }}
            onClick={() => setActiveTab("shared")}
            className={`rounded-2xl p-4 flex items-center gap-3 shadow-sm transition-colors text-left ${
              activeTab === "shared"
                ? "bg-[#c9a87c] text-white"
                : "bg-white text-[#8a8279] border border-[#e5ddd0]/50"
            }`}
            style={{ touchAction: "manipulation" }}
          >
            <Users className="w-5 h-5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium">Поделились</p>
              <p className="text-sm font-medium">со мной</p>
              {sharedAlbums.length > 0 && (
                <p className={`text-xs ${activeTab === "shared" ? "text-white/70" : "text-[#8a8279]"}`}>
                  ({sharedAlbums.length})
                </p>
              )}
            </div>
          </button>
        </div>

        {/* Search */}
        {activeTab === "my" && (
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8a8279]" />
              <input
                type="text"
                placeholder="Поиск по названию и AI-описаниям..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-10 py-3 bg-white rounded-2xl border border-[#e5ddd0]/50 focus:outline-none focus:ring-2 focus:ring-[#c9a87c] text-sm"
              />
              <Sparkles className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#c9a87c]" />
            </div>
            <button
              type="button"
              onClick={() => setShowYearFilter(!showYearFilter)}
              className="w-full flex items-center justify-between px-4 py-3 bg-white rounded-2xl border border-[#e5ddd0]/50 text-sm text-[#4a4a4a] active:bg-[#faf8f5]"
              style={{ touchAction: "manipulation" }}
            >
              <span>{yearFilter === "all" ? "Все годы" : yearFilter}</span>
              <ChevronDown className={`w-4 h-4 text-[#8a8279] transition-transform ${showYearFilter ? "rotate-180" : ""}`} />
            </button>

            {showYearFilter && (
              <div className="bg-white rounded-2xl border border-[#e5ddd0]/50 overflow-hidden shadow-lg">
                <div
                  role="button"
                  onTouchStart={() => { setYearFilter("all"); setShowYearFilter(false); }}
                  onClick={() => { setYearFilter("all"); setShowYearFilter(false); }}
                  className={`w-full px-4 py-3 text-left text-sm touch-manipulation ${yearFilter === "all" ? "bg-[#c9a87c]/10 text-[#6b4226] font-medium" : "text-[#4a4a4a] active:bg-[#f5f0ea]"}`}
                >
                  Все годы
                </div>
                {availableYears.map((y) => (
                  <div
                    key={y}
                    role="button"
                    onTouchStart={() => { setYearFilter(y); setShowYearFilter(false); }}
                    onClick={() => { setYearFilter(y); setShowYearFilter(false); }}
                    className={`w-full px-4 py-3 text-left text-sm touch-manipulation ${yearFilter === y ? "bg-[#c9a87c]/10 text-[#6b4226] font-medium" : "text-[#4a4a4a] active:bg-[#f5f0ea]"}`}
                  >
                    {y}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Big Add Album Button — только в Мои альбомы */}
        {activeTab === "my" && (
          <button
            type="button"
            onTouchStart={(e) => { e.stopPropagation(); window.location.href = "#/create-album"; }}
            onClick={() => window.location.href = "#/create-album"}
            className="w-full bg-[#c9a87c] text-white rounded-2xl py-4 flex items-center justify-center gap-3 shadow-md active:bg-[#a6875a] active:scale-[0.98] transition-all"
            style={{ touchAction: "manipulation" }}
          >
            <Plus className="w-5 h-5" />
            <span className="text-base font-medium">Новый альбом</span>
          </button>
        )}

        {/* Albums */}
        <div className="space-y-3">
          {filteredAlbums.map((album) => (
            <div
              key={album.id}
              className="bg-white rounded-2xl overflow-hidden shadow-sm"
            >
              {/* Cover */}
              <div className="relative aspect-[16/10]">
                {album.coverPhoto ? (
                  <img
                    src={album.coverPhoto}
                    alt={album.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div
                    className="w-full h-full"
                    style={{
                      background: `linear-gradient(135deg, ${album.accentColor}30 0%, ${album.backgroundColor} 50%, ${album.accentColor}20 100%)`,
                    }}
                  />
                )}
                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1.5">
                  {album.albumType === "family_tree" ? (
                    <span className="text-sm">🌳</span>
                  ) : (
                    <Calendar className="w-3.5 h-3.5 text-[#c9a87c]" />
                  )}
                  <span className="text-xs font-medium text-[#4a4a4a]">
                    {album.year || new Date(album.createdAt).getFullYear()}
                    {album.month ? ` · ${["Янв","Фев","Мар","Апр","Май","Июн","Июл","Авг","Сен","Окт","Ноя","Дек"][album.month - 1]}` : ""}
                  </span>
                </div>
                <div className="absolute top-3 right-3 flex items-center gap-2">
                  <button
                    type="button"
                    onTouchStart={(e) => { e.stopPropagation(); openAlbumSettings(album); }}
                    onClick={(e) => { e.stopPropagation(); openAlbumSettings(album); }}
                    className="w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-[#8a8279] active:text-[#c9a87c]"
                    style={{ touchAction: "manipulation" }}
                  >
                    <Settings className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onTouchStart={(e) => { e.stopPropagation(); openDeleteConfirm(album); }}
                    onClick={(e) => { e.stopPropagation(); openDeleteConfirm(album); }}
                    className="w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center text-[#8a8279] active:text-red-500"
                    style={{ touchAction: "manipulation" }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              {/* Info */}
              <div className="p-4">
                <h3 className="font-serif text-lg text-[#4a4a4a] mb-1">
                  {album.title}
                </h3>
                <div className="flex items-center gap-1 text-sm text-[#8a8279] mb-3">
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{album.description || "Локация"}</span>
                </div>
                <button
                  type="button"
                  onTouchStart={(e) => { e.stopPropagation(); window.location.href = `#/album/${album.id}`; }}
                  onClick={(e) => {
                    e.stopPropagation();
                    window.location.href = `#/album/${album.id}`;
                  }}
                  className="w-full bg-[#c9a87c] text-white py-2.5 rounded-xl text-sm font-medium flex items-center justify-center gap-2 active:bg-[#a6875a] transition-colors"
                  style={{ touchAction: "manipulation" }}
                >
                  <BookOpen className="w-4 h-4" />
                  Открыть альбом
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Empty states */}
        {filteredAlbums.length === 0 && activeTab === "my" && (
          <div className="text-center py-12">
            <BookOpen className="w-12 h-12 text-[#c9a87c]/30 mx-auto mb-4" />
            <p className="text-[#8a8279] mb-4">Нет альбомов</p>
          </div>
        )}
        {filteredAlbums.length === 0 && activeTab === "shared" && (
          <div className="text-center py-12">
            <Users className="w-12 h-12 text-[#c9a87c]/30 mx-auto mb-4" />
            <p className="text-[#8a8279] mb-2">Нет альбомов, которыми с вами поделились</p>
            <p className="text-xs text-[#8a8279]/70">
              Когда кто-то пригласит вас в альбом, он появится здесь
            </p>
          </div>
        )}
      </main>

      {/* System Invite Modal */}
      {showSystemInvite && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowSystemInvite(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a]">Пригласить в систему</h3>
              <button
                type="button"
                onClick={() => setShowSystemInvite(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#8a8279] mb-3">
              Получатель увидит все альбомы системы
            </p>
            <div className="bg-[#f5f0ea] rounded-xl p-3 mb-3 break-all text-xs text-[#4a4a4a]">
              {systemLink}
            </div>
            <button
              type="button"
              onClick={handleShareSystem}
              className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-2.5 flex items-center justify-center gap-2 font-medium mb-2"
            >
              <Share2 className="w-4 h-4" />
              Поделиться ссылкой
            </button>
            <button
              type="button"
              onClick={copyLink}
              className="w-full bg-[#f5f0ea] active:bg-[#e5ddd0] text-[#4a4a4a] rounded-xl py-2.5 flex items-center justify-center gap-2 font-medium text-sm"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-green-600" />
                  <span className="text-green-600">Скопировано!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Копировать ссылку
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Support Chat Modal */}
      {showSupportChat && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowSupportChat(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a] flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-[#c9a87c]" />
                Чат поддержки
              </h3>
              <button
                type="button"
                onClick={() => setShowSupportChat(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {supportSent ? (
              <div className="text-center py-4">
                <div className="w-14 h-14 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Check className="w-7 h-7 text-green-600" />
                </div>
                <p className="text-[#4a4a4a] font-medium mb-1">Сообщение отправлено!</p>
                <p className="text-sm text-[#8a8279]">
                  Мы ответим вам на почту или в мессенджер.
                </p>
              </div>
            ) : (
              <>
                <p className="text-sm text-[#8a8279] mb-3">
                  Напишите нам — ответим как можно скорее.
                </p>
                <input
                  type="text"
                  value={supportName}
                  onChange={(e) => setSupportName(e.target.value)}
                  placeholder="Ваше имя"
                  className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm mb-2"
                />
                <input
                  type="email"
                  value={supportEmail}
                  onChange={(e) => setSupportEmail(e.target.value)}
                  placeholder="Email или телефон"
                  className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm mb-2"
                />
                <textarea
                  value={supportMessage}
                  onChange={(e) => setSupportMessage(e.target.value)}
                  placeholder="Ваше сообщение..."
                  rows={4}
                  className="w-full px-4 py-3 border border-[#e5ddd0] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#c9a87c] bg-[#faf8f5] text-sm mb-3 resize-none"
                />
                <button
                  type="button"
                  onClick={handleSendSupport}
                  className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-3 flex items-center justify-center gap-2 font-medium"
                >
                  <Send className="w-4 h-4" />
                  Отправить
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* Install App Modal */}
      {showInstallModal && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowInstallModal(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-serif text-[#4a4a4a] flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-[#c9a87c]" />
                Установить приложение
              </h3>
              <button
                type="button"
                onClick={() => setShowInstallModal(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* iOS Instructions */}
            <div className="bg-[#faf8f5] rounded-xl p-4 mb-3">
              <p className="text-sm font-medium text-[#4a4a4a] mb-2">iPhone / iPad</p>
              <ol className="text-sm text-[#8a8279] space-y-1.5 list-decimal list-inside">
                <li>Нажмите «Поделиться» в Safari внизу</li>
                <li>Прокрутите вниз и выберите «На экран Домой»</li>
                <li>Нажмите «Добавить»</li>
              </ol>
            </div>

            {/* Android button */}
            <button
              type="button"
              onClick={() => {
                setShowInstallModal(false);
                setTimeout(() => {
                  if (installPrompt) {
                    installPrompt.prompt();
                    installPrompt.userChoice.then(() => setInstallPrompt(null));
                  }
                }, 300);
              }}
              className="w-full bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-3 flex items-center justify-center gap-2 font-medium"
            >
              <Smartphone className="w-4 h-4" />
              Android — Установить
            </button>
          </div>
        </div>
      )}
    {/* Delete Album Confirmation Modal */}
      {showDeleteConfirm && albumToDelete && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowDeleteConfirm(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <h3 className="text-lg font-serif text-[#4a4a4a]">Удалить альбом?</h3>
                <p className="text-sm text-[#8a8279]">{albumToDelete.title}</p>
              </div>
            </div>
            <p className="text-sm text-[#8a8279] mb-4">
              Все фото альбома будут удалены безвозвратно.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 bg-[#f5f0ea] text-[#4a4a4a] rounded-xl py-3 font-medium"
                style={{ touchAction: "manipulation" }}
              >
                Отмена
              </button>
              <button
                type="button"
                onClick={confirmDeleteAlbum}
                className="flex-1 bg-red-500 active:bg-red-600 text-white rounded-xl py-3 font-medium"
                style={{ touchAction: "manipulation" }}
              >
                Удалить
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Album Settings Modal */}
      {showAlbumSettings && albumToEdit && (
        <div
          className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
          onClick={() => setShowAlbumSettings(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#c9a87c]" />
                <h3 className="text-lg font-serif text-[#4a4a4a]">Настройки альбома</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAlbumSettings(false)}
                className="w-8 h-8 rounded-full bg-[#f5f0ea] flex items-center justify-center text-[#8a8279] active:bg-[#e5ddd0]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-sm text-[#8a8279] mb-1">Название</label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                />
              </div>
              <div>
                <label className="block text-sm text-[#8a8279] mb-1">Локация / Описание</label>
                <input
                  type="text"
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                />
              </div>
              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="block text-sm text-[#8a8279] mb-1">Год</label>
                  <input
                    type="number"
                    value={editYear}
                    onChange={(e) => setEditYear(e.target.value)}
                    placeholder="2025"
                    className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm text-[#8a8279] mb-1">Месяц</label>
                  <select
                    value={editMonth}
                    onChange={(e) => setEditMonth(e.target.value)}
                    className="w-full px-3 py-2.5 border border-[#e5ddd0] rounded-xl text-sm bg-[#faf8f5] focus:outline-none focus:ring-2 focus:ring-[#c9a87c]"
                  >
                    <option value="">—</option>
                    {["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"].map((m, i) => (
                      <option key={i + 1} value={i + 1}>{m}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <button
              type="button"
              onTouchStart={() => saveAlbumSettings()}
              onClick={() => saveAlbumSettings()}
              className="w-full mt-4 bg-[#c9a87c] active:bg-[#b08d65] text-white rounded-xl py-3.5 font-medium min-h-[48px] select-none"
              style={{ touchAction: "manipulation" }}
            >
              Сохранить
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
