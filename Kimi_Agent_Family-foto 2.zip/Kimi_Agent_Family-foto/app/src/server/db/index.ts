// Simple in-memory database with localStorage persistence
import type { Album, Photo, FamilyMember, PhotoBookPage, Invite, SupportReview, User } from "../../types";

const DB_KEY = "family_album_db";

interface Database {
  albums: Album[];
  photos: Photo[];
  familyMembers: FamilyMember[];
  photoBookPages: PhotoBookPage[];
  invites: Invite[];
  supportReviews: SupportReview[];
  users: User[];
}

let db: Database;

try {
  const stored = localStorage.getItem(DB_KEY);
  if (stored) {
    db = JSON.parse(stored);
    // Clean up: remove photos/members embedded in albums (they belong in separate arrays)
    db.albums.forEach((a: any) => {
      delete a.photos;
      delete a.members;
    });
    if (!db.users) db.users = [];
  } else {
    db = getDefaultDb();
  }
} catch {
  db = getDefaultDb();
}

function getDefaultDb(): Database {
  return {
    albums: [],
    photos: [],
    familyMembers: [],
    photoBookPages: [],
    invites: [],
    supportReviews: [],
    users: [],
  };
}

function persist() {
  // Strip photos/members from albums before saving (they're stored in separate arrays)
  const clean = {
    ...db,
    albums: db.albums.map((a) => {
      const { photos, members, ...rest } = a as any;
      return rest;
    }),
  };
  localStorage.setItem(DB_KEY, JSON.stringify(clean));
}

function generateId(): number {
  return Date.now() + Math.floor(Math.random() * 1000);
}

function generateToken(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}

// Album operations
export function getAlbums(userId: number): Album[] {
  return db.albums
    .filter((a) => a.createdBy === userId)
    .map((album) => {
      // If no coverPhoto set, try to find one from isCover photo
      if (!album.coverPhoto) {
        const coverPhoto = db.photos.find(
          (p) => p.albumId === album.id && p.isCover
        );
        if (coverPhoto) {
          return { ...album, coverPhoto: coverPhoto.url };
        }
      }
      return { ...album };
    });
}

export function getSharedAlbums(_userId: number): Album[] {
  // Shared albums are fetched via invite system, not familyMembers
  return [];
}

export function getAlbumById(id: number): Album | undefined {
  const album = db.albums.find((a) => a.id === id);
  if (!album) return undefined;
  // Return a copy to avoid mutating the persisted object
  return {
    ...album,
    photos: db.photos.filter((p) => p.albumId === id),
    members: db.familyMembers.filter((m) => m.albumId === id),
  };
}

export function createAlbum(data: Omit<Album, "id" | "createdAt" | "updatedAt">): Album {
  const album: Album = {
    ...data,
    id: generateId(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  db.albums.push(album);
  persist();
  return album;
}

export function updateAlbum(id: number, data: Partial<Album>): Album | undefined {
  const idx = db.albums.findIndex((a) => a.id === id);
  if (idx === -1) return undefined;
  db.albums[idx] = { ...db.albums[idx], ...data, updatedAt: new Date().toISOString() };
  persist();
  return db.albums[idx];
}

export function deleteAlbum(id: number): boolean {
  const idx = db.albums.findIndex((a) => a.id === id);
  if (idx === -1) return false;
  db.albums.splice(idx, 1);
  db.photos = db.photos.filter((p) => p.albumId !== id);
  db.familyMembers = db.familyMembers.filter((m) => m.albumId !== id);
  db.photoBookPages = db.photoBookPages.filter((p) => p.albumId !== id);
  persist();
  return true;
}

// Photo operations
export function getPhotos(albumId: number): Photo[] {
  return db.photos.filter((p) => p.albumId === albumId);
}

export function createPhoto(data: Omit<Photo, "id" | "createdAt">): Photo {
  const photo: Photo = {
    ...data,
    id: generateId(),
    createdAt: new Date().toISOString(),
  };
  db.photos.push(photo);
  persist();
  return photo;
}

export function createPhotosBatch(data: Omit<Photo, "id" | "createdAt">[]): Photo[] {
  const photos = data.map((d) => ({ ...d, id: generateId(), createdAt: new Date().toISOString() }));
  db.photos.push(...photos);
  persist();
  return photos;
}

export function updatePhoto(id: number, data: Partial<Photo>): Photo | undefined {
  const idx = db.photos.findIndex((p) => p.id === id);
  if (idx === -1) return undefined;
  db.photos[idx] = { ...db.photos[idx], ...data };
  persist();
  return db.photos[idx];
}

// Get all photos (for AI search)
export function getAllPhotos(): Photo[] {
  return [...db.photos];
}

export function deletePhoto(id: number): boolean {
  const idx = db.photos.findIndex((p) => p.id === id);
  if (idx === -1) return false;
  db.photos.splice(idx, 1);
  persist();
  return true;
}

export function setCoverPhoto(albumId: number, photoId: number): boolean {
  db.photos.forEach((p) => {
    if (p.albumId === albumId) p.isCover = p.id === photoId;
  });
  persist();
  return true;
}

// Family Member operations
export function getFamilyMembers(albumId: number): FamilyMember[] {
  return db.familyMembers.filter((m) => m.albumId === albumId);
}

export function createFamilyMember(data: Omit<FamilyMember, "id" | "createdAt">): FamilyMember {
  const member: FamilyMember = {
    ...data,
    id: generateId(),
    createdAt: new Date().toISOString(),
  };
  db.familyMembers.push(member);
  persist();
  return member;
}

export function deleteFamilyMember(id: number): boolean {
  const idx = db.familyMembers.findIndex((m) => m.id === id);
  if (idx === -1) return false;
  db.familyMembers.splice(idx, 1);
  persist();
  return true;
}

export function updateFamilyMember(id: number, data: Partial<FamilyMember>): FamilyMember | null {
  const idx = db.familyMembers.findIndex((m) => m.id === id);
  if (idx === -1) return null;
  db.familyMembers[idx] = { ...db.familyMembers[idx], ...data };
  persist();
  return db.familyMembers[idx];
}

// Photo Book operations
export function getPhotoBookPages(albumId: number): PhotoBookPage[] {
  return db.photoBookPages
    .filter((p) => p.albumId === albumId)
    .sort((a, b) => a.pageNumber - b.pageNumber);
}

export function getPhotoBookAssignments(albumId: number): PhotoBookPage[] {
  return getPhotoBookPages(albumId);
}

export function assignPhotoToPage(albumId: number, pageNumber: number, photoId: number): boolean {
  const page = db.photoBookPages.find(
    (p) => p.albumId === albumId && p.pageNumber === pageNumber
  );
  if (page) {
    const data = JSON.parse(page.pageData || "{\"photos\":[]}");
    const photo = db.photos.find((p) => p.id === photoId);
    if (photo) {
      data.photos = data.photos.filter((p: { id: number }) => p.id !== photoId);
      data.photos.push({ id: photo.id, url: photo.url, caption: photo.caption });
      page.pageData = JSON.stringify(data);
      persist();
      return true;
    }
  }
  return false;
}

export function removePhotoFromPage(albumId: number, pageNumber: number, photoId: number): boolean {
  const page = db.photoBookPages.find(
    (p) => p.albumId === albumId && p.pageNumber === pageNumber
  );
  if (page) {
    const data = JSON.parse(page.pageData || "{\"photos\":[]}");
    data.photos = data.photos.filter((p: { id: number }) => p.id !== photoId);
    page.pageData = JSON.stringify(data);
    persist();
    return true;
  }
  return false;
}

export function resetAssignments(albumId: number): boolean {
  db.photoBookPages = db.photoBookPages.filter((p) => p.albumId !== albumId);
  persist();
  return true;
}

export function generatePhotoBook(albumId: number): PhotoBookPage[] {
  const album = db.albums.find((a) => a.id === albumId);
  const photos = db.photos.filter((p) => p.albumId === albumId);
  if (!album) return [];

  // Clear existing pages
  db.photoBookPages = db.photoBookPages.filter((p) => p.albumId !== albumId);

  const pages: PhotoBookPage[] = [];
  const photosPerPage = album.photosPerPage || 2;

  // Cover page
  pages.push({
    id: generateId(),
    albumId,
    pageNumber: 1,
    layoutType: "cover",
    pageData: JSON.stringify({
      photos: photos.length > 0 ? [{ id: photos[0].id, url: photos[0].url }] : [],
    }),
    accentColor: album.accentColor || "#c9a87c",
    backgroundColor: album.backgroundColor || "#faf8f5",
    createdAt: new Date().toISOString(),
  });

  // Content pages
  const layouts = ["single", "double", "triple", "quad"];
  for (let i = 1; i < photos.length; i += photosPerPage) {
    const pagePhotos = photos.slice(i, i + photosPerPage).map((p) => ({
      id: p.id,
      url: p.url,
      caption: p.caption,
    }));
    pages.push({
      id: generateId(),
      albumId,
      pageNumber: pages.length + 1,
      layoutType: layouts[Math.min(pagePhotos.length - 1, layouts.length - 1)],
      pageData: JSON.stringify({ photos: pagePhotos }),
      accentColor: album.accentColor || "#c9a87c",
      backgroundColor: album.backgroundColor || "#faf8f5",
      createdAt: new Date().toISOString(),
    });
  }

  db.photoBookPages.push(...pages);
  persist();
  return pages;
}

// Invite operations
export function getInvitesByAlbum(albumId: number): Invite[] {
  return db.invites.filter((i) => i.type === "album" && i.albumId === albumId);
}

export function verifyInvite(token: string): { type: "system" | "album"; album?: Album; role: string } | null {
  const invite = db.invites.find((i) => i.token === token && !i.usedAt);
  if (!invite) return null;
  if (new Date(invite.expiresAt) < new Date()) return null;
  
  if (invite.type === "system") {
    return { type: "system", role: invite.role };
  }
  
  const album = db.albums.find((a) => a.id === invite.albumId);
  if (!album) return null;
  return { type: "album", album, role: invite.role };
}

export function createInvite(data: { type: "system" | "album"; albumId?: number; email?: string; role: string; createdBy: number }): Invite {
  const invite: Invite = {
    id: generateId(),
    type: data.type,
    albumId: data.type === "album" && data.albumId ? data.albumId : null,
    token: generateToken(),
    email: data.email || null,
    role: data.role,
    expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    usedAt: null,
    createdBy: data.createdBy,
    createdAt: new Date().toISOString(),
  };
  db.invites.push(invite);
  persist();
  return invite;
}

export function cancelInvite(id: number): boolean {
  const idx = db.invites.findIndex((i) => i.id === id);
  if (idx === -1) return false;
  db.invites.splice(idx, 1);
  persist();
  return true;
}

export function acceptInvite(token: string, _userId: number): { success: boolean; type?: "system" | "album"; albumId?: number } {
  const invite = db.invites.find((i) => i.token === token);
  if (!invite || invite.usedAt) return { success: false };
  invite.usedAt = new Date().toISOString();
  
  if (invite.type === "album" && invite.albumId) {
    persist();
    return { success: true, type: "album", albumId: invite.albumId };
  }
  
  persist();
  return { success: true, type: "system" };
}

// Support operations
export function getSupportStats(): { count: number; avgRating: number } {
  const reviews = db.supportReviews;
  if (reviews.length === 0) return { count: 0, avgRating: 0 };
  const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
  return { count: reviews.length, avgRating: sum / reviews.length };
}

export function createSupportReview(data: {
  rating: number;
  comment?: string;
  thanks?: string;
}): SupportReview {
  const review: SupportReview = {
    id: generateId(),
    rating: data.rating,
    comment: data.comment || null,
    thanks: data.thanks || null,
    createdAt: new Date().toISOString(),
  };
  db.supportReviews.push(review);
  persist();
  return review;
}

export function getSupportReviews(): SupportReview[] {
  return [...db.supportReviews];
}

export function getInvites(): Invite[] {
  return [...db.invites];
}

export function getUsers(): StoredUser[] {
  const stored = localStorage.getItem("auth_user");
  if (!stored) return [];
  try {
    const user = JSON.parse(stored);
    return [user];
  } catch {
    return [];
  }
}
interface StoredUser {
  id: number;
  name: string;
  email: string;
  role: string;
}

export function getCurrentUser(): StoredUser | null {
  const stored = localStorage.getItem("auth_user");
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch {
    return null;
  }
}
