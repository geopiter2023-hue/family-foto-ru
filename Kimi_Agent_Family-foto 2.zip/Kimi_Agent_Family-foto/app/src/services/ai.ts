// AI Service — Hugging Face Inference API for photo processing

const HF_API_URL = "https://api-inference.huggingface.co/models";

// Default models
const CAPTION_MODEL = "Salesforce/blip-image-captioning-base";
const CLASSIFICATION_MODEL = "microsoft/resnet-50";

interface AICaptionResult {
  generated_text: string;
}

interface AIClassificationResult {
  label: string;
  score: number;
}

// Get token from localStorage or use empty (free tier)
function getToken(): string | null {
  return localStorage.getItem("ai_hf_token");
}

function getHeaders(): Record<string, string> {
  const token = getToken();
  const headers: Record<string, string> = {};
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
}

// Convert base64 to Blob
function base64ToBlob(base64: string): Blob {
  const byteString = atob(base64.split(",")[1] || base64);
  const mimeString = base64.split(",")[0]?.match(/:(.*?);/)?.[1] || "image/jpeg";
  const ab = new ArrayBuffer(byteString.length);
  const ia = new Uint8Array(ab);
  for (let i = 0; i < byteString.length; i++) {
    ia[i] = byteString.charCodeAt(i);
  }
  return new Blob([ab], { type: mimeString });
}

// Generate AI caption for a photo
export async function generateCaption(imageUrl: string): Promise<string | null> {
  try {
    let blob: Blob;
    if (imageUrl.startsWith("data:")) {
      blob = base64ToBlob(imageUrl);
    } else {
      // Fetch external URL
      const response = await fetch(imageUrl, { mode: "cors" });
      blob = await response.blob();
    }

    const response = await fetch(`${HF_API_URL}/${CAPTION_MODEL}`, {
      method: "POST",
      headers: getHeaders(),
      body: blob,
    });

    if (!response.ok) {
      if (response.status === 403 || response.status === 401) {
        throw new Error("API_TOKEN_REQUIRED");
      }
      throw new Error(`HTTP ${response.status}`);
    }

    const result: AICaptionResult[] = await response.json();
    if (Array.isArray(result) && result[0]?.generated_text) {
      return result[0].generated_text;
    }
    return null;
  } catch (error: any) {
    console.error("AI caption error:", error);
    if (error.message === "API_TOKEN_REQUIRED") {
      return "__TOKEN_REQUIRED__";
    }
    return null;
  }
}

// Classify image content (for smart search)
export async function classifyImage(imageUrl: string): Promise<string[]> {
  try {
    let blob: Blob;
    if (imageUrl.startsWith("data:")) {
      blob = base64ToBlob(imageUrl);
    } else {
      const response = await fetch(imageUrl, { mode: "cors" });
      blob = await response.blob();
    }

    const response = await fetch(`${HF_API_URL}/${CLASSIFICATION_MODEL}`, {
      method: "POST",
      headers: getHeaders(),
      body: blob,
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const result: AIClassificationResult[] = await response.json();
    if (Array.isArray(result)) {
      return result
        .filter((r) => r.score > 0.3)
        .map((r) => r.label.toLowerCase());
    }
    return [];
  } catch (error) {
    console.error("AI classify error:", error);
    return [];
  }
}

// Save AI token
export function saveAIToken(token: string) {
  localStorage.setItem("ai_hf_token", token);
}

// Get AI token
export function getAIToken(): string | null {
  return localStorage.getItem("ai_hf_token");
}

// Remove AI token
export function removeAIToken() {
  localStorage.removeItem("ai_hf_token");
}
