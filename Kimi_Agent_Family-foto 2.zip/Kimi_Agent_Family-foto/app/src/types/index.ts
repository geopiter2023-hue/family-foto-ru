export interface Album {
  id: number;
  title: string;
  description: string | null;
  coverPhoto: string | null;
  year: number | null;
  month: number | null;
  albumType: "photo" | "family_tree"; // photo = regular album, family_tree = genealogy
  accentColor: string;
  backgroundColor: string;
  fontFamily: string;
  photosPerPage: number;
  isPublic: boolean;
  createdBy: number;
  createdAt: string;
  updatedAt: string;
  role?: string;
  photos?: Photo[];
  members?: FamilyMember[];
}

export interface Photo {
  id: number;
  albumId: number;
  url: string;
  thumbnail: string | null;
  caption: string | null;
  location: string | null;
  takenAt: string | null;
  isCover: boolean;
  uploadedBy: number;
  createdAt: string;
  order?: number;
  emotion?: string | null; // "Счастье", "Ностальгия", "Уют", "Любовь" и т.д.
  emotionNote?: string | null;
}

export interface FamilyMember {
  id: number;
  albumId: number;
  role: string;
  name: string;
  email: string | null;
  phone: string | null;
  birthDate: string | null;
  deathDate: string | null;
  bio: string | null;
  photoUrl: string | null;
  parent1Id: number | null;
  parent2Id: number | null;
  spouseId: number | null;
  order: number;
  createdAt: string;
}

export interface PhotoBookPage {
  id: number;
  albumId: number;
  pageNumber: number;
  layoutType: string;
  pageData: string | null;
  accentColor: string;
  backgroundColor: string;
  createdAt: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  createdAt: string;
}

export interface Invite {
  id: number;
  type: "system" | "album";
  albumId: number | null;
  token: string;
  email: string | null;
  role: string;
  expiresAt: string;
  usedAt: string | null;
  createdBy: number;
  createdAt: string;
}

export interface SupportReview {
  id: number;
  rating: number;
  comment: string | null;
  thanks: string | null;
  createdAt: string;
}
