// IndexedDB storage for photos — avoids localStorage 5MB limit
const DB_NAME = "family_foto_photos";
const DB_VERSION = 1;
const STORE_PHOTOS = "photos";
const STORE_ALBUMS = "albums";
const STORE_MEMBERS = "members";

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = (e) => {
      const db = (e.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_PHOTOS)) {
        db.createObjectStore(STORE_PHOTOS, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(STORE_ALBUMS)) {
        db.createObjectStore(STORE_ALBUMS, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(STORE_MEMBERS)) {
        db.createObjectStore(STORE_MEMBERS, { keyPath: "id" });
      }
    };
  });
}

async function withStore<T>(storeName: string, mode: IDBTransactionMode, fn: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDB();
  const tx = db.transaction(storeName, mode);
  const store = tx.objectStore(storeName);
  const req = fn(store);
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    tx.oncomplete = () => db.close();
    tx.onerror = () => reject(tx.error);
  });
}

// ===== PHOTOS =====
export async function dbPhotoList(albumId?: string | number): Promise<any[]> {
  try {
    const all = await withStore<any[]>(STORE_PHOTOS, "readonly", (s) => s.getAll());
    if (albumId !== undefined) {
      const albumIdStr = String(albumId);
      return all.filter((p) => String(p.albumId) === albumIdStr && !p.deletedAt);
    }
    return all.filter((p) => !p.deletedAt);
  } catch (e) {
    console.warn("[dbPhotoList] error:", e);
    return [];
  }
}

export async function dbPhotoGet(id: string | number): Promise<any | null> {
  try {
    return await withStore(STORE_PHOTOS, "readonly", (s) => s.get(id));
  } catch (e) {
    console.warn("[dbPhotoGet] error:", e);
    return null;
  }
}

export async function dbPhotoPut(photo: any): Promise<void> {
  try {
    await withStore(STORE_PHOTOS, "readwrite", (s) => s.put(photo));
  } catch (e) {
    console.warn("[dbPhotoPut] error:", e);
    throw e;
  }
}

export async function dbPhotoPutBatch(photos: any[]): Promise<void> {
  const db = await openDB();
  const tx = db.transaction(STORE_PHOTOS, "readwrite");
  const store = tx.objectStore(STORE_PHOTOS);
  for (const p of photos) {
    store.put(p);
  }
  return new Promise((resolve, reject) => {
    tx.onsuccess = () => { db.close(); resolve(); };
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error); };
  });
}

export async function dbPhotoSoftDelete(id: string | number): Promise<void> {
  try {
    const p = await dbPhotoGet(id);
    if (p) {
      p.deletedAt = new Date().toISOString();
      await dbPhotoPut(p);
    }
  } catch (e) {
    console.warn("[dbPhotoSoftDelete] error:", e);
  }
}

export async function dbPhotoRestore(id: string | number): Promise<void> {
  try {
    const p = await dbPhotoGet(id);
    if (p) {
      p.deletedAt = undefined;
      await dbPhotoPut(p);
    }
  } catch (e) {
    console.warn("[dbPhotoRestore] error:", e);
  }
}

export async function dbPhotoListDeleted(): Promise<any[]> {
  try {
    const all = await withStore<any[]>(STORE_PHOTOS, "readonly", (s) => s.getAll());
    return all.filter((p) => p.deletedAt);
  } catch (e) {
    console.warn("[dbPhotoListDeleted] error:", e);
    return [];
  }
}

// ===== ALBUMS =====
export async function dbAlbumList(): Promise<any[]> {
  try {
    const all = await withStore<any[]>(STORE_ALBUMS, "readonly", (s) => s.getAll());
    return all.filter((a) => !a.deletedAt);
  } catch (e) {
    console.warn("[dbAlbumList] error:", e);
    return [];
  }
}

export async function dbAlbumGet(id: string | number): Promise<any | null> {
  try {
    return await withStore(STORE_ALBUMS, "readonly", (s) => s.get(id));
  } catch (e) {
    console.warn("[dbAlbumGet] error:", e);
    return null;
  }
}

export async function dbAlbumPut(album: any): Promise<void> {
  try {
    await withStore(STORE_ALBUMS, "readwrite", (s) => s.put(album));
  } catch (e) {
    console.warn("[dbAlbumPut] error:", e);
    throw e;
  }
}

export async function dbAlbumSoftDelete(id: string | number): Promise<void> {
  try {
    const a = await dbAlbumGet(id);
    if (a) {
      a.deletedAt = new Date().toISOString();
      await dbAlbumPut(a);
    }
  } catch (e) {
    console.warn("[dbAlbumSoftDelete] error:", e);
  }
}

export async function dbAlbumRestore(id: string | number): Promise<void> {
  try {
    const a = await dbAlbumGet(id);
    if (a) {
      a.deletedAt = undefined;
      await dbAlbumPut(a);
    }
  } catch (e) {
    console.warn("[dbAlbumRestore] error:", e);
  }
}

export async function dbAlbumListDeleted(): Promise<any[]> {
  try {
    const all = await withStore<any[]>(STORE_ALBUMS, "readonly", (s) => s.getAll());
    return all.filter((a) => a.deletedAt);
  } catch (e) {
    console.warn("[dbAlbumListDeleted] error:", e);
    return [];
  }
}

// ===== MEMBERS =====
export async function dbMemberList(albumId?: string | number): Promise<any[]> {
  try {
    const all = await withStore<any[]>(STORE_MEMBERS, "readonly", (s) => s.getAll());
    if (albumId !== undefined) {
      const albumIdStr = String(albumId);
      return all.filter((m) => String(m.albumId) === albumIdStr && !m.deletedAt);
    }
    return all.filter((m) => !m.deletedAt);
  } catch (e) {
    console.warn("[dbMemberList] error:", e);
    return [];
  }
}

export async function dbMemberPut(member: any): Promise<void> {
  try {
    await withStore(STORE_MEMBERS, "readwrite", (s) => s.put(member));
  } catch (e) {
    console.warn("[dbMemberPut] error:", e);
    throw e;
  }
}

export async function dbMemberSoftDelete(id: string | number): Promise<void> {
  try {
    const m = await withStore(STORE_MEMBERS, "readonly", (s) => s.get(id));
    if (m) {
      m.deletedAt = new Date().toISOString();
      await dbMemberPut(m);
    }
  } catch (e) {
    console.warn("[dbMemberSoftDelete] error:", e);
  }
}

export async function dbMemberRestore(id: string | number): Promise<void> {
  try {
    const m = await withStore(STORE_MEMBERS, "readonly", (s) => s.get(id));
    if (m) {
      m.deletedAt = undefined;
      await dbMemberPut(m);
    }
  } catch (e) {
    console.warn("[dbMemberRestore] error:", e);
  }
}

// ===== MIGRATION: localStorage → IndexedDB =====
export async function migrateLocalStorageToIndexedDB(): Promise<void> {
  try {
    // Migrate photos
    const photosStr = localStorage.getItem("ff_photos");
    if (photosStr) {
      const photos = JSON.parse(photosStr);
      if (Array.isArray(photos) && photos.length > 0) {
        const db = await openDB();
        const tx = db.transaction(STORE_PHOTOS, "readwrite");
        const store = tx.objectStore(STORE_PHOTOS);
        for (const p of photos) {
          store.put(p);
        }
        await new Promise<void>((resolve, reject) => {
          tx.oncomplete = () => { db.close(); resolve(); };
          tx.onerror = () => { db.close(); reject(tx.error); };
        });
        console.log("[migrate] Migrated", photos.length, "photos to IndexedDB");
      }
    }
    // Migrate albums
    const albumsStr = localStorage.getItem("ff_albums");
    if (albumsStr) {
      const albums = JSON.parse(albumsStr);
      if (Array.isArray(albums) && albums.length > 0) {
        const db = await openDB();
        const tx = db.transaction(STORE_ALBUMS, "readwrite");
        const store = tx.objectStore(STORE_ALBUMS);
        for (const a of albums) {
          store.put(a);
        }
        await new Promise<void>((resolve, reject) => {
          tx.oncomplete = () => { db.close(); resolve(); };
          tx.onerror = () => { db.close(); reject(tx.error); };
        });
        console.log("[migrate] Migrated", albums.length, "albums to IndexedDB");
      }
    }
    // Migrate members
    const membersStr = localStorage.getItem("ff_familyMembers");
    if (membersStr) {
      const members = JSON.parse(membersStr);
      if (Array.isArray(members) && members.length > 0) {
        const db = await openDB();
        const tx = db.transaction(STORE_MEMBERS, "readwrite");
        const store = tx.objectStore(STORE_MEMBERS);
        for (const m of members) {
          store.put(m);
        }
        await new Promise<void>((resolve, reject) => {
          tx.oncomplete = () => { db.close(); resolve(); };
          tx.onerror = () => { db.close(); reject(tx.error); };
        });
        console.log("[migrate] Migrated", members.length, "members to IndexedDB");
      }
    }
  } catch (e) {
    console.warn("[migrate] error:", e);
  }
}
