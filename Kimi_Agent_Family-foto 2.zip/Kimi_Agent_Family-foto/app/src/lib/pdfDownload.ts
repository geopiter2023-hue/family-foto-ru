// PDF download helper — works on all platforms including iOS Safari

export function isIOS(): boolean {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
}

/**
 * Download or open PDF.
 * - Desktop/Android: native file download via <a download>
 * - iOS Safari: window.open() in new tab for Share ↗️ button
 */
export function downloadPDF(pdfBlob: Blob, filename: string): void {
  const url = URL.createObjectURL(pdfBlob);
  const safeName = filename.replace(/[^a-zA-Z0-9\u0400-\u04FF_.-]/g, "_");

  if (isIOS()) {
    // iOS Safari: window.open creates a new tab with PDF viewer + Share button
    const newWindow = window.open(url, "_blank");
    if (!newWindow) {
      // Fallback if popup blocked
      window.location.href = url;
    }
    // Revoke after 30s to allow sharing
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    return;
  }

  // Desktop / Android: native download
  const a = document.createElement("a");
  a.href = url;
  a.download = safeName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/** Hint shown after PDF opens */
export function getMobilePDFHint(): string | null {
  if (isIOS()) {
    return "PDF открылся в новой вкладке Safari. Нажмите \"Поделиться\" ↗️ внизу экрана и выберите мессенджер";
  }
  return null;
}
