// Database migration system for localStorage
// Ensures user data survives app updates

const DB_VERSION_KEY = "ff_db_version";
const CURRENT_DB_VERSION = 2;

// Migration steps: v1 → v2 → v3 etc.
const migrations: Record<number, () => void> = {
  1: () => {
    // v1: Initial setup — ensure all tables exist
    const keys = ["ff_albums", "ff_photos", "ff_familyMembers", "ff_reviews", "ff_users"];
    keys.forEach((k) => {
      if (!localStorage.getItem(k)) localStorage.setItem(k, "[]");
    });
    console.log("[DB] Migration v1: initialized empty tables");
  },
  2: () => {
    // v2: Fix snake_case fields → camelCase for consistency
    try {
      const albums = JSON.parse(localStorage.getItem("ff_albums") || "[]");
      albums.forEach((a: any) => {
        if (a.album_type && !a.albumType) a.albumType = a.album_type;
        if (a.cover_photo && !a.coverPhoto) a.coverPhoto = a.cover_photo;
        if (a.accent_color && !a.accentColor) a.accentColor = a.accent_color;
        if (a.background_color && !a.backgroundColor) a.backgroundColor = a.background_color;
        if (a.font_family && !a.fontFamily) a.fontFamily = a.font_family;
        if (a.photos_per_page && !a.photosPerPage) a.photosPerPage = a.photos_per_page;
        if (a.is_public !== undefined && a.isPublic === undefined) a.isPublic = !!a.is_public;
        if (a.created_by && !a.createdBy) a.createdBy = a.created_by;
        if (a.created_at && !a.createdAt) a.createdAt = a.created_at;
      });
      localStorage.setItem("ff_albums", JSON.stringify(albums));

      const photos = JSON.parse(localStorage.getItem("ff_photos") || "[]");
      photos.forEach((p: any) => {
        if (p.album_id && !p.albumId) p.albumId = p.album_id;
        if (p.is_cover !== undefined && p.isCover === undefined) p.isCover = !!p.is_cover;
        if (p.uploaded_by && !p.uploadedBy) p.uploadedBy = p.uploaded_by;
        if (p.taken_at && !p.takenAt) p.takenAt = p.taken_at;
        if (p.created_at && !p.createdAt) p.createdAt = p.created_at;
      });
      localStorage.setItem("ff_photos", JSON.stringify(photos));

      const members = JSON.parse(localStorage.getItem("ff_familyMembers") || "[]");
      members.forEach((m: any) => {
        if (m.album_id && !m.albumId) m.albumId = m.album_id;
        if (m.photo_url && !m.photoUrl) m.photoUrl = m.photo_url;
        if (m.birth_date && !m.birthDate) m.birthDate = m.birth_date;
        if (m.death_date && !m.deathDate) m.deathDate = m.death_date;
        if (m.parent1_id && !m.parent1Id) m.parent1Id = m.parent1_id;
        if (m.parent2_id && !m.parent2Id) m.parent2Id = m.parent2_id;
        if (m.spouse_id && !m.spouseId) m.spouseId = m.spouse_id;
        if (m.order_num !== undefined && m.order === undefined) m.order = m.order_num;
        if (m.created_at && !m.createdAt) m.createdAt = m.created_at;
      });
      localStorage.setItem("ff_familyMembers", JSON.stringify(members));

      console.log("[DB] Migration v2: normalized snake_case → camelCase");
    } catch (e) {
      console.error("[DB] Migration v2 failed:", e);
    }
  },
};

export function runMigrations() {
  const storedVersion = parseInt(localStorage.getItem(DB_VERSION_KEY) || "0");

  if (storedVersion >= CURRENT_DB_VERSION) {
    console.log(`[DB] Up to date (v${storedVersion})`);
    return;
  }

  console.log(`[DB] Migrating: v${storedVersion} → v${CURRENT_DB_VERSION}`);

  for (let v = storedVersion + 1; v <= CURRENT_DB_VERSION; v++) {
    if (migrations[v]) {
      try {
        migrations[v]();
        localStorage.setItem(DB_VERSION_KEY, String(v));
        console.log(`[DB] Applied migration v${v}`);
      } catch (e) {
        console.error(`[DB] Migration v${v} failed:`, e);
        break;
      }
    }
  }
}

// Seed demo data only on first install (no existing albums)
export function seedDemoDataIfEmpty() {
  const albums = JSON.parse(localStorage.getItem("ff_albums") || "[]");
  if (albums.length > 0) return; // User has albums — don't overwrite

  // ... existing seedDemoData logic ...
  // But don't touch if albums exist!
}
