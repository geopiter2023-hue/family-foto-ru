import { createClient } from "@supabase/supabase-js";
import {
  dbPhotoList, dbPhotoPut, dbPhotoPutBatch, dbPhotoSoftDelete, dbPhotoRestore, dbPhotoListDeleted,
  dbAlbumList, dbAlbumGet, dbAlbumPut, dbAlbumSoftDelete, dbAlbumRestore, dbAlbumListDeleted,
  dbMemberList, dbMemberPut, dbMemberSoftDelete, dbMemberRestore,
  migrateLocalStorageToIndexedDB,
} from "./photoDb";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://hmxwvuojbgmijhqgnpep.supabase.co";
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhteHd2dW9qYmdtaWpocWducGVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzc3NzY2ODcsImV4cCI6MjA5MzM1MjY4N30.SicbeQRPAP9BpdTD9F9uyFQFjj4TFKdFCQr7xPSOW_U";

export const supabase =
  supabaseUrl && supabaseKey
    ? createClient(supabaseUrl, supabaseKey, {
        auth: { autoRefreshToken: true, persistSession: true },
      })
    : null;

// Helper: track invited users
function trackInvitedUser(email: string) {
  try {
    const invited = JSON.parse(localStorage.getItem("ff_invited_users") || "[]");
    if (Array.isArray(invited) && !invited.includes(email)) {
      invited.push(email);
      localStorage.setItem("ff_invited_users", JSON.stringify(invited));
    }
  } catch { /* ignore */ }
}

export function getInvitedUsers(): string[] {
  try {
    return JSON.parse(localStorage.getItem("ff_invited_users") || "[]");
  } catch { return []; }
}

// Check if Supabase is configured
const hasSupabase = !!supabase;

function getSb() {
  if (!supabase) throw new Error("Supabase not configured");
  return supabase;
}

// ==========================================
// LOCAL STORAGE FALLBACK (when Supabase not configured)
// ==========================================

function lsGet<T>(key: string, fallback: T): T {
  try { return JSON.parse(localStorage.getItem(key) || "null") ?? fallback; } catch { return fallback; }
}
function lsSet(key: string, val: any) {
  localStorage.setItem(key, JSON.stringify(val));
}
function generateId(): string {
  return (Date.now() + Math.floor(Math.random() * 1000)).toString(36) + Math.random().toString(36).slice(2, 6);
}

// Upload file — with fallback
// Resize image to avoid quota issues (max 800px, 75% JPEG quality)
function resizeImage(file: File, maxWidth = 800, maxHeight = 800, quality = 0.75): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      let { width, height } = img;
      if (width > maxWidth) { height = Math.round(height * maxWidth / width); width = maxWidth; }
      if (height > maxHeight) { width = Math.round(width * maxHeight / height); height = maxHeight; }
      const canvas = document.createElement("canvas");
      canvas.width = width; canvas.height = height;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL("image/jpeg", quality));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Failed to load image")); };
    img.src = url;
  });
}

export async function uploadFile(file: File): Promise<string> {
  console.log("[uploadFile] start, type:", file.type, "size:", file.size, "hasSupabase:", hasSupabase);
  const isImage = file.type.startsWith("image/");

  // Always resize images first
  if (isImage) {
    try {
      const resized = await resizeImage(file, 800, 800, 0.75);
      console.log("[uploadFile] resized to ~", Math.round(resized.length / 1024), "KB");

      if (hasSupabase) {
        try {
          const res = await fetch(resized);
          const blob = await res.blob();
          const sb = getSb();
          const fileName = `${Date.now()}_${Math.random().toString(36).slice(2)}.jpg`;
          const filePath = `photos/${fileName}`;
          console.log("[uploadFile] uploading to Supabase:", filePath);

          const { error } = await sb.storage.from("family-foto").upload(filePath, blob, {
            cacheControl: "3600",
            upsert: false,
            contentType: "image/jpeg",
          });

          if (error) {
            console.error("[uploadFile] Supabase upload ERROR:", error.message, error);
          } else {
            const { data } = sb.storage.from("family-foto").getPublicUrl(filePath);
            console.log("[uploadFile] SUCCESS, URL:", data.publicUrl);
            return data.publicUrl;
          }
        } catch (e: any) {
          console.error("[uploadFile] Supabase exception:", e?.message || e);
        }
      }

      // Fallback: return resized base64
      console.log("[uploadFile] returning base64 fallback");
      return resized;
    } catch (e) {
      console.error("[uploadFile] resize failed:", e);
    }
  }

  // Non-image or fallback
  if (hasSupabase) {
    try {
      const sb = getSb();
      const fileExt = file.name.split(".").pop() || "jpg";
      const fileName = `${Date.now()}_${Math.random().toString(36).slice(2)}.${fileExt}`;
      const filePath = `photos/${fileName}`;
      const { error } = await sb.storage.from("family-foto").upload(filePath, file, { cacheControl: "3600", upsert: false });
      if (error) {
        console.error("[uploadFile] non-image upload error:", error.message);
        throw new Error(`Upload failed: ${error.message}`);
      }
      const { data } = sb.storage.from("family-foto").getPublicUrl(filePath);
      return data.publicUrl;
    } catch (e: any) {
      console.error("[uploadFile] non-image exception:", e?.message || e);
    }
  }

  // Final fallback: base64
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (ev) => resolve(ev.target?.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Album API — with localStorage fallback
export const albumApi = {
  list: async () => {
    let result: Album[] = [];
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data, error } = await sb.from("albums").select("*").is("deleted_at", null).order("created_at", { ascending: false });
        if (!error && data) {
          result = data.map((a: any) => ({
            ...a,
            deletedAt: a.deleted_at,
            albumType: a.album_type,
            coverPhoto: a.cover_photo,
            accentColor: a.accent_color,
            backgroundColor: a.background_color,
            fontFamily: a.font_family,
            photosPerPage: a.photos_per_page,
            isPublic: a.is_public,
            createdBy: a.created_by,
            createdAt: a.created_at,
          })).filter((a: any) => !a.deletedAt);
        }
      } catch (e: any) {
        console.warn("[albumApi.list] Supabase failed:", e?.message || e);
      }
    }
    // Merge with IndexedDB albums (deduplicate)
    if (result.length === 0) {
      const dbAlbums = await dbAlbumList();
      const existingIds = new Set(result.map((a) => String(a.id)));
      for (const a of dbAlbums) {
        if (!existingIds.has(String(a.id))) result.push(a);
      }
    }
    // Legacy fallback: localStorage
    if (result.length === 0) {
      const localAlbums = lsGet<Album[]>("ff_albums", []).filter((a) => !a.deletedAt);
      result = localAlbums;
    }
    return result.filter((a) => !a.deletedAt);
  },

  getById: async (id: string | number) => {
    const idStr = String(id);
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data: album, error } = await sb.from("albums").select("*").eq("id", id).is("deleted_at", null).single();
        if (!error && album) {
          const { data: photos } = await sb.from("photos").select("*").eq("album_id", id).is("deleted_at", null).order("created_at", { ascending: true });
          const { data: members } = await sb.from("family_members").select("*").eq("album_id", id).is("deleted_at", null).order("order_num", { ascending: true });
          return {
            ...album,
            deletedAt: album.deleted_at,
            albumType: album.album_type,
            coverPhoto: album.cover_photo,
            accentColor: album.accent_color,
            backgroundColor: album.background_color,
            fontFamily: album.font_family,
            photosPerPage: album.photos_per_page,
            isPublic: album.is_public,
            createdBy: album.created_by,
            createdAt: album.created_at,
            photos: (photos || []).map((p: any) => ({ ...p, deletedAt: p.deleted_at, albumId: p.album_id, isCover: p.is_cover, uploadedBy: p.uploaded_by, createdAt: p.created_at })),
            members: (members || []).map((m: any) => ({ ...m, deletedAt: m.deleted_at, albumId: m.album_id, photoUrl: m.photo_url, birthDate: m.birth_date, deathDate: m.death_date, parent1Id: m.parent1_id, parent2Id: m.parent2_id, spouseId: m.spouse_id, createdAt: m.created_at })),
          };
        }
      } catch (e: any) {
        console.warn("[albumApi.getById] Supabase failed:", e?.message || e);
      }
    }
    // IndexedDB fallback
    const dbAlbum = await dbAlbumGet(id);
    if (dbAlbum && !dbAlbum.deletedAt) {
      const photos = await dbPhotoList(id);
      const members = await dbMemberList(id);
      return { ...dbAlbum, photos, members };
    }
    // Legacy localStorage
    const albums = lsGet<Album[]>("ff_albums", []);
    const a = albums.find((a) => String(a.id) === idStr && !a.deletedAt);
    if (!a) return null;
    const lsPhotos = lsGet<any[]>("ff_photos", []).filter((p) => String(p.albumId) === idStr && !p.deletedAt);
    const lsMembers = lsGet<any[]>("ff_familyMembers", []).filter((m) => String(m.albumId) === idStr && !m.deletedAt);
    return { ...a, photos: lsPhotos, members: lsMembers };
  },

  create: async (data: any) => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        const insertData: any = {
          title: data.title,
          description: data.description || null,
          year: data.year || null,
          month: data.month || null,
          album_type: data.albumType || "photo",
          cover_photo: data.coverPhoto || null,
          accent_color: data.accentColor || "#c9a87c",
          background_color: data.backgroundColor || "#faf8f5",
          font_family: data.fontFamily || "serif",
          photos_per_page: data.photosPerPage || 2,
          is_public: data.isPublic ? 1 : 0,
        };
        if (data.createdBy) insertData.created_by = data.createdBy;
        const { data: result, error } = await sb.from("albums").insert(insertData).select().single();
        if (error) throw error;
        return result;
      } catch (e: any) {
        console.warn("[albumApi.create] Supabase failed, using localStorage fallback:", e?.message || e);
      }
    }
    // LocalStorage fallback
    const albums = lsGet<Album[]>("ff_albums", []);
    const newAlbum = { ...data, id: generateId(), createdAt: new Date().toISOString() };
    albums.push(newAlbum);
    lsSet("ff_albums", albums);
    return newAlbum;
  },

  update: async (id: number | string, data: any) => {
    const idStr = String(id);
    if (hasSupabase) {
      try {
        const sb = getSb();
        const update: any = {};
        if (data.title !== undefined) update.title = data.title;
        if (data.description !== undefined) update.description = data.description;
        if (data.year !== undefined) update.year = data.year;
        if (data.month !== undefined) update.month = data.month;
        if (data.coverPhoto !== undefined) update.cover_photo = data.coverPhoto;
        if (data.accentColor !== undefined) update.accent_color = data.accentColor;
        if (data.backgroundColor !== undefined) update.background_color = data.backgroundColor;
        if (data.fontFamily !== undefined) update.font_family = data.fontFamily;
        if (data.photosPerPage !== undefined) update.photos_per_page = data.photosPerPage;
        if (data.isPublic !== undefined) update.is_public = data.isPublic ? 1 : 0;
        await sb.from("albums").update(update).eq("id", id);
      } catch (e: any) {
        console.warn("[albumApi.update] Supabase failed, using localStorage:", e?.message || e);
      }
    }
    const albums = lsGet<Album[]>("ff_albums", []);
    const idx = albums.findIndex((a) => String(a.id) === idStr);
    if (idx !== -1) {
      albums[idx] = { ...albums[idx], ...data };
      try {
        lsSet("ff_albums", albums);
      } catch (e) {
        console.error("[albumApi.update] localStorage quota exceeded:", e);
        throw new Error("Не удалось сохранить — хранилище переполнено. Попробуйте удалить старые фото.");
      }
    }
    return { success: true };
  },

  delete: async (id: number | string) => {
    const deletedAt = new Date().toISOString();
    const idStr = String(id);
    let supabaseOk = false;
    if (hasSupabase) {
      try {
        const sb = getSb();
        await sb.from("albums").update({ deleted_at: deletedAt }).eq("id", id);
        await sb.from("photos").update({ deleted_at: deletedAt }).eq("album_id", id);
        await sb.from("family_members").update({ deleted_at: deletedAt }).eq("album_id", id);
        supabaseOk = true;
      } catch (e: any) {
        console.warn("[albumApi.delete] Supabase failed:", e?.message || e);
      }
    }
    // IndexedDB
    await dbAlbumSoftDelete(id);
    const dbPhotos = await dbPhotoList(id);
    for (const p of dbPhotos) await dbPhotoSoftDelete(p.id);
    const dbMembers = await dbMemberList(id);
    for (const m of dbMembers) await dbMemberSoftDelete(m.id);
    // Legacy localStorage
    let albums = lsGet<Album[]>("ff_albums", []);
    albums = albums.map((a) => String(a.id) === idStr ? { ...a, deletedAt } : a);
    lsSet("ff_albums", albums);
    let photos = lsGet<any[]>("ff_photos", []);
    photos = photos.map((p) => String(p.albumId) === idStr ? { ...p, deletedAt } : p);
    lsSet("ff_photos", photos);
    let members = lsGet<any[]>("ff_familyMembers", []);
    members = members.map((m) => String(m.albumId) === idStr ? { ...m, deletedAt } : m);
    lsSet("ff_familyMembers", members);
    return { success: true };
  },

  restore: async (id: number | string) => {
    const idStr = String(id);
    if (hasSupabase) {
      try {
        const sb = getSb();
        await sb.from("albums").update({ deleted_at: null }).eq("id", id);
        await sb.from("photos").update({ deleted_at: null }).eq("album_id", id);
        await sb.from("family_members").update({ deleted_at: null }).eq("album_id", id);
      } catch (e: any) {
        console.warn("[albumApi.restore] Supabase failed:", e?.message || e);
      }
    }
    await dbAlbumRestore(id);
    const dbPhotos = await dbPhotoList(id);
    for (const p of dbPhotos) await dbPhotoRestore(p.id);
    const dbMembers = await dbMemberList(id);
    for (const m of dbMembers) await dbMemberRestore(m.id);
    // Legacy localStorage
    let albums = lsGet<Album[]>("ff_albums", []);
    albums = albums.map((a) => String(a.id) === idStr ? { ...a, deletedAt: undefined } : a);
    lsSet("ff_albums", albums);
    let photos = lsGet<any[]>("ff_photos", []);
    photos = photos.map((p) => String(p.albumId) === idStr ? { ...p, deletedAt: undefined } : p);
    lsSet("ff_photos", photos);
    let members = lsGet<any[]>("ff_familyMembers", []);
    members = members.map((m) => String(m.albumId) === idStr ? { ...m, deletedAt: undefined } : m);
    lsSet("ff_familyMembers", members);
    return { success: true };
  },

  listDeleted: async () => {
    let result: Album[] = [];
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data, error } = await sb.from("albums").select("*").not("deleted_at", "is", null);
        if (!error && data) {
          result = data.map((a: any) => ({
            ...a,
            deletedAt: a.deleted_at,
            albumType: a.album_type,
            coverPhoto: a.cover_photo,
            accentColor: a.accent_color,
            backgroundColor: a.background_color,
            fontFamily: a.font_family,
            photosPerPage: a.photos_per_page,
            isPublic: a.is_public,
            createdBy: a.created_by,
            createdAt: a.created_at,
          }));
        }
      } catch (e: any) {
        console.warn("[albumApi.listDeleted] Supabase failed:", e?.message || e);
      }
    }
    const dbDeleted = await dbAlbumListDeleted();
    const existingIds = new Set(result.map((a) => String(a.id)));
    for (const a of dbDeleted) {
      if (!existingIds.has(String(a.id))) result.push(a);
    }
    if (result.length === 0) {
      result = lsGet<Album[]>("ff_albums", []).filter((a) => a.deletedAt);
    }
    return result;
  },
};

// Photo API
export const photoApi = {
  list: async (albumId: number | string) => {
    const albumIdStr = String(albumId);
    let result: any[] = [];
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data, error } = await sb.from("photos").select("*").eq("album_id", albumId).is("deleted_at", null).order("created_at", { ascending: true });
        if (!error) {
          result = (data || []).map((p: any) => ({
            ...p,
            deletedAt: p.deleted_at,
            albumId: p.album_id,
            isCover: p.is_cover,
            uploadedBy: p.uploaded_by,
            createdAt: p.created_at,
          })).filter((p: any) => !p.deletedAt);
        }
      } catch (e: any) {
        console.warn("[photoApi.list] Supabase failed:", e?.message || e);
      }
    }
    // Merge with IndexedDB (deduplicate, prefer Supabase data)
    if (result.length === 0) {
      const dbPhotos = await dbPhotoList(albumId);
      const existingIds = new Set(result.map((p) => String(p.id)));
      for (const p of dbPhotos) {
        if (!existingIds.has(String(p.id))) result.push(p);
      }
    }
    // Legacy fallback: localStorage
    if (result.length === 0) {
      const lsPhotos = lsGet<any[]>("ff_photos", []).filter((p) => String(p.albumId) === albumIdStr && !p.deletedAt);
      result = lsPhotos;
    }
    return result;
  },

  create: async (data: any) => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { error } = await sb.from("photos").insert({
          album_id: data.albumId,
          url: data.url,
          thumbnail: data.thumbnail || null,
          caption: data.caption || null,
          location: data.location || null,
          taken_at: data.takenAt || null,
          is_cover: data.isCover ? 1 : 0,
          uploaded_by: data.uploadedBy,
        });
        if (!error) return { success: true };
        console.error("[photoApi.create] Supabase error:", error.message);
      } catch (e: any) {
        console.warn("[photoApi.create] Supabase failed, using IndexedDB:", e?.message || e);
      }
    }
    // IndexedDB — no 5MB limit
    const newPhoto = { ...data, id: generateId(), createdAt: new Date().toISOString() };
    try {
      await dbPhotoPut(newPhoto);
    } catch (e) {
      console.error("[photoApi.create] IndexedDB failed:", e);
      // Last resort: localStorage
      const photos = lsGet<any[]>("ff_photos", []);
      photos.push(newPhoto);
      try {
        lsSet("ff_photos", photos);
      } catch (e2) {
        console.error("[photoApi.create] localStorage quota exceeded:", e2);
        throw new Error("Хранилище переполнено. Попробуйте сохранить меньше фото за раз.");
      }
    }
    return { success: true, id: newPhoto.id };
  },

  createBatch: async (albumId: number | string, items: any[]) => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        const values = items.map((item) => ({
          album_id: albumId,
          url: item.url,
          thumbnail: item.thumbnail || null,
          caption: item.caption || null,
          location: item.location || null,
          taken_at: item.takenAt || null,
          is_cover: item.isCover ? 1 : 0,
          uploaded_by: item.uploadedBy,
        }));
        const { error } = await sb.from("photos").insert(values);
        if (!error) return { success: true, count: values.length };
        console.warn("[photoApi.createBatch] Supabase insert error:", error.message);
      } catch (e: any) {
        console.warn("[photoApi.createBatch] Supabase failed, using IndexedDB:", e?.message || e);
      }
    }
    // IndexedDB — no 5MB limit, supports batch writes
    const photosToSave = items.map((item) => ({
      ...item, albumId, id: generateId(), createdAt: new Date().toISOString(),
    }));
    try {
      await dbPhotoPutBatch(photosToSave);
      console.log("[photoApi.createBatch] Saved", photosToSave.length, "photos to IndexedDB");
    } catch (e) {
      console.error("[photoApi.createBatch] IndexedDB failed:", e);
      // Fallback: localStorage (may fail with quota)
      const photos = lsGet<any[]>("ff_photos", []);
      for (const item of items) {
        photos.push({ ...item, albumId, id: generateId(), createdAt: new Date().toISOString() });
      }
      try {
        lsSet("ff_photos", photos);
      } catch (e2) {
        console.error("[photoApi.createBatch] localStorage quota exceeded:", e2);
        throw new Error("Хранилище переполнено. Попробуйте сохранить меньше фото за раз.");
      }
    }
    return { success: true, count: items.length };
  },

  delete: async (id: string | number) => {
    const idStr = String(id);
    const deletedAt = new Date().toISOString();
    if (hasSupabase) {
      try {
        const sb = getSb();
        await sb.from("photos").update({ deleted_at: deletedAt }).eq("id", id);
      } catch (e: any) {
        console.warn("[photoApi.delete] Supabase failed:", e?.message || e);
      }
    }
    // IndexedDB
    await dbPhotoSoftDelete(id);
    // Legacy localStorage
    let photos = lsGet<any[]>("ff_photos", []);
    photos = photos.map((p) => String(p.id) === idStr ? { ...p, deletedAt } : p);
    lsSet("ff_photos", photos);
    return { success: true };
  },

  restore: async (id: string | number) => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        await sb.from("photos").update({ deleted_at: null }).eq("id", id);
      } catch (e: any) {
        console.warn("[photoApi.restore] Supabase failed:", e?.message || e);
      }
    }
    await dbPhotoRestore(id);
    let photos = lsGet<any[]>("ff_photos", []);
    const idStr = String(id);
    photos = photos.map((p) => String(p.id) === idStr ? { ...p, deletedAt: undefined } : p);
    lsSet("ff_photos", photos);
    return { success: true };
  },

  listDeleted: async () => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data, error } = await sb.from("photos").select("*").not("deleted_at", "is", null);
        if (!error && data) {
          return data.map((p: any) => ({
            ...p,
            deletedAt: p.deleted_at,
            albumId: p.album_id,
            isCover: p.is_cover,
            uploadedBy: p.uploaded_by,
            createdAt: p.created_at,
          }));
        }
      } catch (e: any) {
        console.warn("[photoApi.listDeleted] Supabase failed:", e?.message || e);
      }
    }
    const dbDeleted = await dbPhotoListDeleted();
    if (dbDeleted.length > 0) return dbDeleted;
    return lsGet<any[]>("ff_photos", []).filter((p) => p.deletedAt);
  },

  update: async (id: number | string, data: any) => {
    const idStr = String(id);
    if (hasSupabase) {
      try {
        const sb = getSb();
        const update: any = {};
        if (data.caption !== undefined) update.caption = data.caption;
        if (data.location !== undefined) update.location = data.location;
        if (data.emotion !== undefined) update.emotion = data.emotion;
        if (data.emotionNote !== undefined) update.emotion_note = data.emotionNote;
        if (data.isCover !== undefined) update.is_cover = data.isCover ? 1 : 0;
        const { error } = await sb.from("photos").update(update).eq("id", id);
        if (error) throw error;
        return { success: true };
      } catch (e: any) {
        console.warn("[photoApi.update] Supabase failed, using localStorage:", e?.message || e);
      }
    }
    const photos = lsGet<any[]>("ff_photos", []);
    const idx = photos.findIndex((p) => String(p.id) === idStr);
    if (idx !== -1) {
      photos[idx] = { ...photos[idx], ...data };
      lsSet("ff_photos", photos);
    }
    return { success: true };
  },

  setCover: async (albumId: number | string, photoId: number | string) => {
    const albumIdStr = String(albumId);
    const photoIdStr = String(photoId);
    if (hasSupabase) {
      try {
        const sb = getSb();
        await sb.from("photos").update({ is_cover: 0 }).eq("album_id", albumId);
        await sb.from("photos").update({ is_cover: 1 }).eq("id", photoId);
      } catch (e: any) {
        console.warn("[photoApi.setCover] Supabase failed, using localStorage:", e?.message || e);
      }
    }
    const photos = lsGet<any[]>("ff_photos", []);
    photos.forEach((p) => {
      if (String(p.albumId) === albumIdStr) p.isCover = false;
    });
    const idx = photos.findIndex((p) => String(p.id) === photoIdStr);
    if (idx !== -1) {
      photos[idx].isCover = true;
    }
    lsSet("ff_photos", photos);
    return { success: true };
  },
};

// Family Member API
export const memberApi = {
  list: async (albumId: number | string) => {
    const albumIdStr = String(albumId);
    let result: any[] = [];
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data, error } = await sb.from("family_members").select("*").eq("album_id", albumId).is("deleted_at", null).order("order_num", { ascending: true });
        if (error) throw error;
        result = (data || []).map((m: any) => ({
          ...m,
          deletedAt: m.deleted_at,
          albumId: m.album_id,
          photoUrl: m.photo_url,
          birthDate: m.birth_date,
          deathDate: m.death_date,
          parent1Id: m.parent1_id,
          parent2Id: m.parent2_id,
          spouseId: m.spouse_id,
          createdAt: m.created_at,
        })).filter((m: any) => !m.deletedAt);
      } catch (e: any) {
        console.warn("[memberApi.list] Supabase failed:", e?.message || e);
      }
    }
    if (result.length === 0) {
      const dbMembers = await dbMemberList(albumId);
      const existingIds = new Set(result.map((m) => String(m.id)));
      for (const m of dbMembers) {
        if (!existingIds.has(String(m.id))) result.push(m);
      }
    }
    if (result.length === 0) {
      result = lsGet<any[]>("ff_familyMembers", []).filter((m) => String(m.albumId) === albumIdStr && !m.deletedAt);
    }
    return result;
  },

  create: async (data: any) => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data: result, error } = await sb.from("family_members").insert({
          album_id: data.albumId,
          name: data.name,
          role: data.role,
          photo_url: data.photoUrl || null,
          birth_date: data.birthDate || null,
          death_date: data.deathDate || null,
          parent1_id: data.parent1Id || null,
          parent2_id: data.parent2Id || null,
          spouse_id: data.spouseId || null,
          bio: data.bio || null,
          order_num: data.order || 0,
        }).select().single();
        if (error) throw error;
        return result;
      } catch (e: any) {
        console.warn("[memberApi.create] Supabase failed, using IndexedDB:", e?.message || e);
      }
    }
    const newMember = { ...data, id: generateId(), createdAt: new Date().toISOString() };
    try {
      await dbMemberPut(newMember);
    } catch (e) {
      const members = lsGet<any[]>("ff_familyMembers", []);
      members.push(newMember);
      lsSet("ff_familyMembers", members);
    }
    return newMember;
  },

  update: async (id: number | string, data: any) => {
    const idStr = String(id);
    if (hasSupabase) {
      try {
        const sb = getSb();
        const update: any = {};
        if (data.name !== undefined) update.name = data.name;
        if (data.role !== undefined) update.role = data.role;
        if (data.photoUrl !== undefined) update.photo_url = data.photoUrl || null;
        if (data.birthDate !== undefined) update.birth_date = data.birthDate || null;
        if (data.deathDate !== undefined) update.death_date = data.deathDate || null;
        if (data.parent1Id !== undefined) update.parent1_id = data.parent1Id || null;
        if (data.parent2Id !== undefined) update.parent2_id = data.parent2Id || null;
        if (data.spouseId !== undefined) update.spouse_id = data.spouseId || null;
        if (data.bio !== undefined) update.bio = data.bio || null;
        await sb.from("family_members").update(update).eq("id", id);
      } catch (e: any) {
        console.warn("[memberApi.update] Supabase failed:", e?.message || e);
      }
    }
    // IndexedDB
    const dbMember = await withStore(STORE_MEMBERS, "readonly", (s) => s.get(id));
    if (dbMember) {
      await dbMemberPut({ ...dbMember, ...data });
    }
    // Legacy localStorage
    const members = lsGet<any[]>("ff_familyMembers", []);
    const idx = members.findIndex((m) => String(m.id) === idStr);
    if (idx !== -1) {
      members[idx] = { ...members[idx], ...data };
      lsSet("ff_familyMembers", members);
    }
    return { success: true };
  },

  delete: async (id: number | string) => {
    const deletedAt = new Date().toISOString();
    const idStr = String(id);
    if (hasSupabase) {
      try {
        const sb = getSb();
        await sb.from("family_members").update({ deleted_at: deletedAt }).eq("id", id);
      } catch (e: any) {
        console.warn("[memberApi.delete] Supabase failed:", e?.message || e);
      }
    }
    // IndexedDB
    await dbMemberSoftDelete(id);
    // Legacy localStorage
    let members = lsGet<any[]>("ff_familyMembers", []);
    members = members.map((m) => String(m.id) === idStr ? { ...m, deletedAt } : m);
    lsSet("ff_familyMembers", members);
    return { success: true };
  },

  restore: async (id: number | string) => {
    const idStr = String(id);
    if (hasSupabase) {
      try {
        const sb = getSb();
        await sb.from("family_members").update({ deleted_at: null }).eq("id", id);
      } catch (e: any) {
        console.warn("[memberApi.restore] Supabase failed:", e?.message || e);
      }
    }
    await dbMemberRestore(id);
    let members = lsGet<any[]>("ff_familyMembers", []);
    members = members.map((m) => String(m.id) === idStr ? { ...m, deletedAt: undefined } : m);
    lsSet("ff_familyMembers", members);
    return { success: true };
  },

  listDeleted: async () => {
    let result: any[] = [];
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data, error } = await sb.from("family_members").select("*").not("deleted_at", "is", null);
        if (!error && data) {
          result = data.map((m: any) => ({
            ...m,
            deletedAt: m.deleted_at,
            albumId: m.album_id,
            photoUrl: m.photo_url,
            birthDate: m.birth_date,
            deathDate: m.death_date,
            parent1Id: m.parent1_id,
            parent2Id: m.parent2_id,
            spouseId: m.spouse_id,
            createdAt: m.created_at,
          }));
        }
      } catch (e: any) {
        console.warn("[memberApi.listDeleted] Supabase failed:", e?.message || e);
      }
    }
    const dbDeleted = await withStore<any[]>("members", "readonly", (s) => s.getAll()).then((all) => all.filter((m) => m.deletedAt));
    const existingIds = new Set(result.map((m) => String(m.id)));
    for (const m of dbDeleted) {
      if (!existingIds.has(String(m.id))) result.push(m);
    }
    if (result.length === 0) {
      result = lsGet<any[]>("ff_familyMembers", []).filter((m) => m.deletedAt);
    }
    return result;
  },
};

// Auth helpers — unified single key
const AUTH_KEY = "auth_user";

export function getCurrentUser() {
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    if (!raw) return null;
    const user = JSON.parse(raw);
    return user?.token ? user : null;
  } catch {
    return null;
  }
}

export function setCurrentUser(user: any) {
  localStorage.setItem(AUTH_KEY, JSON.stringify(user));
}

export function logout() {
  // Sign out from Supabase too
  if (supabase) {
    supabase.auth.signOut().catch(() => {});
  }
  localStorage.removeItem(AUTH_KEY);
  window.location.hash = "#/login";
}

export function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.hash = "#/login";
    return null;
  }
  return user;
}

// Legacy stubs
export const photoBookApi = {
  list: (albumId: number | string) => {
    try { return JSON.parse(localStorage.getItem(`pb_${albumId}`) || "[]"); } catch { return []; }
  },
  generate: (albumId: number | string) => {
    const albumIdStr = String(albumId);
    const photos = JSON.parse(localStorage.getItem("ff_photos") || "[]").filter((p: any) => String(p.albumId) === albumIdStr);
    const book = photos.map((p: any, i: number) => ({ ...p, page: Math.floor(i / 2) + 1, layout: "auto" }));
    localStorage.setItem(`pb_${albumId}`, JSON.stringify(book));
    return book;
  },
  reset: (albumId: number | string) => {
    localStorage.removeItem(`pb_${albumId}`);
  },
};

export const supportApi = {
  stats: () => {
    try {
      const reviews = JSON.parse(localStorage.getItem("ff_reviews") || "[]");
      const total = reviews.length;
      const avgRating = total > 0 ? reviews.reduce((sum: number, r: any) => sum + (r.rating || 0), 0) / total : 0;
      return { total, avgRating: Math.round(avgRating * 10) / 10 };
    } catch {
      return { total: 0, avgRating: 0 };
    }
  },
  create: (data: any) => {
    try {
      const reviews = JSON.parse(localStorage.getItem("ff_reviews") || "[]");
      reviews.push({ ...data, createdAt: new Date().toISOString() });
      localStorage.setItem("ff_reviews", JSON.stringify(reviews));
    } catch { /* */ }
  },
};

export const inviteApi = {
  create: async (data: { type: string; albumId: number | string; role?: string; email?: string }) => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        const token = generateId().slice(0, 16);
        const { error } = await sb.from("invites").insert({
          token,
          type: data.type,
          album_id: data.albumId,
          role: data.role || "viewer",
          email: data.email || null,
        });
        if (!error) {
          if (data.email) trackInvitedUser(data.email);
          return { token, ...data };
        }
      } catch (e: any) {
        console.warn("[inviteApi.create] Supabase failed:", e?.message || e);
      }
    }
    const invites = lsGet<any[]>("ff_invites", []);
    const token = generateId().slice(0, 16);
    invites.push({ token, ...data, createdAt: new Date().toISOString() });
    lsSet("ff_invites", invites);
    if (data.email) trackInvitedUser(data.email);
    return { token, ...data };
  },

  verify: async (token: string) => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { data, error } = await sb.from("invites").select("*").eq("token", token).single();
        if (error || !data) return { valid: false };
        return { valid: !data.used_at, token, albumId: data.album_id, type: data.type };
      } catch (e: any) {
        console.warn("[inviteApi.verify] Supabase failed, using localStorage:", e?.message || e);
      }
    }
    const invites = lsGet<any[]>("ff_invites", []);
    const invite = invites.find((i) => i.token === token);
    if (!invite) return { valid: false };
    return { valid: !invite.usedAt, token, albumId: invite.albumId, type: invite.type };
  },

  accept: async (token: string) => {
    if (hasSupabase) {
      try {
        const sb = getSb();
        const { error } = await sb.from("invites").update({ used_at: new Date().toISOString() }).eq("token", token);
        if (error) throw error;
      } catch (e: any) {
        console.warn("[inviteApi.accept] Supabase failed, using localStorage:", e?.message || e);
      }
    }
    // Always mark as used in localStorage
    const invites = lsGet<any[]>("ff_invites", []);
    const idx = invites.findIndex((i) => i.token === token);
    if (idx !== -1) {
      invites[idx] = { ...invites[idx], usedAt: new Date().toISOString() };
      lsSet("ff_invites", invites);
    }
    return true;
  },

  cancel: (id: number) => Promise.resolve(true),
  listByAlbum: (albumId: number) => Promise.resolve([]),
};

// List files in Supabase Storage
export async function listStorageFiles(bucket: string = "family-foto", path: string = "photos"): Promise<string[]> {
  if (!hasSupabase) {
    console.warn("[listStorageFiles] Supabase not available");
    return [];
  }
  try {
    const sb = getSb();
    const { data, error } = await sb.storage.from(bucket).list(path);
    if (error) {
      console.error("[listStorageFiles] error:", error.message);
      return [];
    }
    return (data || []).map((f: any) => {
      const { data: urlData } = sb.storage.from(bucket).getPublicUrl(`${path}/${f.name}`);
      return urlData.publicUrl;
    });
  } catch (e: any) {
    console.error("[listStorageFiles] exception:", e?.message || e);
    return [];
  }
}

export function getAdminStats() {
  const albums = lsGet<Album[]>("ff_albums", []).filter((a) => !a.deletedAt);
  const photos = lsGet<any[]>("ff_photos", []).filter((p) => !p.deletedAt);
  const users = JSON.parse(localStorage.getItem("ff_users") || "[]");
  const invites = lsGet<any[]>("ff_invites", []);
  const reviews = lsGet<any[]>("ff_reviews", []);
  return {
    albums: albums.length,
    photos: photos.length,
    users: Array.isArray(users) ? users.length : 0,
    invites: invites.length,
    reviews: reviews.length,
  };
}

export function seedDemoData() {
  const albums = lsGet<Album[]>("ff_albums", []);
  let allPhotos = lsGet<any[]>("ff_photos", []);
  let allMembers = lsGet<any[]>("ff_familyMembers", []);

  // Case 1: completely new user — create everything from scratch
  if (albums.length === 0) {
    const photoAlbumId = generateId();
    const treeAlbumId = generateId();

    const photoAlbum = {
      id: photoAlbumId,
      title: "Мой первый альбом",
      description: "Демонстрационный альбом",
      year: new Date().getFullYear(),
      month: null,
      albumType: "photo",
      coverPhoto: "./demo-photos/family1.jpg",
      accentColor: "#c9a87c",
      backgroundColor: "#faf8f5",
      fontFamily: "serif",
      photosPerPage: 2,
      isPublic: false,
      createdBy: 1,
      createdAt: new Date().toISOString(),
    };

    const treeAlbum = {
      id: treeAlbumId,
      title: "Семейное древо Ушаковых",
      description: "Родословная семьи",
      year: null,
      month: null,
      albumType: "family_tree",
      coverPhoto: "./demo-photos/tree_cover.jpg",
      accentColor: "#c9a87c",
      backgroundColor: "#faf8f5",
      fontFamily: "serif",
      photosPerPage: 2,
      isPublic: false,
      createdBy: 1,
      createdAt: new Date().toISOString(),
    };

    lsSet("ff_albums", [photoAlbum, treeAlbum]);

    // Seed demo photos
    const demoPhotos = [
      "./demo-photos/family1.jpg",
      "./demo-photos/family2.jpg",
      "./demo-photos/family3.jpg",
      "./demo-photos/family4.jpg",
      "./demo-photos/family5.jpg",
      "./demo-photos/family6.jpg",
    ];
    const captions = [
      "Семья вместе",
      "Бабушка и дедушка",
      "Готовим вместе",
      "Праздничный ужин",
      "Осенняя прогулка",
      "Закат на пляже",
    ];
    const photos = demoPhotos.map((url, i) => ({
      id: generateId(),
      albumId: photoAlbumId,
      url,
      thumbnail: null,
      caption: captions[i],
      location: null,
      takenAt: null,
      isCover: i === 0,
      uploadedBy: 1,
      createdAt: new Date().toISOString(),
    }));
    lsSet("ff_photos", photos);

    // Seed demo family members
    const dedId = generateId();
    const babId = generateId();
    const fatherId = generateId();
    const motherId = generateId();
    const childId = generateId();

    const members = [
      {
        id: dedId,
        albumId: treeAlbumId,
        name: "Александр Ушаков",
        role: "ded",
        photoUrl: "./demo-photos/family2.jpg",
        birthDate: "1950-03-15",
        deathDate: null,
        parent1Id: null,
        parent2Id: null,
        spouseId: babId,
        order: 0,
        createdAt: new Date().toISOString(),
      },
      {
        id: babId,
        albumId: treeAlbumId,
        name: "Елена Ушакова",
        role: "babushka",
        photoUrl: "./demo-photos/family3.jpg",
        birthDate: "1952-07-22",
        deathDate: null,
        parent1Id: null,
        parent2Id: null,
        spouseId: dedId,
        order: 1,
        createdAt: new Date().toISOString(),
      },
      {
        id: fatherId,
        albumId: treeAlbumId,
        name: "Сергей Ушаков",
        role: "otets",
        photoUrl: "./demo-photos/family4.jpg",
        birthDate: "1975-11-08",
        deathDate: null,
        parent1Id: dedId,
        parent2Id: babId,
        spouseId: motherId,
        order: 2,
        createdAt: new Date().toISOString(),
      },
      {
        id: motherId,
        albumId: treeAlbumId,
        name: "Мария Ушакова",
        role: "mat",
        photoUrl: "./demo-photos/family5.jpg",
        birthDate: "1978-04-12",
        deathDate: null,
        parent1Id: null,
        parent2Id: null,
        spouseId: fatherId,
        order: 3,
        createdAt: new Date().toISOString(),
      },
      {
        id: childId,
        albumId: treeAlbumId,
        name: "Виктор Ушаков",
        role: "syn",
        photoUrl: "./demo-photos/family1.jpg",
        birthDate: "2005-06-01",
        deathDate: null,
        parent1Id: fatherId,
        parent2Id: motherId,
        spouseId: null,
        order: 4,
        createdAt: new Date().toISOString(),
      },
    ];
    lsSet("ff_familyMembers", members);

    console.log("[seed] Created demo albums + photos + members for new user");
    return;
  }

  // Case 2: user has albums but demo albums are missing content — backfill photos & members
  const photoAlbum = albums.find((a) => a.title === "Мой первый альбом" && a.albumType === "photo" && !a.deletedAt);
  if (photoAlbum) {
    const existingPhotos = allPhotos.filter((p) => p.albumId === photoAlbum.id && !p.deletedAt);
    if (existingPhotos.length === 0) {
      const demoPhotos = [
        "./demo-photos/family1.jpg",
        "./demo-photos/family2.jpg",
        "./demo-photos/family3.jpg",
        "./demo-photos/family4.jpg",
        "./demo-photos/family5.jpg",
        "./demo-photos/family6.jpg",
      ];
      const captions = [
        "Семья вместе",
        "Бабушка и дедушка",
        "Готовим вместе",
        "Праздничный ужин",
        "Осенняя прогулка",
        "Закат на пляже",
      ];
      for (let i = 0; i < demoPhotos.length; i++) {
        allPhotos.push({
          id: generateId(),
          albumId: photoAlbum.id,
          url: demoPhotos[i],
          thumbnail: null,
          caption: captions[i],
          location: null,
          takenAt: null,
          isCover: i === 0,
          uploadedBy: 1,
          createdAt: new Date().toISOString(),
        });
      }
      lsSet("ff_photos", allPhotos);
      console.log("[seed] Backfilled demo photos for photo album");
    }
  }

  const treeAlbum = albums.find((a) => a.title === "Семейное древо Ушаковых" && a.albumType === "family_tree" && !a.deletedAt);
  if (treeAlbum) {
    // Set cover photo if missing
    if (!treeAlbum.coverPhoto) {
      const albumsToUpdate = lsGet<Album[]>("ff_albums", []);
      const idx = albumsToUpdate.findIndex((a) => String(a.id) === String(treeAlbum.id));
      if (idx !== -1) {
        albumsToUpdate[idx] = { ...albumsToUpdate[idx], coverPhoto: "./demo-photos/tree_cover.jpg" };
        lsSet("ff_albums", albumsToUpdate);
      }
      console.log("[seed] Set tree cover photo");
    }
    const existingMembers = allMembers.filter((m) => m.albumId === treeAlbum.id && !m.deletedAt);
    if (existingMembers.length === 0) {
      const dedId = generateId();
      const babId = generateId();
      const fatherId = generateId();
      const motherId = generateId();
      const childId = generateId();

      allMembers.push(
        {
          id: dedId,
          albumId: treeAlbum.id,
          name: "Александр Ушаков",
          role: "ded",
          photoUrl: "./demo-photos/family2.jpg",
          birthDate: "1950-03-15",
          deathDate: null,
          parent1Id: null,
          parent2Id: null,
          spouseId: babId,
          order: 0,
          createdAt: new Date().toISOString(),
        },
        {
          id: babId,
          albumId: treeAlbum.id,
          name: "Елена Ушакова",
          role: "babushka",
          photoUrl: "./demo-photos/family3.jpg",
          birthDate: "1952-07-22",
          deathDate: null,
          parent1Id: null,
          parent2Id: null,
          spouseId: dedId,
          order: 1,
          createdAt: new Date().toISOString(),
        },
        {
          id: fatherId,
          albumId: treeAlbum.id,
          name: "Сергей Ушаков",
          role: "otets",
          photoUrl: "./demo-photos/family4.jpg",
          birthDate: "1975-11-08",
          deathDate: null,
          parent1Id: dedId,
          parent2Id: babId,
          spouseId: motherId,
          order: 2,
          createdAt: new Date().toISOString(),
        },
        {
          id: motherId,
          albumId: treeAlbum.id,
          name: "Мария Ушакова",
          role: "mat",
          photoUrl: "./demo-photos/family5.jpg",
          birthDate: "1978-04-12",
          deathDate: null,
          parent1Id: null,
          parent2Id: null,
          spouseId: fatherId,
          order: 3,
          createdAt: new Date().toISOString(),
        },
        {
          id: childId,
          albumId: treeAlbum.id,
          name: "Виктор Ушаков",
          role: "syn",
          photoUrl: "./demo-photos/family1.jpg",
          birthDate: "2005-06-01",
          deathDate: null,
          parent1Id: fatherId,
          parent2Id: motherId,
          spouseId: null,
          order: 4,
          createdAt: new Date().toISOString(),
        }
      );
      lsSet("ff_familyMembers", allMembers);
      console.log("[seed] Backfilled demo members for tree album");
    }
  }
}

export function getUpcomingBirthdays(daysWindow = 30) {
  const members = lsGet<any[]>("ff_familyMembers", []).filter((m) => !m.deletedAt);
  if (!members.length) return [];

  const today = new Date();
  const currentYear = today.getFullYear();
  const result: any[] = [];

  for (const m of members) {
    if (!m.birthDate) continue;
    const [year, month, day] = m.birthDate.split("-").map(Number);
    if (!month || !day) continue;

    let nextBirthday = new Date(currentYear, month - 1, day);
    if (nextBirthday < today) {
      nextBirthday = new Date(currentYear + 1, month - 1, day);
    }

    const diffMs = nextBirthday.getTime() - today.getTime();
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays <= daysWindow) {
      const age = nextBirthday.getFullYear() - year;
      result.push({
        id: m.id,
        name: m.name,
        birthDate: m.birthDate,
        daysUntil: diffDays,
        age: age > 0 && age < 150 ? age : null,
        role: m.role,
        photoUrl: m.photoUrl || null,
      });
    }
  }

  return result.sort((a, b) => a.daysUntil - b.daysUntil);
}


// ===== SYSTEM SETTINGS =====
const SETTINGS_KEY = "ff_settings";

const DEFAULT_SETTINGS = {
  siteName: "Семейный Альбом",
  supportEmail: "support@family-foto.ru",
  social: {
    telegram: "https://t.me/familyfotoru",
    vk: "https://vk.com/familyfotoru",
    instagram: "https://instagram.com/familyfotoru",
    youtube: "https://youtube.com/@familyfotoru",
  },
  colors: {
    accent: "#c9a87c",
    background: "#faf8f5",
  },
  features: {
    registration: true,
    albums: true,
    photos: true,
    familyTree: true,
    invites: true,
    reviews: true,
    demoData: true,
  },
  adminPassword: "mariana2024",
};

export function getSettings(): typeof DEFAULT_SETTINGS {
  try {
    const stored = localStorage.getItem(SETTINGS_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return { ...DEFAULT_SETTINGS, ...parsed, social: { ...DEFAULT_SETTINGS.social, ...(parsed.social || {}) }, features: { ...DEFAULT_SETTINGS.features, ...(parsed.features || {}) }, colors: { ...DEFAULT_SETTINGS.colors, ...(parsed.colors || {}) } };
    }
  } catch { /* ignore */ }
  return { ...DEFAULT_SETTINGS };
}

export function saveSettings(settings: Partial<typeof DEFAULT_SETTINGS>) {
  const current = getSettings();
  const merged = {
    ...current,
    ...settings,
    social: { ...current.social, ...(settings.social || {}) },
    features: { ...current.features, ...(settings.features || {}) },
    colors: { ...current.colors, ...(settings.colors || {}) },
  };
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(merged));
  return merged;
}

export function isFeatureEnabled(feature: keyof typeof DEFAULT_SETTINGS.features): boolean {
  return getSettings().features[feature] ?? true;
}

export function changeAdminPassword(current: string, newPass: string): boolean {
  const settings = getSettings();
  if (settings.adminPassword !== current) return false;
  saveSettings({ adminPassword: newPass });
  return true;
}

// Check storage usage
export function getStorageUsage() {
  let total = 0;
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key) {
      total += localStorage.getItem(key)?.length || 0;
    }
  }
  // localStorage limit ~5-10MB on mobile
  const limit = 5 * 1024 * 1024; // 5MB
  return {
    used: total,
    limit,
    percent: Math.round((total / limit) * 100),
    warning: total / limit > 0.8,
  };
}


// ===== TRASH / RECYCLE BIN =====

const DAYS_TO_KEEP = 30;

export function cleanupOldDeletedItems() {
  const cutoff = Date.now() - DAYS_TO_KEEP * 24 * 60 * 60 * 1000;

  // Clean albums
  let albums = lsGet<Album[]>("ff_albums", []);
  const albumsBefore = albums.length;
  albums = albums.filter((a) => {
    if (!a.deletedAt) return true;
    return new Date(a.deletedAt).getTime() > cutoff;
  });
  if (albums.length < albumsBefore) {
    lsSet("ff_albums", albums);
    console.log(`[cleanup] Removed ${albumsBefore - albums.length} old albums`);
  }

  // Clean photos
  let photos = lsGet<any[]>("ff_photos", []);
  const photosBefore = photos.length;
  photos = photos.filter((p) => {
    if (!p.deletedAt) return true;
    return new Date(p.deletedAt).getTime() > cutoff;
  });
  if (photos.length < photosBefore) {
    lsSet("ff_photos", photos);
    console.log(`[cleanup] Removed ${photosBefore - photos.length} old photos`);
  }

  // Clean members
  let members = lsGet<any[]>("ff_familyMembers", []);
  const membersBefore = members.length;
  members = members.filter((m) => {
    if (!m.deletedAt) return true;
    return new Date(m.deletedAt).getTime() > cutoff;
  });
  if (members.length < membersBefore) {
    lsSet("ff_familyMembers", members);
    console.log(`[cleanup] Removed ${membersBefore - members.length} old members`);
  }
}

// Days remaining before permanent deletion
export function getDaysRemaining(deletedAt: string): number {
  const deleted = new Date(deletedAt).getTime();
  const expires = deleted + DAYS_TO_KEEP * 24 * 60 * 60 * 1000;
  const remaining = Math.ceil((expires - Date.now()) / (24 * 60 * 60 * 1000));
  return Math.max(0, remaining);
}
