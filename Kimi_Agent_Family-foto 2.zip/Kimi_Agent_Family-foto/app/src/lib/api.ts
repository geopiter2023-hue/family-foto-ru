import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "";
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "";

export const supabase =
  supabaseUrl && supabaseKey
    ? createClient(supabaseUrl, supabaseKey, {
        auth: { autoRefreshToken: true, persistSession: true },
      })
    : null;

// Check if Supabase is configured
const hasSupabase = !!supabase;

function getSb() {
  if (!supabase) throw new Error("Supabase not configured");
  return supabase;
}

// ==========================================
// LOCAL STORAGE FALLBACK (when Supabase not configured)
// ==========================================

function lsGet<T>(key: string, fallback: T): T {
  try { return JSON.parse(localStorage.getItem(key) || "null") ?? fallback; } catch { return fallback; }
}
function lsSet(key: string, val: any) {
  localStorage.setItem(key, JSON.stringify(val));
}
function generateId() {
  return Date.now() + Math.floor(Math.random() * 1000);
}

// Upload file — with fallback
export async function uploadFile(file: File): Promise<string> {
  if (hasSupabase) {
    const sb = getSb();
    const fileExt = file.name.split(".").pop() || "jpg";
    const fileName = `${Date.now()}_${Math.random().toString(36).slice(2)}.${fileExt}`;
    const filePath = `photos/${fileName}`;
    const { error } = await sb.storage.from("family-foto").upload(filePath, file, {
      cacheControl: "3600", upsert: false,
    });
    if (error) throw new Error(`Upload failed: ${error.message}`);
    const { data } = sb.storage.from("family-foto").getPublicUrl(filePath);
    return data.publicUrl;
  }
  // Fallback: base64
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (ev) => resolve(ev.target?.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Album API — with localStorage fallback
export const albumApi = {
  list: async () => {
    if (hasSupabase) {
      const sb = getSb();
      const { data, error } = await sb.from("albums").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data || [];
    }
    return lsGet<Album[]>("ff_albums", []);
  },

  getById: async (id: number) => {
    if (hasSupabase) {
      const sb = getSb();
      const { data: album, error } = await sb.from("albums").select("*").eq("id", id).single();
      if (error || !album) return null;
      const { data: photos } = await sb.from("photos").select("*").eq("album_id", id).order("created_at", { ascending: true });
      const { data: members } = await sb.from("family_members").select("*").eq("album_id", id).order("order_num", { ascending: true });
      return { ...album, photos: photos || [], members: members || [] };
    }
    const albums = lsGet<Album[]>("ff_albums", []);
    const a = albums.find((a) => a.id === id);
    if (!a) return null;
    const photos = lsGet<any[]>("ff_photos", []).filter((p) => p.albumId === id);
    const members = lsGet<any[]>("ff_familyMembers", []).filter((m) => m.albumId === id);
    return { ...a, photos, members };
  },

  create: async (data: any) => {
    if (hasSupabase) {
      const sb = getSb();
      const { data: result, error } = await sb.from("albums").insert({
        title: data.title,
        description: data.description || null,
        year: data.year,
        month: data.month,
        album_type: data.albumType || "photo",
        cover_photo: data.coverPhoto || null,
        accent_color: data.accentColor || "#c9a87c",
        background_color: data.backgroundColor || "#faf8f5",
        font_family: data.fontFamily || "serif",
        photos_per_page: data.photosPerPage || 2,
        is_public: data.isPublic ? 1 : 0,
        created_by: data.createdBy,
      }).select().single();
      if (error) throw error;
      return result;
    }
    // LocalStorage fallback
    const albums = lsGet<Album[]>("ff_albums", []);
    const newAlbum = { ...data, id: generateId(), createdAt: new Date().toISOString() };
    albums.push(newAlbum);
    lsSet("ff_albums", albums);
    return newAlbum;
  },

  update: async (id: number, data: any) => {
    if (hasSupabase) {
      const sb = getSb();
      const update: any = {};
      if (data.title !== undefined) update.title = data.title;
      if (data.description !== undefined) update.description = data.description;
      if (data.year !== undefined) update.year = data.year;
      if (data.month !== undefined) update.month = data.month;
      if (data.coverPhoto !== undefined) update.cover_photo = data.coverPhoto;
      if (data.accentColor !== undefined) update.accent_color = data.accentColor;
      if (data.backgroundColor !== undefined) update.background_color = data.backgroundColor;
      if (data.fontFamily !== undefined) update.font_family = data.fontFamily;
      if (data.photosPerPage !== undefined) update.photos_per_page = data.photosPerPage;
      if (data.isPublic !== undefined) update.is_public = data.isPublic ? 1 : 0;
      const { error } = await sb.from("albums").update(update).eq("id", id);
      if (error) throw error;
      return { success: true };
    }
    const albums = lsGet<Album[]>("ff_albums", []);
    const idx = albums.findIndex((a) => a.id === id);
    if (idx !== -1) {
      albums[idx] = { ...albums[idx], ...data };
      try {
        lsSet("ff_albums", albums);
      } catch (e) {
        console.error("[albumApi.update] localStorage quota exceeded:", e);
        throw new Error("Не удалось сохранить — хранилище переполнено. Попробуйте удалить старые фото.");
      }
    }
    return { success: true };
  },

  delete: async (id: number) => {
    if (hasSupabase) {
      const sb = getSb();
      await sb.from("photos").delete().eq("album_id", id);
      await sb.from("family_members").delete().eq("album_id", id);
      const { error } = await sb.from("albums").delete().eq("id", id);
      if (error) throw error;
      return { success: true };
    }
    let albums = lsGet<Album[]>("ff_albums", []);
    albums = albums.filter((a) => a.id !== id);
    lsSet("ff_albums", albums);
    let photos = lsGet<any[]>("ff_photos", []);
    photos = photos.filter((p) => p.albumId !== id);
    lsSet("ff_photos", photos);
    let members = lsGet<any[]>("ff_familyMembers", []);
    members = members.filter((m) => m.albumId !== id);
    lsSet("ff_familyMembers", members);
    return { success: true };
  },
};

// Photo API
export const photoApi = {
  list: async (albumId: number) => {
    if (hasSupabase) {
      const sb = getSb();
      const { data, error } = await sb.from("photos").select("*").eq("album_id", albumId).order("created_at", { ascending: true });
      if (error) throw error;
      return data || [];
    }
    return lsGet<any[]>("ff_photos", []).filter((p) => p.albumId === albumId);
  },

  create: async (data: any) => {
    if (hasSupabase) {
      const sb = getSb();
      const { error } = await sb.from("photos").insert({
        album_id: data.albumId,
        url: data.url,
        thumbnail: data.thumbnail || null,
        caption: data.caption || null,
        location: data.location || null,
        taken_at: data.takenAt || null,
        is_cover: data.isCover ? 1 : 0,
        uploaded_by: data.uploadedBy,
      });
      if (error) throw error;
      return { success: true };
    }
    const photos = lsGet<any[]>("ff_photos", []);
    photos.push({ ...data, id: generateId(), createdAt: new Date().toISOString() });
    lsSet("ff_photos", photos);
    return { success: true };
  },

  createBatch: async (albumId: number, items: any[]) => {
    if (hasSupabase) {
      const sb = getSb();
      const values = items.map((item) => ({
        album_id: albumId,
        url: item.url,
        thumbnail: item.thumbnail || null,
        caption: item.caption || null,
        location: item.location || null,
        taken_at: item.takenAt || null,
        is_cover: item.isCover ? 1 : 0,
        uploaded_by: item.uploadedBy,
      }));
      const { error } = await sb.from("photos").insert(values);
      if (error) throw error;
      return { success: true, count: values.length };
    }
    const photos = lsGet<any[]>("ff_photos", []);
    for (const item of items) {
      photos.push({ ...item, albumId, id: generateId(), createdAt: new Date().toISOString() });
    }
    lsSet("ff_photos", photos);
    return { success: true, count: items.length };
  },

  delete: async (id: number) => {
    if (hasSupabase) {
      const sb = getSb();
      const { error } = await sb.from("photos").delete().eq("id", id);
      if (error) throw error;
      return { success: true };
    }
    let photos = lsGet<any[]>("ff_photos", []);
    photos = photos.filter((p) => p.id !== id);
    lsSet("ff_photos", photos);
    return { success: true };
  },

  update: async (id: number, data: any) => {
    if (hasSupabase) {
      const sb = getSb();
      const update: any = {};
      if (data.caption !== undefined) update.caption = data.caption;
      if (data.location !== undefined) update.location = data.location;
      if (data.emotion !== undefined) update.emotion = data.emotion;
      if (data.emotionNote !== undefined) update.emotion_note = data.emotionNote;
      if (data.isCover !== undefined) update.is_cover = data.isCover ? 1 : 0;
      const { error } = await sb.from("photos").update(update).eq("id", id);
      if (error) throw error;
      return { success: true };
    }
    const photos = lsGet<any[]>("ff_photos", []);
    const idx = photos.findIndex((p) => p.id === id);
    if (idx !== -1) {
      photos[idx] = { ...photos[idx], ...data };
      lsSet("ff_photos", photos);
    }
    return { success: true };
  },

  setCover: async (albumId: number, photoId: number) => {
    if (hasSupabase) {
      const sb = getSb();
      // Clear previous cover
      await sb.from("photos").update({ is_cover: 0 }).eq("album_id", albumId);
      // Set new cover
      const { error } = await sb.from("photos").update({ is_cover: 1 }).eq("id", photoId);
      if (error) throw error;
      return { success: true };
    }
    const photos = lsGet<any[]>("ff_photos", []);
    photos.forEach((p) => {
      if (p.albumId === albumId) p.isCover = false;
    });
    const idx = photos.findIndex((p) => p.id === photoId);
    if (idx !== -1) {
      photos[idx].isCover = true;
    }
    lsSet("ff_photos", photos);
    return { success: true };
  },
};

// Family Member API
export const memberApi = {
  list: async (albumId: number) => {
    if (hasSupabase) {
      const sb = getSb();
      const { data, error } = await sb.from("family_members").select("*").eq("album_id", albumId).order("order_num", { ascending: true });
      if (error) throw error;
      return data || [];
    }
    return lsGet<any[]>("ff_familyMembers", []).filter((m) => m.albumId === albumId);
  },

  create: async (data: any) => {
    if (hasSupabase) {
      const sb = getSb();
      const { data: result, error } = await sb.from("family_members").insert({
        album_id: data.albumId,
        name: data.name,
        role: data.role,
        photo_url: data.photoUrl || null,
        birth_date: data.birthDate || null,
        death_date: data.deathDate || null,
        parent1_id: data.parent1Id || null,
        parent2_id: data.parent2Id || null,
        spouse_id: data.spouseId || null,
        bio: data.bio || null,
        order_num: data.order || 0,
      }).select().single();
      if (error) throw error;
      return result;
    }
    const members = lsGet<any[]>("ff_familyMembers", []);
    const newMember = { ...data, id: generateId(), createdAt: new Date().toISOString() };
    members.push(newMember);
    lsSet("ff_familyMembers", members);
    return newMember;
  },

  update: async (id: number, data: any) => {
    if (hasSupabase) {
      const sb = getSb();
      const update: any = {};
      if (data.name !== undefined) update.name = data.name;
      if (data.role !== undefined) update.role = data.role;
      if (data.photoUrl !== undefined) update.photo_url = data.photoUrl || null;
      if (data.birthDate !== undefined) update.birth_date = data.birthDate || null;
      if (data.deathDate !== undefined) update.death_date = data.deathDate || null;
      if (data.parent1Id !== undefined) update.parent1_id = data.parent1Id || null;
      if (data.parent2Id !== undefined) update.parent2_id = data.parent2Id || null;
      if (data.spouseId !== undefined) update.spouse_id = data.spouseId || null;
      if (data.bio !== undefined) update.bio = data.bio || null;
      const { error } = await sb.from("family_members").update(update).eq("id", id);
      if (error) throw error;
      return { success: true };
    }
    const members = lsGet<any[]>("ff_familyMembers", []);
    const idx = members.findIndex((m) => m.id === id);
    if (idx !== -1) {
      members[idx] = { ...members[idx], ...data };
      lsSet("ff_familyMembers", members);
    }
    return { success: true };
  },

  delete: async (id: number) => {
    if (hasSupabase) {
      const sb = getSb();
      const { error } = await sb.from("family_members").delete().eq("id", id);
      if (error) throw error;
      return { success: true };
    }
    let members = lsGet<any[]>("ff_familyMembers", []);
    members = members.filter((m) => m.id !== id);
    lsSet("ff_familyMembers", members);
    return { success: true };
  },
};

// Auth helpers — unified single key
const AUTH_KEY = "auth_user";

export function getCurrentUser() {
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    if (!raw) return null;
    const user = JSON.parse(raw);
    return user?.token ? user : null;
  } catch {
    return null;
  }
}

export function setCurrentUser(user: any) {
  localStorage.setItem(AUTH_KEY, JSON.stringify(user));
}

export function logout() {
  // Sign out from Supabase too
  if (supabase) {
    supabase.auth.signOut().catch(() => {});
  }
  localStorage.removeItem(AUTH_KEY);
  window.location.hash = "#/login";
}

export function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.hash = "#/login";
    return null;
  }
  return user;
}

// Legacy stubs
export const photoBookApi = {
  list: (albumId: number) => {
    try { return JSON.parse(localStorage.getItem(`pb_${albumId}`) || "[]"); } catch { return []; }
  },
  generate: (albumId: number) => {
    const photos = JSON.parse(localStorage.getItem("ff_photos") || "[]").filter((p: any) => p.albumId === albumId);
    const book = photos.map((p: any, i: number) => ({ ...p, page: Math.floor(i / 2) + 1, layout: "auto" }));
    localStorage.setItem(`pb_${albumId}`, JSON.stringify(book));
    return book;
  },
  reset: (albumId: number) => {
    localStorage.removeItem(`pb_${albumId}`);
  },
};

export const supportApi = {
  stats: () => {
    try {
      const reviews = JSON.parse(localStorage.getItem("ff_reviews") || "[]");
      const total = reviews.length;
      const avgRating = total > 0 ? reviews.reduce((sum: number, r: any) => sum + (r.rating || 0), 0) / total : 0;
      return { total, avgRating: Math.round(avgRating * 10) / 10 };
    } catch {
      return { total: 0, avgRating: 0 };
    }
  },
  create: (data: any) => {
    try {
      const reviews = JSON.parse(localStorage.getItem("ff_reviews") || "[]");
      reviews.push({ ...data, createdAt: new Date().toISOString() });
      localStorage.setItem("ff_reviews", JSON.stringify(reviews));
    } catch { /* */ }
  },
};

export const inviteApi = {
  verify: (token: string) => Promise.resolve({ valid: true, token }),
  create: (data: any) => Promise.resolve(data),
  cancel: (id: number) => Promise.resolve(true),
  accept: (token: string) => Promise.resolve(true),
  listByAlbum: (albumId: number) => Promise.resolve([]),
};

export function getAdminStats() {
  return { albums: 0, photos: 0, users: 0, invites: 0, reviews: 0 };
}

export function seedDemoData() {
  const albums = lsGet<Album[]>("ff_albums", []);
  let allPhotos = lsGet<any[]>("ff_photos", []);
  let allMembers = lsGet<any[]>("ff_familyMembers", []);

  // Case 1: completely new user — create everything from scratch
  if (albums.length === 0) {
    const photoAlbumId = generateId();
    const treeAlbumId = generateId();

    const photoAlbum = {
      id: photoAlbumId,
      title: "Мой первый альбом",
      description: "Демонстрационный альбом",
      year: new Date().getFullYear(),
      month: null,
      albumType: "photo",
      coverPhoto: "./demo-photos/family1.jpg",
      accentColor: "#c9a87c",
      backgroundColor: "#faf8f5",
      fontFamily: "serif",
      photosPerPage: 2,
      isPublic: false,
      createdBy: 1,
      createdAt: new Date().toISOString(),
    };

    const treeAlbum = {
      id: treeAlbumId,
      title: "Семейное древо Ушаковых",
      description: "Родословная семьи",
      year: null,
      month: null,
      albumType: "family_tree",
      coverPhoto: "./demo-photos/tree_cover.jpg",
      accentColor: "#c9a87c",
      backgroundColor: "#faf8f5",
      fontFamily: "serif",
      photosPerPage: 2,
      isPublic: false,
      createdBy: 1,
      createdAt: new Date().toISOString(),
    };

    lsSet("ff_albums", [photoAlbum, treeAlbum]);

    // Seed demo photos
    const demoPhotos = [
      "./demo-photos/family1.jpg",
      "./demo-photos/family2.jpg",
      "./demo-photos/family3.jpg",
      "./demo-photos/family4.jpg",
      "./demo-photos/family5.jpg",
      "./demo-photos/family6.jpg",
    ];
    const captions = [
      "Семья вместе",
      "Бабушка и дедушка",
      "Готовим вместе",
      "Праздничный ужин",
      "Осенняя прогулка",
      "Закат на пляже",
    ];
    const photos = demoPhotos.map((url, i) => ({
      id: generateId(),
      albumId: photoAlbumId,
      url,
      thumbnail: null,
      caption: captions[i],
      location: null,
      takenAt: null,
      isCover: i === 0,
      uploadedBy: 1,
      createdAt: new Date().toISOString(),
    }));
    lsSet("ff_photos", photos);

    // Seed demo family members
    const dedId = generateId();
    const babId = generateId();
    const fatherId = generateId();
    const motherId = generateId();
    const childId = generateId();

    const members = [
      {
        id: dedId,
        albumId: treeAlbumId,
        name: "Александр Ушаков",
        role: "ded",
        photoUrl: "./demo-photos/family2.jpg",
        birthDate: "1950-03-15",
        deathDate: null,
        parent1Id: null,
        parent2Id: null,
        spouseId: babId,
        order: 0,
        createdAt: new Date().toISOString(),
      },
      {
        id: babId,
        albumId: treeAlbumId,
        name: "Елена Ушакова",
        role: "babushka",
        photoUrl: "./demo-photos/family3.jpg",
        birthDate: "1952-07-22",
        deathDate: null,
        parent1Id: null,
        parent2Id: null,
        spouseId: dedId,
        order: 1,
        createdAt: new Date().toISOString(),
      },
      {
        id: fatherId,
        albumId: treeAlbumId,
        name: "Сергей Ушаков",
        role: "otets",
        photoUrl: "./demo-photos/family4.jpg",
        birthDate: "1975-11-08",
        deathDate: null,
        parent1Id: dedId,
        parent2Id: babId,
        spouseId: motherId,
        order: 2,
        createdAt: new Date().toISOString(),
      },
      {
        id: motherId,
        albumId: treeAlbumId,
        name: "Мария Ушакова",
        role: "mat",
        photoUrl: "./demo-photos/family5.jpg",
        birthDate: "1978-04-12",
        deathDate: null,
        parent1Id: null,
        parent2Id: null,
        spouseId: fatherId,
        order: 3,
        createdAt: new Date().toISOString(),
      },
      {
        id: childId,
        albumId: treeAlbumId,
        name: "Виктор Ушаков",
        role: "syn",
        photoUrl: "./demo-photos/family1.jpg",
        birthDate: "2005-06-01",
        deathDate: null,
        parent1Id: fatherId,
        parent2Id: motherId,
        spouseId: null,
        order: 4,
        createdAt: new Date().toISOString(),
      },
    ];
    lsSet("ff_familyMembers", members);

    console.log("[seed] Created demo albums + photos + members for new user");
    return;
  }

  // Case 2: user has albums but demo albums are missing content — backfill photos & members
  const photoAlbum = albums.find((a) => a.title === "Мой первый альбом" && a.albumType === "photo");
  if (photoAlbum) {
    const existingPhotos = allPhotos.filter((p) => p.albumId === photoAlbum.id);
    if (existingPhotos.length === 0) {
      const demoPhotos = [
        "./demo-photos/family1.jpg",
        "./demo-photos/family2.jpg",
        "./demo-photos/family3.jpg",
        "./demo-photos/family4.jpg",
        "./demo-photos/family5.jpg",
        "./demo-photos/family6.jpg",
      ];
      const captions = [
        "Семья вместе",
        "Бабушка и дедушка",
        "Готовим вместе",
        "Праздничный ужин",
        "Осенняя прогулка",
        "Закат на пляже",
      ];
      for (let i = 0; i < demoPhotos.length; i++) {
        allPhotos.push({
          id: generateId(),
          albumId: photoAlbum.id,
          url: demoPhotos[i],
          thumbnail: null,
          caption: captions[i],
          location: null,
          takenAt: null,
          isCover: i === 0,
          uploadedBy: 1,
          createdAt: new Date().toISOString(),
        });
      }
      lsSet("ff_photos", allPhotos);
      console.log("[seed] Backfilled demo photos for photo album");
    }
  }

  const treeAlbum = albums.find((a) => a.title === "Семейное древо Ушаковых" && a.albumType === "family_tree");
  if (treeAlbum) {
    // Set cover photo if missing
    if (!treeAlbum.coverPhoto) {
      treeAlbum.coverPhoto = "./demo-photos/tree_cover.jpg";
      lsSet("ff_albums", albums);
      console.log("[seed] Set tree cover photo");
    }
    const existingMembers = allMembers.filter((m) => m.albumId === treeAlbum.id);
    if (existingMembers.length === 0) {
      const dedId = generateId();
      const babId = generateId();
      const fatherId = generateId();
      const motherId = generateId();
      const childId = generateId();

      allMembers.push(
        {
          id: dedId,
          albumId: treeAlbum.id,
          name: "Александр Ушаков",
          role: "ded",
          photoUrl: "./demo-photos/family2.jpg",
          birthDate: "1950-03-15",
          deathDate: null,
          parent1Id: null,
          parent2Id: null,
          spouseId: babId,
          order: 0,
          createdAt: new Date().toISOString(),
        },
        {
          id: babId,
          albumId: treeAlbum.id,
          name: "Елена Ушакова",
          role: "babushka",
          photoUrl: "./demo-photos/family3.jpg",
          birthDate: "1952-07-22",
          deathDate: null,
          parent1Id: null,
          parent2Id: null,
          spouseId: dedId,
          order: 1,
          createdAt: new Date().toISOString(),
        },
        {
          id: fatherId,
          albumId: treeAlbum.id,
          name: "Сергей Ушаков",
          role: "otets",
          photoUrl: "./demo-photos/family4.jpg",
          birthDate: "1975-11-08",
          deathDate: null,
          parent1Id: dedId,
          parent2Id: babId,
          spouseId: motherId,
          order: 2,
          createdAt: new Date().toISOString(),
        },
        {
          id: motherId,
          albumId: treeAlbum.id,
          name: "Мария Ушакова",
          role: "mat",
          photoUrl: "./demo-photos/family5.jpg",
          birthDate: "1978-04-12",
          deathDate: null,
          parent1Id: null,
          parent2Id: null,
          spouseId: fatherId,
          order: 3,
          createdAt: new Date().toISOString(),
        },
        {
          id: childId,
          albumId: treeAlbum.id,
          name: "Виктор Ушаков",
          role: "syn",
          photoUrl: "./demo-photos/family1.jpg",
          birthDate: "2005-06-01",
          deathDate: null,
          parent1Id: fatherId,
          parent2Id: motherId,
          spouseId: null,
          order: 4,
          createdAt: new Date().toISOString(),
        }
      );
      lsSet("ff_familyMembers", allMembers);
      console.log("[seed] Backfilled demo members for tree album");
    }
  }
}

export function getUpcomingBirthdays(_daysWindow = 30) {
  return [] as any[];
}
