import { Routes, Route, Navigate } from "react-router-dom";
import { useEffect } from "react";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import AlbumPage from "./pages/AlbumPage";
import CreateAlbum from "./pages/CreateAlbum";
import AddPhoto from "./pages/AddPhoto";
import PhotoBook from "./pages/PhotoBook";
import InvitePage from "./pages/InvitePage";
import NotFound from "./pages/NotFound";
import SupportPage from "./pages/SupportPage";
import AdminPage from "./pages/AdminPage";
import AdminSupport from "./pages/AdminSupport";
import AdminSettings from "./pages/AdminSettings";
import TrashPage from "./pages/TrashPage";
import ResetPassword from "./pages/ResetPassword";
import { migrateLocalStorageToIndexedDB } from "./lib/photoDb";

function isLoggedIn() {
  try {
    const raw = localStorage.getItem("auth_user");
    if (!raw) return false;
    const user = JSON.parse(raw);
    return !!user?.token;
  } catch {
    return false;
  }
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  if (!isLoggedIn()) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

export default function App() {
  useEffect(() => {
    migrateLocalStorageToIndexedDB().catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-[#faf8f5] text-[#4a4a4a]">
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Landing />
            </ProtectedRoute>
          }
        />
        <Route
          path="/album/:id"
          element={
            <ProtectedRoute>
              <AlbumPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/create-album"
          element={
            <ProtectedRoute>
              <CreateAlbum />
            </ProtectedRoute>
          }
        />
        <Route
          path="/album/:id/add-photo"
          element={
            <ProtectedRoute>
              <AddPhoto />
            </ProtectedRoute>
          }
        />
        <Route
          path="/album/:id/book"
          element={
            <ProtectedRoute>
              <PhotoBook />
            </ProtectedRoute>
          }
        />
        <Route path="/invite/:token" element={<InvitePage />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="/support" element={<SupportPage />} />
        <Route path="/mariana" element={<AdminPage />} />
        <Route path="/admin/support" element={<AdminSupport />} />
        <Route path="/admin/settings" element={<AdminSettings />} />
        <Route
          path="/trash"
          element={
            <ProtectedRoute>
              <TrashPage />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}
