import { Routes, Route, Navigate } from "react-router-dom";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import AlbumPage from "./pages/AlbumPage";
import CreateAlbum from "./pages/CreateAlbum";
import AddPhoto from "./pages/AddPhoto";
import PhotoBook from "./pages/PhotoBook";
import InvitePage from "./pages/InvitePage";
import NotFound from "./pages/NotFound";
import SupportPage from "./pages/SupportPage";
import AdminPage from "./pages/AdminPage";
import AdminSupport from "./pages/AdminSupport";

function isLoggedIn() {
  return !!localStorage.getItem("auth_token");
}

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  if (!isLoggedIn()) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <div className="min-h-screen bg-[#faf8f5] text-[#4a4a4a]">
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <Landing />
            </ProtectedRoute>
          }
        />
        <Route
          path="/album/:id"
          element={
            <ProtectedRoute>
              <AlbumPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/create-album"
          element={
            <ProtectedRoute>
              <CreateAlbum />
            </ProtectedRoute>
          }
        />
        <Route
          path="/album/:id/add-photo"
          element={
            <ProtectedRoute>
              <AddPhoto />
            </ProtectedRoute>
          }
        />
        <Route
          path="/album/:id/book"
          element={
            <ProtectedRoute>
              <PhotoBook />
            </ProtectedRoute>
          }
        />
        <Route path="/invite/:token" element={<InvitePage />} />
        <Route path="/support" element={<SupportPage />} />
        <Route path="/mariana" element={<AdminPage />} />
        <Route path="/admin/support" element={<AdminSupport />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}
