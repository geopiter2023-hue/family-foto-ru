Команды для деплоя на Beget (выполнить в консоли сервера):

# 1. Зайти в папку frontend
ssh user@your-server  # или через панель Beget

# 2. Перейти в директорию сайта
cd /var/www/family-foto-ru

# 3. Сделать бэкап текущей версии
cp -r dist dist-backup-$(date +%Y%m%d)

# 4. Распаковать новую сборку (предполагается что архив уже загружен)
unzip -o family-foto-v19.zip

# 5. Важно: заменить placeholder ключи в .env на реальные!
nano .env
# Заменить:
# VITE_SUPABASE_URL=https://your-project.supabase.co
# VITE_SUPABASE_ANON_KEY=eyJ...

# 6. Пересобрать (если меняли .env)
cd /var/www/family-foto-ru  # корень проекта
cd src && npm install && npm run build

# 7. Готово — dist/ содержит актуальную сборку
