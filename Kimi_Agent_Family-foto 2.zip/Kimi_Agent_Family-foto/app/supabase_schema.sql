-- Supabase schema for family-foto.ru
-- Run in Supabase SQL Editor

-- Enable Row Level Security

-- Albums table
CREATE TABLE IF NOT EXISTS albums (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  year INT,
  month INT,
  album_type VARCHAR(20) NOT NULL DEFAULT 'photo',
  cover_photo TEXT,
  accent_color VARCHAR(20) DEFAULT '#c9a87c',
  background_color VARCHAR(20) DEFAULT '#faf8f5',
  font_family VARCHAR(50) DEFAULT 'serif',
  photos_per_page INT DEFAULT 2,
  is_public BOOLEAN DEFAULT FALSE,
  created_by INT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Photos table
CREATE TABLE IF NOT EXISTS photos (
  id SERIAL PRIMARY KEY,
  album_id INT NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  thumbnail TEXT,
  caption VARCHAR(255),
  location VARCHAR(255),
  taken_at VARCHAR(50),
  is_cover BOOLEAN DEFAULT FALSE,
  uploaded_by INT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Family members table
CREATE TABLE IF NOT EXISTS family_members (
  id SERIAL PRIMARY KEY,
  album_id INT NOT NULL REFERENCES albums(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(100) NOT NULL,
  photo_url TEXT,
  birth_date VARCHAR(20),
  death_date VARCHAR(20),
  parent1_id INT,
  parent2_id INT,
  spouse_id INT,
  bio TEXT,
  email VARCHAR(255),
  phone VARCHAR(50),
  order_num INT DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_photos_album ON photos(album_id);
CREATE INDEX idx_family_members_album ON family_members(album_id);

-- Storage bucket for photos
-- Go to Storage → New bucket → name: "family-foto"
-- Set to public, enable RLS, create policy: allow all for anon
