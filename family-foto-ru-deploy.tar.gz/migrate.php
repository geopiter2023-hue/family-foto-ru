<?php
// Миграция базы данных — откройте этот файл в браузере
// https://family-foto.ru/migrate.php

function parseEnv(string $path): array {
    $env = [];
    if (!file_exists($path)) return $env;
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || $line[0] === '#') continue;
        $eq = strpos($line, '=');
        if ($eq === false) continue;
        $key = trim(substr($line, 0, $eq));
        $value = trim(substr($line, $eq + 1));
        if ((str_starts_with($value, '"') && str_ends_with($value, '"')) ||
            (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
            $value = substr($value, 1, -1);
        }
        $env[$key] = $value;
    }
    return $env;
}

function parseDatabaseUrl(string $url): array {
    $parsed = parse_url($url);
    return [
        'host' => $parsed['host'] ?? 'localhost',
        'port' => $parsed['port'] ?? 3306,
        'user' => $parsed['user'] ?? '',
        'pass' => $parsed['pass'] ?? '',
        'db'   => ltrim($parsed['path'] ?? '', '/'),
    ];
}

$envPath = null;
$candidates = [__DIR__ . '/.env', __DIR__ . '/../.env', __DIR__ . '/../../.env'];
foreach ($candidates as $c) {
    if (file_exists($c)) { $envPath = $c; break; }
}

if (!$envPath) {
    die("<h2 style='color:red'>.env не найден!</h2><p>Убедитесь что файл .env лежит рядом с migrate.php</p>");
}

$env = parseEnv($envPath);
$dbUrl = $env['DATABASE_URL'] ?? '';

if (empty($dbUrl) || str_contains($dbUrl, 'ВАШ_ПАРОЛЬ')) {
    die("<h2 style='color:red'>DATABASE_URL не настроен!</h2><p>Откройте .env и замените ВАШ_ПАРОЛЬ на реальный пароль от базы данных.</p>");
}

$db = parseDatabaseUrl($dbUrl);

try {
    $dsn = "mysql:host={$db['host']};port={$db['port']};dbname={$db['db']};charset=utf8mb4";
    $pdo = new PDO($dsn, $db['user'], $db['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
} catch (PDOException $e) {
    die("<h2 style='color:red'>Ошибка подключения!</h2><p>" . htmlspecialchars($e->getMessage()) . "</p>");
}

$tables = [
    "users" => "CREATE TABLE IF NOT EXISTS users (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, email VARCHAR(320) NOT NULL UNIQUE, name VARCHAR(255), createdAt TIMESTAMP DEFAULT NOW() NOT NULL, updatedAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "otpCodes" => "CREATE TABLE IF NOT EXISTS otpCodes (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, email VARCHAR(320) NOT NULL, code VARCHAR(6) NOT NULL, expiresAt TIMESTAMP NOT NULL, used TINYINT(1) DEFAULT 0 NOT NULL, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "albums" => "CREATE TABLE IF NOT EXISTS albums (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, userId BIGINT UNSIGNED NOT NULL, year INT NOT NULL, title VARCHAR(255) NOT NULL, location VARCHAR(255), description TEXT, coverPhotoId BIGINT UNSIGNED, photosPerPage INT DEFAULT 1 NOT NULL, createdAt TIMESTAMP DEFAULT NOW() NOT NULL, updatedAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "photos" => "CREATE TABLE IF NOT EXISTS photos (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, albumId BIGINT UNSIGNED NOT NULL, familyMemberId BIGINT UNSIGNED, url LONGTEXT NOT NULL, caption VARCHAR(255), emotion VARCHAR(50), emotionNote TEXT, dateTaken TIMESTAMP, createdAt TIMESTAMP DEFAULT NOW() NOT NULL, updatedAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "familyMembers" => "CREATE TABLE IF NOT EXISTS familyMembers (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, userId BIGINT UNSIGNED NOT NULL, name VARCHAR(255) NOT NULL, email VARCHAR(320), avatar LONGTEXT, color VARCHAR(20) DEFAULT '#c9a87c' NOT NULL, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "albumInvites" => "CREATE TABLE IF NOT EXISTS albumInvites (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, albumId BIGINT UNSIGNED NOT NULL, email VARCHAR(320) NOT NULL, name VARCHAR(255), token VARCHAR(64) NOT NULL UNIQUE, status VARCHAR(20) DEFAULT 'pending' NOT NULL, invitedBy BIGINT UNSIGNED NOT NULL, acceptedAt TIMESTAMP, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "albumShares" => "CREATE TABLE IF NOT EXISTS albumShares (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, albumId BIGINT UNSIGNED NOT NULL, ownerUserId BIGINT UNSIGNED NOT NULL, sharedWithUserId BIGINT UNSIGNED NOT NULL, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "photoBookPages" => "CREATE TABLE IF NOT EXISTS photoBookPages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, albumId BIGINT UNSIGNED NOT NULL, pageNumber INT NOT NULL, layoutType VARCHAR(50) NOT NULL, title VARCHAR(255), subtitle VARCHAR(255), backgroundColor VARCHAR(20) DEFAULT '#faf8f5', accentColor VARCHAR(20) DEFAULT '#c9a87c', pageData LONGTEXT, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "pageAssignments" => "CREATE TABLE IF NOT EXISTS pageAssignments (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, albumId BIGINT UNSIGNED NOT NULL, pageNumber INT NOT NULL, photoId BIGINT UNSIGNED NOT NULL, position INT DEFAULT 0 NOT NULL, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "supportReviews" => "CREATE TABLE IF NOT EXISTS supportReviews (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, rating INT NOT NULL, comment TEXT, thanks TEXT, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "cardCopyStats" => "CREATE TABLE IF NOT EXISTS cardCopyStats (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, ip VARCHAR(45), userAgent TEXT, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
    "supportMessages" => "CREATE TABLE IF NOT EXISTS supportMessages (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), email VARCHAR(320), message TEXT NOT NULL, type VARCHAR(20) DEFAULT 'support' NOT NULL, isRead TINYINT(1) DEFAULT 0 NOT NULL, createdAt TIMESTAMP DEFAULT NOW() NOT NULL)",
];

$created = []; $errors = [];
foreach ($tables as $name => $sql) {
    try { $pdo->exec($sql); $created[] = $name; }
    catch (PDOException $e) { $errors[] = "$name: " . $e->getMessage(); }
}
?><!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><title>Миграция</title><style>body{font-family:system-ui,sans-serif;background:#f5efe6;padding:40px 20px;max-width:600px;margin:0 auto}h1{color:#6B4226}.success{background:#d4edda;border:1px solid #c3e6cb;color:#155724;padding:16px;border-radius:12px;margin-bottom:12px}.error{background:#f8d7da;border:1px solid #f5c6cb;color:#721c24;padding:16px;border-radius:12px;margin-bottom:12px}.table-list{background:white;padding:20px;border-radius:16px;box-shadow:0 2px 8px rgba(0,0,0,0.05)}.table-item{display:flex;gap:8px;padding:6px 0;border-bottom:1px solid #f0ebe3}.check{color:#28a745;font-weight:bold}.cross{color:#dc3545;font-weight:bold}.btn{display:inline-block;background:#c9a87c;color:white;padding:12px 24px;border-radius:12px;text-decoration:none;margin-top:20px}</style></head><body><h1>Семейный Альбом</h1><?php if(empty($errors)):?><div class="success">Все таблицы созданы! Всего <?=count($created)?> таблиц.</div><?php else:?><div class="error"><strong>Ошибки:</strong><br><?php foreach($errors as $err):?><?=htmlspecialchars($err)?><br><?php endforeach;?></div><?php endif;?><div class="table-list"><?php foreach($tables as $name=>$sql):?><div class="table-item"><?php if(in_array($name,$created)):?><span class="check">✓</span> <?=$name?><?php else:?><span class="cross">✗</span> <?=$name?><?php endif;?></div><?php endforeach;?></div><a href="/" class="btn">Перейти на сайт →</a></body></html>