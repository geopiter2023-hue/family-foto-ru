#!/bin/sh
echo "=== Семейный Альбом ==="
node boot.js
