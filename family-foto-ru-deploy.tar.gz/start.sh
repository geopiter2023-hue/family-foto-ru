#!/bin/sh
echo "=== Семейный Альбом ==="
echo "PORT: ${PORT:-3000}"
node boot.js
