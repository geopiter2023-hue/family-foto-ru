import { getDb } from "../api/queries/connection";

async function migrate() {
  const db = getDb();

  await db.execute(`
    CREATE TABLE IF NOT EXISTS supportReviews (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      rating INT NOT NULL,
      comment TEXT,
      thanks TEXT,
      createdAt TIMESTAMP DEFAULT NOW() NOT NULL
    )
  `);

  await db.execute(`
    CREATE TABLE IF NOT EXISTS cardCopyStats (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      ip VARCHAR(45),
      userAgent TEXT,
      createdAt TIMESTAMP DEFAULT NOW() NOT NULL
    )
  `);

  await db.execute(`
    CREATE TABLE IF NOT EXISTS supportMessages (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255),
      email VARCHAR(320),
      message TEXT NOT NULL,
      type VARCHAR(20) DEFAULT 'support' NOT NULL,
      isRead TINYINT(1) DEFAULT 0 NOT NULL,
      createdAt TIMESTAMP DEFAULT NOW() NOT NULL
    )
  `);

  console.log("All migrations completed successfully");
  process.exit(0);
}

migrate().catch((err) => {
  console.error("Migration failed:", err);
  process.exit(1);
});
